// js/shared/submission-guard.js — شبتوت بحري
// ═══════════════════════════════════════════════════════════════════
//  حراسة الفورمات العامة (بيت المناسبات، صندوق الأفكار، تواصل معنا،
//  والتعليقات) — دفاع من طبقتين، مُطبَّق في db.js نفسه (مش في كل
//  فورم لوحده) عشان محدش ينساها لاحقًا:
//
//  ١) حد طول صارم لكل حقل — الـ maxlength في الفورمات (input/textarea)
//     واجهة بس، أي حد يقدر يتخطاها بنداء addOccasion/addIdea... مباشرة
//     من الـ console. enforceMaxLength() بترمي خطأ فعلي لو الحقل تخطى
//     الحد، بغض النظر عن مصدر النداء.
//
//  ٢) تهدئة بسيطة بين كل عملية نشر وبعدها (cooldown) — مش حماية سبام
//     حقيقية (المفروض تبقى في سياسات RLS / Cloud Functions لما
//     ننتقل)، لكنها بترفع سقف أي محاولة إغراق سريعة عبر console أو
//     script، وبتتخزن في localStorage عشان تنفع حتى لو الصفحة اتحدّثت.
//
//  ملحوظة معمارية: لما ننتقل لـ Firebase، الطبقة الحقيقية هي
//  سياسات RLS في Supabase (حدود الطول) + Cloud Function أو App Check
//  (التهدئة الحقيقية) — الملف ده حماية أولى مؤقتة، مش بديل عنها.
// ═══════════════════════════════════════════════════════════════════

const COOLDOWN_PREFIX = 'submission_cooldown:';

/** خطأ حراسة النشر — رسالته آمنة للعرض المباشر للمستخدم (عربية، مُعدّة مسبقًا،
 * ما فيهاش أي تفاصيل تقنية) على عكس أي خطأ تاني (شبكة، adapter...). */
export class SubmissionGuardError extends Error {}

/**
 * يتأكد إن كل حقل من الحقول المُمرَّرة ما تخطاش حده الأقصى — يرمي
 * خطأ برسالة عربية واضحة لو حقل واحد تخطى.
 * @param {Record<string, { value: string, max: number, label: string }>} fields
 */
export function enforceMaxLength(fields) {
  for (const key in fields) {
    const { value, max, label } = fields[key];
    if (typeof value === 'string' && value.length > max) {
      throw new SubmissionGuardError(`${label} طويل زيادة (الحد الأقصى ${max} حرف)`);
    }
  }
}

/**
 * يتأكد إن آخر عملية من نفس النوع مرّ عليها وقت كافٍ، ويسجّل وقت
 * المحاولة الحالية. يرمي خطأ لو المستخدم بيحاول ينشر بسرعة زيادة.
 * @param {string} actionKey - مفتاح فريد لنوع العملية (مثلاً 'add-occasion')
 * @param {number} [cooldownMs=4000]
 */
export function enforceCooldown(actionKey, cooldownMs = 4000) {
  const storageKey = COOLDOWN_PREFIX + actionKey;
  let last = 0;
  try {
    last = Number(localStorage.getItem(storageKey) || 0);
  } catch {
    return; // localStorage مش متاح (وضع خاص مثلاً) — نتجاوز التهدئة بدل ما نكسر النشر
  }

  const now = Date.now();
  if (now - last < cooldownMs) {
    throw new SubmissionGuardError('على مهلك شوية — استنى ثواني وجرب تاني');
  }

  try {
    localStorage.setItem(storageKey, String(now));
  } catch {
    // فشل الكتابة مش سبب كافي لمنع النشر
  }
}

// ═══════════════════════════════════════════════════════════════════
//  فلتر "الكلام المفهوم" — للأفكار والمناسبات فقط (مش التعليقات: الضحك
//  "هههه" ورد "آمين" مقبولين هناك).
//
//  حماية أولى من الطلاسم العفوية (ااااا، سيبلتنم، asdfgh، ١٢٣٤٥٦٧)،
//  مش حماية من شخص قاصد الإزعاج — ده دور المراجعة قبل الظهور.
// ═══════════════════════════════════════════════════════════════════

/** حدود النشر اليومي لكل حساب. نفس الأرقام مكتوبة في سياسات RLS في Supabase
 *  (دالة ideaQuotaOk/occasionQuotaOk) — غيّر الاتنين مع بعض. */
export const SUBMISSION_LIMITS = { ideas: 2, occasions: 2 };

/** أقصى عدد تعليقات للشخص الواحد على الفكرة الواحدة (المشرفون خارج الحد).
 *  نفس الرقم مفروض في سياسات RLS في Supabase عبر معرّفات التعليق `${uid}_1..3` — غيّر الاتنين مع بعض. */
export const IDEA_COMMENTS_PER_USER = 3;

export function ideaCommentLimitMessage() {
  const n = IDEA_COMMENTS_PER_USER;
  const what = n === 1 ? 'تعليق واحد' : n === 2 ? 'تعليقين' : `${n} تعليقات`;
  return `وصلت للحد على هذه الفكرة (${what} للشخص الواحد). تقدر تعلّق على أفكار تانية`;
}

const _LIMIT_LABELS = { ideas: 'أفكار', occasions: 'مناسبات' };

export function dailyLimitMessage(kind) {
  const n = SUBMISSION_LIMITS[kind];
  const what = kind === 'ideas'
    ? (n === 1 ? 'فكرة واحدة' : n === 2 ? 'فكرتين' : `${n} أفكار`)
    : (n === 1 ? 'مناسبة واحدة' : n === 2 ? 'مناسبتين' : `${n} مناسبات`);
  return `وصلت للحد اليومي (${what} في اليوم). تقدر تنشر ${_LIMIT_LABELS[kind]} تانية بكرة بإذن الله`;
}

// صفوف لوحة المفاتيح العربية — تتابع ٥ حروف متجاورة بنفس الترتيب = ضغط عشوائي
const _KEYBOARD_ROWS = [
  'ضصثقفغعهخحجد',
  'شسيبلاتنمكط',
  'ئءؤرلاىةوزظ',
  'qwertyuiop',
  'asdfghjkl',
  'zxcvbnm',
];
const _KEY_RUN = 5;

function _hasKeyboardRun(letters) {
  const s = [...letters.toLowerCase()];
  for (const row of _KEYBOARD_ROWS) {
    const idx = s.map(c => row.indexOf(c));
    for (const dir of [1, -1]) {
      // strict: ٥ مفاتيح متجاورة تمامًا · loose: ٨ بتخطي مفتاح أحيانًا
      // (loose بحد أعلى عشان كلمات حقيقية زي "مناسباتنا" ما تتصنّفش عشوائية)
      let strict = 1, loose = 1;
      for (let i = 1; i < s.length; i++) {
        const valid = idx[i] >= 0 && idx[i - 1] >= 0;
        const step = (idx[i] - idx[i - 1]) * dir;
        strict = valid && step === 1 ? strict + 1 : 1;
        loose  = valid && (step === 1 || step === 2) ? loose + 1 : 1;
        if (strict >= _KEY_RUN || loose >= 8) return true;
      }
    }
  }
  return false;
}

/**
 * يرجع سبب الرفض (نص عربي) أو '' لو الكلام مقبول.
 * @param {string} value
 * @param {{ minLetters?: number }} [opts]
 */
export function readabilityProblem(value, { minLetters = 3 } = {}) {
  const text = String(value || '')
    .replace(/[\u0640\u064B-\u0652]/g, '')   // تطويل + تشكيل
    .trim();
  if (!text) return '';

  const letters = text.match(/[\u0621-\u064A\u0671-\u06D3a-zA-Z]/g) || [];
  const nonSpace = text.replace(/\s/g, '');

  if (letters.length < minLetters) return 'قصير زيادة';

  // أغلبه أرقام/رموز
  if (letters.length / nonSpace.length < 0.6) return 'في رموز أو أرقام أكتر من الكلام';

  // حرف واحد متكرر ٤ مرات ورا بعض (ااااا، ممممم)
  if (/(.)\1{3,}/u.test(text.replace(/\s/g, ''))) return 'في حروف متكررة';

  // تنوّع الحروف ضعيف في نص طويل نسبيًا (ابابابابابابا)
  if (letters.length >= 10 && new Set(letters.map(c => c.toLowerCase())).size <= 3) {
    return 'الحروف متكررة بشكل غير طبيعي';
  }

  // كلمة واحدة مكررة تشكّل معظم النص (كلام كلام كلام كلام)
  const tokens = text.split(/\s+/).filter(Boolean);
  if (tokens.length >= 4) {
    const counts = new Map();
    tokens.forEach(t => counts.set(t, (counts.get(t) || 0) + 1));
    if (Math.max(...counts.values()) / tokens.length > 0.6) return 'الكلمة نفسها متكررة';
  }

  // ضغط عشوائي على لوحة المفاتيح
  for (const t of tokens) {
    const tl = (t.match(/[\u0621-\u064A\u0671-\u06D3a-zA-Z]/g) || []).join('');
    if (tl.length >= _KEY_RUN && _hasKeyboardRun(tl)) return 'شكله ضغط عشوائي على الكيبورد';
    // لاتيني بلا حروف علّة أو بسلسلة صوامت طويلة
    if (/^[a-zA-Z]{5,}$/.test(tl) && (!/[aeiouyAEIOUY]/.test(tl) || /[^aeiouyAEIOUY]{6,}/.test(tl))) {
      return 'شكله كلام غير مفهوم';
    }
  }

  return '';
}

/**
 * يرمي SubmissionGuardError برسالة عربية لو أي حقل غير مفهوم.
 * @param {Record<string, { value: string, label: string, required?: boolean, minLetters?: number }>} fields
 *   الحقل الاختياري الفاضي يعدّي؛ المملوء لازم يعدّي الفحص.
 */
export function enforceReadable(fields) {
  for (const key in fields) {
    const { value, label, minLetters } = fields[key];
    const v = typeof value === 'string' ? value.trim() : '';
    if (!v) continue;
    const problem = readabilityProblem(v, { minLetters });
    if (problem) {
      throw new SubmissionGuardError(`${label}: ${problem}. اكتب بكلام مفهوم لو سمحت`);
    }
  }
}
