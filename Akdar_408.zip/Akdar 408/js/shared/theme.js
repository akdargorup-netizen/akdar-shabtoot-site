// js/shared/theme.js — شبتوت بحري
// ══════════════════════════════════════════════════════════════
//  محلّل الثيم الموحَّد — المصدر الوحيد لتطبيق الثيم في التطبيق كله.
//
//  المشكلة اللي بيحلّها:
//  إعداد المستخدم (data-theme) له قيمتان: "light" و"system". الثيم الفاتح
//  كان مكتوب مرة لـ [data-theme="light"] ومرة تانية (ناقصة) داخل
//  @media (prefers-color-scheme: light) لـ [data-theme="system"]، فمعظم
//  قواعد الفاتح ما كانتش بتوصل لمستخدم "تلقائي" على جهاز فاتح (وهو
//  الافتراضي). كمان meta theme-color (شريط حالة الجهاز) كان ثابت داكن.
//
//  الحل: نحسب القيمة "المحلولة" مرة واحدة هنا ونحطها في data-scheme
//  (= "light" | "dark")، وكل CSS الثيم بيقرأ data-scheme بس.
//  بتتحدّث لحظياً لو الجهاز بدّل بين فاتح/داكن والتطبيق مفتوح.
//
//  ⚠️ لأي حد (أو أداة ذكاء اصطناعي) بيضيف CSS للثيم الفاتح: اكتب
//  [data-scheme="light"] .x — مش [data-theme="light"] ولا @media
//  (prefers-color-scheme) — وهيشتغل لـ"فاتح" و"تلقائي" معاً تلقائياً.
// ══════════════════════════════════════════════════════════════

const THEME_KEY = 'app-theme';

// لون شريط الحالة/المتصفح (meta theme-color) لكل سطح — نفس surface-base
const CHROME_COLOR = { light: '#f2f2e6', dark: '#1b1c14' };

const mql = typeof window !== 'undefined' && window.matchMedia
  ? window.matchMedia('(prefers-color-scheme: dark)')
  : null;

// الهواتف الضعيفة/الـ WebView القديم (أقدم من Chrome 76) لا تعرف prefers-color-scheme أصلًا،
// فيرجع الاستعلام "not all" ولا يطابق أبدًا → كان "تلقائي" يبقى فاتحًا دائمًا.
// في هذه الحالة فقط نستخدم وقت الجهاز كبديل: داكن من ٧ مساءً حتى ٥ فجرًا.
function _prefersColorSchemeSupported() {
  try {
    if (!mql || mql.media === 'not all') return false;
    return mql.matches || window.matchMedia('(prefers-color-scheme: light)').matches;
  } catch { return false; }
}
function _nightNow() {
  const h = new Date().getHours();
  return h >= 19 || h < 5;
}

/** يحوّل إعداد المستخدم (light | system) إلى سطح فعلي (light | dark) */
export function resolveScheme(theme) {
  if (theme === 'light') return 'light';
  if (_prefersColorSchemeSupported()) return mql.matches ? 'dark' : 'light';
  return _nightNow() ? 'dark' : 'light';
}

export function getStoredTheme() {
  // خياران فقط: فاتح | تلقائي — القيمة القديمة "dark" تُعامل كـ "تلقائي"
  try { return localStorage.getItem(THEME_KEY) === 'light' ? 'light' : 'system'; }
  catch { return 'system'; }
}

function paint(theme) {
  const root   = document.documentElement;
  theme = theme === 'light' ? 'light' : 'system';
  const scheme = resolveScheme(theme);

  root.setAttribute('data-theme', theme);
  root.setAttribute('data-scheme', scheme);

  // لون شريط حالة الجهاز/المتصفح يتبع الثيم (كان ثابت داكن)
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute('content', CHROME_COLOR[scheme]);

  return scheme;
}

/**
 * يطبّق الثيم. withTransition=true (عند تغيير المستخدم له يدوياً) يضيف
 * انتقال لوني ناعم لمدة قصيرة بدل القفزة المفاجئة — ويُحترم تفضيل تقليل الحركة.
 */
export function applyTheme(theme, withTransition = false) {
  const root = document.documentElement;
  const reduce = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;

  if (withTransition && !reduce) {
    root.setAttribute('data-theme-changing', '');
    clearTimeout(applyTheme._t);
    applyTheme._t = setTimeout(() => root.removeAttribute('data-theme-changing'), 450);
  }
  return paint(theme);
}

let _inited = false;

/** يُستدعى مرة واحدة عند بدء التطبيق (app.js) */
export function initTheme() {
  paint(getStoredTheme());
  if (_inited) return;
  _inited = true;

  // لو الإعداد "تلقائي" والجهاز بدّل فاتح↔داكن والتطبيق مفتوح
  const onChange = () => {
    if (getStoredTheme() === 'system') applyTheme('system', true);
  };
  if (mql) {
    if (mql.addEventListener) mql.addEventListener('change', onChange);
    else if (mql.addListener)  mql.addListener(onChange);   // Safari القديم
  }
  // أجهزة بلا دعم prefers-color-scheme: نعيد الحساب كلما رجع التطبيق للواجهة (الوقت قد يكون تغيّر)
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible' && getStoredTheme() === 'system' && !_prefersColorSchemeSupported()) {
      applyTheme('system');
    }
  });
}
