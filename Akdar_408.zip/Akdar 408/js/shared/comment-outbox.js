// js/shared/comment-outbox.js — شبتوت بحري
// ═══════════════════════════════════════════════════════════════════
//  طابور تعليقات بيت المناسبات وصندوق الأفكار وقت عدم توفر شبكة حقيقية — نفس فكرة
//  "الرسالة المعلّقة" في واتساب: بمجرد الضغط على إرسال والجهاز
//  أوفلاين (navigator.onLine === false) أو فشل الإرسال فعليًا،
//  نحفظ التعليق في localStorage فورًا (تفضل الفقاعة بعلامة ساعة)،
//  ولما يرجع نت حقيقي (حدث 'online' من المتصفح) نحاول نرسله عبر
//  addOccasionComment نفسها — مفيش أي محاكاة وهمية بـ setTimeout،
//  الإرسال الفعلي بيصير أول ما الشبكة ترجع بجد.
// ═══════════════════════════════════════════════════════════════════

import { isTransientFailure, shouldQueue } from './transient-error.js';

const MAX_UNKNOWN_TRIES = 6; // فشل غير مفهوم: نعيد المحاولة هذا العدد قبل التخلّي وإعلام المستخدم

const KEYS = { occasion: 'akdar_occasion_comment_outbox', idea: 'akdar_idea_comment_outbox' };

function _readAll(kind) {
  try {
    return JSON.parse(localStorage.getItem(KEYS[kind]) || '{}');
  } catch {
    return {};
  }
}

function _writeAll(kind, data) {
  try {
    localStorage.setItem(KEYS[kind], JSON.stringify(data));
  } catch {
    /* تخزين ممتلئ أو غير متاح (وضع خاص مثلاً) — نتجاهل بصمت، التعليق
       يفضل في الذاكرة لهذه الجلسة بس، أهون من ما نكسر النشر. */
  }
}

function _queue(kind, parentId, comment) {
  const all = _readAll(kind);
  const list = all[parentId] || [];
  const tempId = `pending-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  const queued = { ...comment, id: tempId, createdAt: new Date().toISOString(), _pending: true };
  list.push(queued);
  all[parentId] = list;
  _writeAll(kind, all);
  return queued;
}

/** يضيف تعليقًا لطابور الإرسال المحلي ويرجّع نسخته المعلّقة (فيها
 * id مؤقت و _pending: true) عشان تُعرض فورًا كفقاعة بعلامة ساعة. */
export function queueComment(occasionId, comment) {
  return _queue('occasion', occasionId, comment);
}

/** نفس الشيء لتعليقات الأفكار. comment.clientId (مفتاح التفرّد) يلزم أن يكون نفسه الذي جُرّب به الإرسال الأول. */
export function queueIdeaComment(ideaId, comment) {
  return _queue('idea', ideaId, comment);
}

/** هل عند هذا المستخدم تعليق معلّق (لسع ما اترسلش) على هذه المناسبة؟ */
export function getQueuedUserComment(occasionId, uid) {
  const list = _readAll('occasion')[occasionId] || [];
  return list.find(c => c.uid === uid) || null;
}

export function getQueuedComments(occasionId) {
  return _readAll('occasion')[occasionId] || [];
}

export function getQueuedIdeaComments(ideaId) {
  return _readAll('idea')[ideaId] || [];
}

function _removeFromQueue(kind, parentId, tempId) {
  const all = _readAll(kind);
  const list = (all[parentId] || []).filter(c => c.id !== tempId);
  if (list.length) all[parentId] = list;
  else delete all[parentId];
  _writeAll(kind, all);
}

function _bumpTries(kind, parentId, tempId) {
  const all = _readAll(kind);
  const item = (all[parentId] || []).find(c => c.id === tempId);
  if (!item) return 0;
  item._tries = (item._tries || 0) + 1;
  _writeAll(kind, all);
  return item._tries;
}

function _hasQueuedItems() {
  return ['occasion', 'idea'].some((kind) => {
    const all = _readAll(kind);
    return Object.keys(all).some(k => (all[k] || []).length > 0);
  });
}

let _flushing = false;
let _failStreak = 0; // محاولات فاشلة متتالية: نمدّ الفاصل (٣٠ث ← ٥ دقائق) كي لا نضغط خادمًا مشغولًا
let _nextAt = 0;

/** يحاول إرسال كل التعليقات المعلّقة فعلاً — بيتنفّذ فقط لو الجهاز
 * فعلاً أونلاين، وبينادي addOccasionComment / addIdeaComment الحقيقية من db.js.
 * عند النجاح: يشيل التعليق من الطابور ويطلق حدث akdar:comment-synced
 * عشان أي صفحة مفتوحة تحدّث الفقاعة من ساعة لصح. تعليق الفكرة الذي يرفضه الخادم نهائيًا
 * (حد يومي/حظر...) يُشال ويُطلق akdar:comment-failed ليعرف المستخدم ولا تبقى ساعته للأبد. */
export async function flushOutbox() {
  if (_flushing || !navigator.onLine || !_hasQueuedItems() || Date.now() < _nextAt) return;
  _flushing = true;
  let failed = false;
  try {
    const { addOccasionComment, addIdeaComment } = await import('../data/db.js');

    const occ = _readAll('occasion');
    for (const occasionId of Object.keys(occ)) {
      for (const queued of occ[occasionId] || []) {
        try {
          const { id, _pending, _tries, ...payload } = queued;
          const saved = await addOccasionComment(occasionId, payload);
          _removeFromQueue('occasion', occasionId, id);
          window.dispatchEvent(new CustomEvent('akdar:comment-synced', {
            detail: { kind: 'occasion', occasionId, tempId: id, comment: saved },
          }));
        } catch (err) {
          // لو اتضاف تعليق لنفس المستخدم من مكان تاني قبل ما نلحق
          // نرسل هذا (uid مكرر) — نشيله من الطابور، محاولة الإرسال
          // بقت بلا فايدة أصلًا. أي خطأ تاني (شبكة اتقطعت وسط
          // المحاولة، أو تهدئة enforceCooldown) يفضل بالطابور
          // للمحاولة الجاية.
          if (err?.message === 'لقد علّقت على هذه المناسبة من قبل') {
            _removeFromQueue('occasion', occasionId, queued.id);
          } else {
            failed = true;
          }
        }
      }
    }

    const ideas = _readAll('idea');
    for (const ideaId of Object.keys(ideas)) {
      for (const queued of ideas[ideaId] || []) {
        try {
          const { id, _pending, _tries, createdAt, ...payload } = queued;
          const saved = await addIdeaComment(ideaId, payload); // payload.clientId يمنع التكرار
          _removeFromQueue('idea', ideaId, id);
          window.dispatchEvent(new CustomEvent('akdar:comment-synced', {
            detail: { kind: 'idea', ideaId, tempId: id, comment: saved },
          }));
        } catch (err) {
          if (isTransientFailure(err) || (shouldQueue(err) && _bumpTries('idea', ideaId, queued.id) < MAX_UNKNOWN_TRIES)) {
            failed = true; // نعيد المحاولة لاحقًا
          } else {
            _removeFromQueue('idea', ideaId, queued.id);
            window.dispatchEvent(new CustomEvent('akdar:comment-failed', {
              detail: { kind: 'idea', ideaId, tempId: queued.id, text: queued.text, message: err?.message || '' },
            }));
          }
        }
      }
    }
  } finally {
    _flushing = false;
    if (failed) {
      _failStreak = Math.min(_failStreak + 1, 6);
      _nextAt = Date.now() + Math.min(30000 * 2 ** (_failStreak - 1), 300000) + Math.random() * 10000;
    } else { _failStreak = 0; _nextAt = 0; }
  }
}

// عودة الاتصال: نبدأ من جديد (مع تفريق عشوائي حتى لا تعود آلاف الأجهزة معًا)
window.addEventListener('online', () => { _nextAt = 0; setTimeout(flushOutbox, Math.random() * 8000); });

// لو رجعنا فتحنا التطبيق ولسع فيه طابور من جلسة سابقة والشبكة
// متوفرة فعلاً دلوقتي — نحاول فورًا بدل ما ننتظر حدث 'online' اللي
// ممكن ما يطلقش لو الجهاز كان أونلاين من الأساس وقت الفتح.
flushOutbox();

// شبكة بعض الأجهزة بترجع فعليًا من غير ما حدث 'online' يتطلق بثبات
// (خصوصًا WebView على أندرويد) — محاولة احتياطية خفيفة كل نص دقيقة
// طول ما فيه تعليقات لسع معلّقة، تتوقف تلقائيًا لما الطابور يفضى.
setInterval(() => { if (_hasQueuedItems()) flushOutbox(); }, 30000);
