// js/shared/name-required-modal.js — شبتوت بحري
// ═══════════════════════════════════════════════════════════════════
//  نافذة "اكتب اسمك" — إجبارية، تظهر مباشرة بعد نجاح تسجيل الدخول
//  بجوجل لأول مرة (لما ما يكون عنده اسم مخصص محفوظ من قبل). بنفس
//  فلسفة permission-onboarding.js: زرار واحد بس، بدون "بعدين"، وبدون
//  إغلاق بالضغط على الخلفية أو زرار إغلاق — المستخدم لازم يكتب اسم
//  حقيقي (سطرين فأكثر بعد trim) قبل ما يكمل لأي فعل (تعليق/تصويت/
//  مناسبة...). كان قبل كده window.prompt() قابل للإلغاء، فيسمح
//  بالاستمرار باسم فاضي/null — ده اللي هذه النافذة بتمنعه.
// ═══════════════════════════════════════════════════════════════════

import { renderIcons } from './icons.js';

const MIN_LENGTH = 2;

let _cleanup = null;

/**
 * يفتح نافذة إجبارية لإدخال اسم العرض، ولا يحل الـ promise إلا باسم
 * صالح فعلاً (بعد trim، طوله >= 2 حرف). لا يوجد أي طريقة تجاوز.
 * @param {string} [suggested] اسم مقترح مبدئي (زي اسم حساب جوجل) يُعرض كقيمة افتراضية في الحقل
 * @param {number} [maxLength] الحد الأعلى لطول الاسم
 * @returns {Promise<string>} الاسم النهائي بعد الـ trim
 */
export function promptRequiredName(suggested = '', maxLength = 40) {
  return new Promise(resolve => {
    closeNameRequiredModal(); // تأكد عدم تكرار النافذة

    const backdrop = document.createElement('div');
    backdrop.className = 'overlay-backdrop overlay-backdrop--center';
    backdrop.innerHTML = `
      <div class="modal modal--center login-prompt-modal" role="dialog" aria-modal="true" aria-label="اكتب اسمك">
        <div class="modal__body login-prompt-modal__body">
          <div class="login-prompt-modal__icon"><i data-lucide="user-round-pen"></i></div>
          <h3 class="modal__title login-prompt-modal__title">عرّف نفسك لأهل البلد</h3>
          <p class="login-prompt-modal__desc">
            اكتب الاسم الذي تحب أن يظهر به على تعليقاتك وأفكارك ومشاركاتك في مناسبات البلد.
          </p>
          <div class="input-group">
            <input
              type="text"
              class="input"
              id="name-required-input"
              maxlength="${maxLength}"
              autocomplete="name"
              placeholder="اكتب اسمك هنا..."
              value="${(suggested || '').replace(/"/g, '&quot;')}"
            />
            <p class="input-error-msg" id="name-required-error" style="display:none;">
              اكتب اسم لا يقل عن حرفين
            </p>
          </div>
        </div>
        <div class="modal__footer">
          <button class="btn btn--primary btn--full" id="name-required-submit">تأكيد الاسم</button>
        </div>
      </div>
    `;
    document.body.appendChild(backdrop);
    renderIcons(backdrop);

    const input    = backdrop.querySelector('#name-required-input');
    const errorMsg = backdrop.querySelector('#name-required-error');
    const submitBtn = backdrop.querySelector('#name-required-submit');

    const trySubmit = () => {
      const name = input.value.trim().slice(0, maxLength);
      if (name.length < MIN_LENGTH) {
        input.classList.add('input--error');
        errorMsg.style.display = 'flex';
        input.focus();
        return;
      }
      closeNameRequiredModal();
      resolve(name);
    };

    input.addEventListener('input', () => {
      input.classList.remove('input--error');
      errorMsg.style.display = 'none';
    });
    input.addEventListener('keydown', e => {
      if (e.key === 'Enter') trySubmit();
    });
    submitBtn.addEventListener('click', trySubmit);

    _cleanup = () => backdrop.remove();

    // تركيز تلقائي على الحقل عشان المستخدم يكتب فوراً
    setTimeout(() => input.focus(), 50);
  });
}

/** إغلاق النافذة إن كانت مفتوحة (بدون حل الـ promise — تُستخدم داخليًا). */
export function closeNameRequiredModal() {
  if (_cleanup) {
    _cleanup();
    _cleanup = null;
  }
}
