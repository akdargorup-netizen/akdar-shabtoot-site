// js/shared/audio-clips.js — شبتوت بحري
// ═══════════════════════════════════════════════════════════════════
// تشغيل مقاطع النطق الصوتي (قاموس آنداندي + تعلم الكلام).
//
// لماذا لا <audio src="رابط"> مباشرة؟ المتصفح يرسل طلبات Range للوسائط، والكاش لا يجيب عنها جيدًا
// (iOS خصوصًا). فنجلب المقطع كاملًا (~٢٠KB) مرة واحدة، نخزّنه في كاش خاص، ونشغّله من blob.
//
// • حقل audio على الكلمة/الجملة = مسار نسبي داخل bucket (مثل w/<id>-v1.m4a). غيابه = لا زر.
// • الكاش akdar-clips-v1: مُدرج في قائمة الاستثناء بـ activate في service-worker.js (لا يُمسح مع التحديثات)،
//   وسقفه بالعدد كي لا يتضخم. لا علاقة له بـ CACHE_VERSION ولا بالتحميل المسبق.
// • مقطع واحد في كل مرة: الضغطة الجديدة توقف السابق.
// • الأخطاء كلها هادئة (رسالة لطيفة بلا نت وبلا نسخة محفوظة).
// ═══════════════════════════════════════════════════════════════════

import { SUPABASE_URL } from '../data/supabase-client.js';
import { AUDIO_PREFIX, secondaryClipUrl, fetchObject } from '../data/storage-overflow.js';

export const CLIPS_CACHE = 'akdar-clips-v1';
// (v546) لا سقف ولا حذف للمقاطع: صوت آنداندي ثابت بأسماء فريدة، وكل حذف = إعادة تحميل من Supabase.
const BUCKET_PATH = '/storage/v1/object/public/akdar-audio/';
const PATH_RE = /^[a-zA-Z0-9_-]+(?:\/[a-zA-Z0-9_.-]+)*\.(?:m4a|mp4|aac|mp3)$/;

let _audio = null;       // العنصر الحالي
let _objUrl = null;      // رابط blob الحالي (يُحرَّر عند الانتهاء)
let _btn = null;         // الزر الذي يشغّل الآن
let _token = 0;          // يلغي أي تشغيل قديم متأخر الوصول

/** مسار صالح؟ (يمنع أي قيمة غريبة في extra من أن تصبح رابطًا) */
export function isValidClipPath(path) {
  return typeof path === 'string' && path.length < 160 && PATH_RE.test(path) && !path.includes('..');
}

export function clipUrl(path) {
  if (path.startsWith(AUDIO_PREFIX)) return secondaryClipUrl(path);   // مخزَّن في المشروع الاحتياطي
  return `${SUPABASE_URL}${BUCKET_PATH}${path}`;
}

function _setBtnState(btn, state) {
  if (!btn) return;
  btn.classList.toggle('is-loading', state === 'loading');
  btn.classList.toggle('is-playing', state === 'playing');
  btn.setAttribute('aria-pressed', state === 'playing' ? 'true' : 'false');
}

function _release() {
  if (_audio) { try { _audio.pause(); } catch { /* */ } _audio.removeAttribute('src'); _audio.load?.(); _audio = null; }
  if (_objUrl) { URL.revokeObjectURL(_objUrl); _objUrl = null; }
  _setBtnState(_btn, 'idle');
  _btn = null;
}

export function stopClip() {
  _token++;
  _release();
}

/** يرجع Blob المقطع من الكاش، أو من الشبكة (ويخزّنه). null لو تعذّر. */
async function _getBlob(path) {
  const href = clipUrl(path);
  let cache = null;
  try { cache = await caches.open(CLIPS_CACHE); } catch { /* متصفح بلا Cache API */ }
  if (cache) {
    const hit = await cache.match(href).catch(() => null);
    if (hit) return hit.blob();
  }
  if (typeof navigator !== 'undefined' && navigator.onLine === false) return null;
  // fetchObject: لو فشل المشروع الأصلي (حجب/حصة/تعطّل) جُرّب الآخر بالمسار نفسه (الكاش يبقى بمفتاح الرابط الأصلي)
  const res = await fetchObject(href, { mode: 'cors', credentials: 'omit' });
  if (!res.ok) return null;
  if (cache) {
    const first = res.clone();
    try {
      await cache.put(href, first);
    } catch { /* امتلاء الجهاز: المقطع يُشغَّل في كل حال، ولا نحذف ما هو محفوظ */ }
  }
  return res.blob();
}

/** تحميل مقطع في الخلفية دون تشغيله (لمقطع السؤال التالي في اللعبة لاحقًا) */
export function prefetchClip(path) {
  if (!isValidClipPath(path)) return;
  _getBlob(path).catch(() => {});
}

async function _toast(msg) {
  try { (await import('./toast.js')).showToast(msg, 'info', 2600); } catch { /* */ }
}

/** يشغّل المقطع. الضغط على الزر الذي يشغّل الآن يوقفه. */
export async function playClip(path, btn = null) {
  if (!isValidClipPath(path)) return;
  if (btn && btn === _btn && btn.classList.contains('is-playing')) { stopClip(); return; }

  stopClip();
  const my = ++_token;
  _btn = btn;
  _setBtnState(btn, 'loading');

  try {
    const blob = await _getBlob(path);
    if (my !== _token) return; // ضغطة أحدث ألغت هذه
    if (!blob) {
      _release();
      _toast('الصوت يحتاج نت أول مرة');
      return;
    }
    _objUrl = URL.createObjectURL(blob);
    _audio = new Audio(_objUrl);
    _audio.preload = 'auto';
    _audio.addEventListener('ended', () => { if (my === _token) _release(); });
    _audio.addEventListener('error', () => { if (my === _token) { _release(); _toast('تعذّر تشغيل المقطع'); } });
    await _audio.play();
    if (my === _token) _setBtnState(btn, 'playing');
  } catch (err) {
    if (my !== _token) return;
    _release();
    // NotAllowedError = المتصفح رفض التشغيل التلقائي؛ الضغطة المباشرة لا تصل هنا عادةً
    if (err?.name !== 'AbortError') _toast(navigator.onLine === false ? 'الصوت يحتاج نت أول مرة' : 'تعذّر تشغيل المقطع');
  }
}

// ─── زر الصوت ─────────────────────────────────────────────────────
const _ICON = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><path d="M15.54 8.46a5 5 0 0 1 0 7.07"></path><path d="M19.07 4.93a10 10 0 0 1 0 14.14"></path></svg>';

/** HTML الزر — فارغ لو لا مقطع صالح (فلا زر). المسار قيمة مصفّاة بـ regex فآمنة في الـattribute. */
export function clipButtonHtml(path, label = 'استمع للنطق') {
  if (!isValidClipPath(path)) return '';
  // الأيقونة داخل دائرة + كلمة صريحة تحتها («استمع» ← «إيقاف» أثناء التشغيل) ليُعرف أنه زر وأنه نطق صوتي.
  // الكلمة تظهر فقط في بطاقات آنداندي (CSS) وتُخفى في بقية المواضع.
  return `<button type="button" class="clip-btn" data-clip="${path}" aria-label="${label}" aria-pressed="false"><span class="clip-btn__icon">${_ICON}</span><span class="clip-btn__label" aria-hidden="true"><span class="clip-btn__t clip-btn__t--idle">استمع</span><span class="clip-btn__t clip-btn__t--on">إيقاف</span></span></button>`;
}

/** بديل خامد لزر الصوت لما الكلمة بلا تسجيل — يحجز نفس المكان فتتطابق كل البطاقات (غير قابل للضغط/التركيز) */
export function clipOffHtml() {
  return `<span class="clip-btn clip-btn--off" role="img" aria-label="لا يوجد تسجيل صوتي" title="لا يوجد تسجيل صوتي"><span class="clip-btn__icon">${_ICON}</span><span class="clip-btn__label" aria-hidden="true"><span class="clip-btn__t clip-btn__t--idle">لا صوت</span></span></span>`;
}

/** ربط تفويضي واحد لكل حاوية — يشتغل مع أي أزرار تُرسم لاحقًا داخلها */
export function bindClipButtons(root) {
  if (!root || root.__clipBound) return;
  root.__clipBound = true;
  root.addEventListener('click', (e) => {
    const btn = e.target.closest?.('.clip-btn[data-clip]');
    if (!btn || !root.contains(btn)) return;
    e.preventDefault();
    e.stopPropagation();
    playClip(btn.dataset.clip, btn);
  });
}
