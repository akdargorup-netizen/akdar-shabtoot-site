// js/shared/arabic-search.js — شبتوت بحري
// ══════════════════════════════════════════════════════════════
//  محرّك البحث المرن المشترك — مصدر واحد لكل بحث في التطبيق
//  (الذكاء الاصطناعي، دليل الاتصال، قاموس آنداندي، فهرس السور).
//
//  ما يفعله:
//   • تطبيع عربي: يتجاهل التشكيل والتطويل واختلاف الهمزات (أ إ آ ٱ)،
//     والتاء المربوطة/الهاء، والألف المقصورة/الياء، وياء/كاف الفارسية،
//     ويوحّد الأرقام الهندية والفارسية إلى لاتينية.
//   • تطبيع لاتيني (للحروف اللاتينية في آنداندي): يشيل العلامات
//     (Sērēn = seren) ويدمج تكرار الحرف (Sereen = Seren)، ويتجاهل
//     الفواصل والرموز (Ai / Aigo).
//   • بحث متعدد الكلمات بأي ترتيب: "احمد علي" تجد "علي احمد".
//   • يتجاهل "ال" التعريف في أول الكلمة ("الصيدلية" = "صيدلية").
//   • يتسامح مع المسافة: "عبدالله" = "عبد الله".
//   • يتسامح مع الأخطاء الإملائية البسيطة (حرف زائد/ناقص/مبدّل)
//     للكلمات من ٤ أحرف فأكثر.
//   • ترتيب النتائج: تطابق تام > بداية الكلمة > داخل الكلمة > تقريبي.
//
//  الواجهة:
//   prepareQuery(text)   → كائن استعلام جاهز (مرة واحدة لكل ضغطة)
//   buildKey(...parts)   → مفتاح بحث مطبّع لعنصر (يُخزَّن في data-search)
//   scoreKey(key, pq)    → 0 = لا تطابق، وأعلى = أفضل
//   scoreText(text, pq)  → نفس scoreKey لنص خام (بيطبّعه أولًا)
//   matchesKey / matchesText → true/false
// ══════════════════════════════════════════════════════════════

const AR_INDIC = '٠١٢٣٤٥٦٧٨٩';
const FA_INDIC = '۰۱۲۳۴۵۶۷۸۹';

/** تطبيع نص (عربي/لاتيني) للمقارنة — لا يمس النص المعروض للمستخدم */
export function normalizeText(input) {
  return String(input ?? '')
    .normalize('NFD')
    // علامات لاتينية مركّبة (ē → e) + تشكيل عربي + تطويل + علامات قرآنية صغيرة
    .replace(/[\u0300-\u036F\u064B-\u065F\u0670\u06D6-\u06ED\u0640]/g, '')
    .replace(/[٠-٩]/g, (d) => String(AR_INDIC.indexOf(d)))
    .replace(/[۰-۹]/g, (d) => String(FA_INDIC.indexOf(d)))
    .replace(/[أإآٱ]/g, 'ا')
    .replace(/[ىیئ]/g, 'ي')
    .replace(/ؤ/g, 'و')
    .replace(/ة/g, 'ه')
    .replace(/ک/g, 'ك')
    .toLowerCase()
    // دمج تكرار الحرف اللاتيني فقط (Sereen → seren) — العربية لا تتأثر
    .replace(/([a-z])\1+/g, '$1')
    // أي رمز/علامة ترقيم → مسافة
    .replace(/[^\p{L}\p{N}]+/gu, ' ')
    .trim();
}

/** يشيل "ال" التعريف (و"وال") من أول الكلمة لو فضل ٣ أحرف فأكثر */
function stripAl(word) {
  if (word.startsWith('وال') && word.length - 3 >= 3) return word.slice(3);
  if (word.startsWith('ال')  && word.length - 2 >= 3) return word.slice(2);
  return word;
}

/** مسافة التحرير (Damerau المبسّطة: حذف/إضافة/استبدال/تبديل متجاورين) */
function editDistance(a, b, max) {
  if (a === b) return 0;
  const la = a.length, lb = b.length;
  if (Math.abs(la - lb) > max) return max + 1;
  let prev2 = null;
  let prev = Array.from({ length: lb + 1 }, (_, j) => j);
  for (let i = 1; i <= la; i++) {
    const cur = [i];
    let rowMin = i;
    for (let j = 1; j <= lb; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      let v = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost);
      if (prev2 && i > 1 && j > 1 && a[i - 1] === b[j - 2] && a[i - 2] === b[j - 1]) {
        v = Math.min(v, prev2[j - 2] + 1);
      }
      cur[j] = v;
      if (v < rowMin) rowMin = v;
    }
    if (rowMin > max) return max + 1;
    prev2 = prev;
    prev = cur;
  }
  return prev[lb];
}

// ─── مرادفات الخدمات (تُستعمل كبدائل بدرجة أقل من التطابق المباشر) ──────
// مكتوبة بصيغتها الأصلية وتُطبَّع وقت التحميل. قصدنا ألفاظ الخدمات الشائعة
// في دليل الاتصال فقط — أضف مجموعة جديدة هنا لو ظهرت حاجة.
const SYNONYM_GROUPS = [
  ['دكتور', 'طبيب', 'طبيبة', 'استشاري', 'اطباء'],
  ['صيدلية', 'صيدلي', 'دواء', 'ادوية'],
  ['اسعاف', 'طوارئ', 'مستشفى', 'عاجل'],
  ['كهربائي', 'كهرباء', 'كهربجي'],
  ['سباك', 'سباكة', 'مواسير'],
  ['نجار', 'نجارة'],
  ['حداد', 'حدادة'],
  ['سواق', 'سائق', 'تاكسي', 'مواصلات'],
  ['مسجد', 'جامع', 'امام'],
  ['مدرسة', 'معلم', 'مدرس', 'تعليم'],
  ['بقالة', 'دكان', 'متجر'],
];
const _synMap = new Map();
SYNONYM_GROUPS.forEach((group) => {
  const norm = group.map((w) => stripAl(normalizeText(w)));
  norm.forEach((w) => _synMap.set(w, norm.filter((x) => x !== w)));
});

// ─── تجهيز الاستعلام ─────────────────────────────────────────────

export function prepareQuery(text) {
  const norm = normalizeText(text);
  const tokens = norm.split(' ').filter(Boolean).map((t) => {
    const stripped = stripAl(t);
    return {
      raw: t,
      stripped,
      isNumber: /^\d+$/.test(t),
      alts: (_synMap.get(stripped) || []).map((a) => ({ raw: a, stripped: a, isNumber: false })),
    };
  });
  return {
    isEmpty: tokens.length === 0,
    norm,
    tokens,
    compact: tokens.map((t) => t.raw).join(''),
  };
}

// ─── مفاتيح العناصر ──────────────────────────────────────────────

/** مفتاح بحث مطبّع من عدة حقول (الفارغ والـnull يُتجاهل) */
export function buildKey(...parts) {
  return normalizeText(parts.filter((p) => p != null && p !== '').join(' '));
}

const _wordsCache = new Map();
function wordsOf(key) {
  let entry = _wordsCache.get(key);
  if (!entry) {
    const words = key.split(' ').filter(Boolean).map((w) => ({ w, s: stripAl(w) }));
    entry = { words, compact: words.map((x) => x.w).join('') };
    if (_wordsCache.size > 3000) _wordsCache.clear();
    _wordsCache.set(key, entry);
  }
  return entry;
}

// ─── التقييم ─────────────────────────────────────────────────────

function scoreWord(tok, w, s) {
  const t = tok.raw;
  const ts = tok.stripped;

  if (t === w || t === s || ts === w || ts === s) return 4;
  if (w.startsWith(ts) || s.startsWith(ts) || w.startsWith(t)) return 3;

  // الحرف الواحد: بداية الكلمة فقط، والأرقام: تطابق/بداية/احتواء بدون تقريب
  if (t.length < 2) return 0;
  if (w.includes(ts) || w.includes(t)) return 2;
  if (tok.isNumber) return 0;

  // تقريبي: خطأ إملائي بسيط في كلمة كاملة أو أثناء الكتابة (بداية الكلمة)
  // (العربية من ٤ أحرف، واللاتينية من ٥ — الكلمات اللاتينية أقصر فالتقريب فيها مزعج)
  const minFuzzy = /[a-z]/.test(t) ? 5 : 4;
  if (t.length >= minFuzzy) {
    const max = t.length >= 9 ? 2 : 1;
    if (editDistance(ts, s, max) <= max || editDistance(t, w, max) <= max) return 1;
    if (w.length > t.length && editDistance(t, w.slice(0, t.length), 1) <= 1) return 1;
  }
  return 0;
}

/** كل كلمات الاستعلام لازم تتطابق (بأي ترتيب). 0 = لا تطابق */
export function scoreKey(key, pq) {
  if (!pq || pq.isEmpty || !key) return 0;
  const { words, compact } = wordsOf(key);

  let total = 0;
  let allMatched = true;
  for (const tok of pq.tokens) {
    let best = 0;
    for (const { w, s } of words) {
      let sc = scoreWord(tok, w, s);
      for (const alt of tok.alts) {
        // بديل مرادف: أعلى درجة له ٢ (أقل من تطابق الكلمة الأصلية)
        const a = Math.min(scoreWord(alt, w, s), 2);
        if (a > sc) sc = a;
      }
      if (sc > best) best = sc;
      if (best === 4) break;
    }
    if (!best) { allMatched = false; break; }
    total += best;
  }
  if (allMatched) return total;

  // تسامح المسافة: "عبد الله" ↔ "عبدالله"، و"ابو بكر" ↔ "ابوبكر"
  if (pq.compact.length >= 3 && compact.includes(pq.compact)) return 2;
  return 0;
}

export function scoreText(text, pq) {
  return scoreKey(normalizeText(text), pq);
}

export function matchesKey(key, pq)   { return scoreKey(key, pq) > 0; }
export function matchesText(text, pq) { return scoreText(text, pq) > 0; }
