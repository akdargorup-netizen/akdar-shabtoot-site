// js/shared/comment-hearts.js — شبتوت بحري
// ═══════════════════════════════════════════════════════════════════
//  قلب التعليق (صندوق الأفكار + المناسبات): تلوين محلي فقط على الجهاز.
//  لا كتابة في قاعدة البيانات، لا عدّاد، لا إشعار لصاحب التعليق، ولا قراءات.
//  (قرار المرحلة المجانية — لاحقًا لو أردنا إعجابات حقيقية نعيد استخدام
//   toggleOccasionCommentLike/toggleIdeaCommentLike الأصلية من التاريخ.)
// ═══════════════════════════════════════════════════════════════════

const KEY = 'akdar_comment_hearts';
const MAX = 500; // سقف معقول للتخزين المحلي (الأحدث)

function _read() {
  try {
    const raw = JSON.parse(localStorage.getItem(KEY) || '[]');
    return new Set(Array.isArray(raw) ? raw : []);
  } catch {
    return new Set();
  }
}

const _k = (kind, parentId, commentId) => `${kind}:${parentId}:${commentId}`;

export function isHearted(kind, parentId, commentId) {
  return _read().has(_k(kind, parentId, commentId));
}

/** يبدّل القلب محليًا ويرجّع الحالة الجديدة (true = ملوّن). */
export function toggleHeart(kind, parentId, commentId) {
  const set = _read();
  const key = _k(kind, parentId, commentId);
  const liked = !set.has(key);
  if (liked) set.add(key); else set.delete(key);
  try { localStorage.setItem(KEY, JSON.stringify([...set].slice(-MAX))); } catch { /* تخزين ممتلئ */ }
  return liked;
}

/** يطبّق حالة القلب المحلية على تعليق قادم من المحوّل (العدّاد دائمًا صفر). */
export function applyHeart(comment, kind, parentId, commentId, uid) {
  const hearted = !!uid && isHearted(kind, parentId, commentId);
  return { ...comment, likedBy: hearted ? [uid] : [], likesCount: 0 };
}
