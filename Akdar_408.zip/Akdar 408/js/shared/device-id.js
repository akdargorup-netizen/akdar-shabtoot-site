// shared/device-id.js
// ═══════════════════════════════════════════════════════════════════
// معرّف جهاز/جلسة ثابت يُنشأ مرة واحدة ويُحفظ محلياً (localStorage) —
// مش هوية تسجيل دخول ولا مربوط بحساب Google، مجرد بصمة جهاز بسيطة.
// يُستخدم حالياً لميزة "رسالة تجريبية تظهر لجلستي بس" في لوحة إدارة
// الرسائل (admin-notifications.js) عشان المطوّر يقدر يجرّب شكل
// الرسالة بدون ما توصل لأي مستخدم حقيقي.
// ═══════════════════════════════════════════════════════════════════

const KEY = 'shabtoot-device-id';

export function getDeviceId() {
  let id = localStorage.getItem(KEY);
  if (!id) {
    id = (typeof crypto !== 'undefined' && crypto.randomUUID)
      ? crypto.randomUUID()
      : `dev-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
    localStorage.setItem(KEY, id);
  }
  return id;
}
