// js/shared/update-banner.js — شبتوت بحري
// ══════════════════════════════════════════════════════════════
//  شريط "تحديث جديد" — بديل الـ toast القديم (نص تحته خط).
//
//  ليه اتغيّر: الـ toast كان مجرد نص قابل للضغط، وكل مرة SW يبلّغ
//  بتحديث كان يتكدّس toast جديد فوق القديم، وكل ضغطة بتستدعي
//  location.reload() تاني من غير أي حماية — فالضغط المتكرر كان
//  بيعمل reloads متداخلة وبيعلّق التطبيق بعد كام مرة.
//
//  دلوقتي:
//    • نسخة واحدة بس من الشريط مهما جالت رسائل التحديث (singleton).
//    • أول ضغطة تقفل الزر وتبيّن "جاري التحديث…" — الضغطات التانية
//      مالهاش أي أثر (حارس updating).
//    • لو إعادة التحميل العادية ما نجحتش (شبكة بطيئة/نسخة عالقة في
//      الكاش)، بنعمل تحديث "قسري": مسح كاش التطبيق + إلغاء تسجيل الـ
//      service worker + فتح الصفحة برابط جديد — فالضغطة تنجح فعلًا بدل
//      رسالة "حاول مرة أخرى". الرسالة دي بتظهر بس لو الحل القسري نفسه
//      فشل (نادر جدًا).
// ══════════════════════════════════════════════════════════════

const BANNER_ID        = 'update-banner';
const RELOAD_DELAY_MS  = 450;   // وقت قصير عشان المستخدم يشوف حالة "جاري التحديث"
const FORCE_AFTER_MS   = 2500;  // لو الصفحة لسع هنا بعد كده، نلجأ للتحديث القسري
const GIVE_UP_AFTER_MS = 9000;  // آخر شبكة أمان: نرجّع الزر يشتغل

const ICON_REFRESH = `
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
       stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
    <path d="M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/>
    <path d="M3 3v5h5"/>
    <path d="M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16"/>
    <path d="M16 16h5v5"/>
  </svg>`;

let updating = false;

export function showUpdateBanner() {
  if (document.getElementById(BANNER_ID)) return;

  const banner = document.createElement('div');
  banner.id = BANNER_ID;
  banner.className = 'update-banner';
  banner.setAttribute('role', 'status');
  banner.setAttribute('aria-live', 'polite');
  banner.innerHTML = `
    <div class="update-banner__icon">${ICON_REFRESH}</div>
    <div class="update-banner__text">
      <strong class="update-banner__title">تحديث جديد جاهز</strong>
      <span class="update-banner__sub">حدّث الآن لتحصل على أحدث نسخة</span>
    </div>
    <button type="button" class="update-banner__close" aria-label="لاحقًا">
      <svg viewBox="0 0 20 20" fill="none" aria-hidden="true">
        <path d="M5 5l10 10M15 5L5 15" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
      </svg>
    </button>
    <button type="button" class="update-banner__btn">
      <span class="update-banner__spinner" aria-hidden="true"></span>
      <span class="update-banner__btn-label">حدّث الآن</span>
    </button>
  `;
  document.body.appendChild(banner);
  requestAnimationFrame(() => banner.classList.add('update-banner--visible'));

  const btn   = banner.querySelector('.update-banner__btn');
  const label = banner.querySelector('.update-banner__btn-label');

  btn.addEventListener('click', () => applyUpdate(banner, btn, label));
  banner.querySelector('.update-banner__close').addEventListener('click', () => {
    if (updating) return;
    hideBanner(banner);
  });
}

function hideBanner(banner) {
  banner.classList.remove('update-banner--visible');
  setTimeout(() => banner.remove(), 350);
}

// رابط الصفحة الحالية بمعامل جديد يتجاوز أي نسخة عالقة في كاش المتصفح،
// مع الحفاظ على الـ hash (الصفحة اللي كان فيها المستخدم).
function freshUrl() {
  const url = new URL(location.href);
  url.searchParams.set('_u', Date.now().toString(36));
  return url.toString();
}

// تحديث قسري: نمسح كاش التطبيق ونلغي الـ service worker، فالفتح الجاي
// يجيب كل حاجة من الشبكة ويسجّل SW جديد نضيف.
async function forceRefresh() {
  try {
    if ('caches' in window) {
      const keys = await caches.keys();
      // الكاشات الدائمة (صور/صوت/خطوط/قرآن/مكتبات) لا تُمسح: محتواها ثابت بأسماء فريدة، ومسحها
      // يعني إعادة تحميلها من Supabase لكل مستخدم يضغط «تحديث» (نقل مجاني محدود). نمسح كاش النسخة فقط.
      const KEEP = /^(shabtoot-images-|akdar-clips-|shabtoot-fonts-|shabtoot-quran-|shabtoot-thumbs-|shabtoot-firebase-sdk-|shabtoot-supabase-sdk-)/;
      await Promise.all(keys.filter(k => !KEEP.test(k)).map(k => caches.delete(k)));
    }
  } catch { /* نكمل حتى لو فشل */ }
  try {
    const regs = await navigator.serviceWorker?.getRegistrations?.();
    if (regs) await Promise.all(regs.map(r => r.unregister()));
  } catch { /* نكمل */ }
  location.replace(freshUrl());
}

async function applyUpdate(banner, btn, label) {
  if (updating) return;          // ضغطات متكررة = تتجاهل
  updating = true;

  btn.disabled = true;
  banner.classList.add('update-banner--loading');
  label.textContent = 'جاري التحديث…';

  // نطلب من أي نسخة منتظرة/جاري تثبيتها تشتغل الآن (لو مفيش، عادي)
  try {
    const reg = await navigator.serviceWorker?.getRegistration();
    reg?.waiting?.postMessage({ type: 'SKIP_WAITING' });
    reg?.installing?.postMessage({ type: 'SKIP_WAITING' });
  } catch { /* مش حرج — النسخة الجديدة مفعّلة أصلاً غالبًا */ }

  // المحاولة الأولى: إعادة تحميل عادية
  setTimeout(() => location.reload(), RELOAD_DELAY_MS);

  // لو الصفحة لسع هنا (إعادة التحميل علقت أو رجعت لنسخة قديمة) → قسري
  setTimeout(() => {
    if (!document.body.contains(banner)) return;
    forceRefresh();
  }, FORCE_AFTER_MS);

  // آخر شبكة أمان: لو حتى القسري ما نجحش، نرجّع الزر يشتغل
  setTimeout(() => {
    if (!document.body.contains(banner)) return;
    updating = false;
    btn.disabled = false;
    banner.classList.remove('update-banner--loading');
    label.textContent = 'حاول مرة أخرى';
  }, GIVE_UP_AFTER_MS);
}
