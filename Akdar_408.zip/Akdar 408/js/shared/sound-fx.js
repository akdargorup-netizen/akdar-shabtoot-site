// js/shared/sound-fx.js — شبتوت بحري
// ═══════════════════════════════════════════════════════════════════
//  أصوات تفاعل قصيرة جدًا (إعجاب + إرسال تعليق) — مولَّدة برمجيًا بـ
//  Web Audio API، بلا أي ملف صوتي خارجي. نغمات خاصة بأخضر (مش محاكاة
//  لصوت واتساب أو فيسبوك)، فمفيش حجم إضافي على التطبيق ولا تحميل شبكة.
//
//  كل دالة هنا "تحسين" بحت: أي فشل (متصفح قديم، AudioContext مرفوض،
//  إلخ) لازم يتجاهَل بصمت ومايوقفش أي تفاعل حقيقي في الواجهة — عشان
//  كده كل المنطق ملفوف بـ try/catch وبيرجع بهدوء لو مفيش دعم.
//
//  ⚠️ ملحوظة مهمة عن التوقيت: AudioContext بيتولد بحالة "معلّقة"
//  (suspended) لحد أول تفاعل حقيقي من المستخدم بالصفحة كلها، ومحرّك
//  الصوت وقتها بيكون "متجمّد" (currentTime ما بيتقدّمش). لو جدولنا
//  النغمة على .currentTime وقت التعليق قبل ما resume() يخلص، هتتأخر
//  لحد ما المحرك يصحى فعليًا — وده اللي كان بيسبب تأخير بثوانٍ.
//  الحل: نفعّل الـcontext من أول لمسة حقيقية بالتطبيق كله (مش وقت أول
//  إعجاب/تعليق بالذات)، فبحلول وقت أول صوت فعلي يكون المحرك شغّال
//  خالص. ولو لسع بيصحى، ننتظر resume() فعلاً قبل الجدولة بدل ما
//  نجدول على توقيت قديم.
// ═══════════════════════════════════════════════════════════════════

let _ctx = null;

function _createContext() {
  const Ctor = window.AudioContext || window.webkitAudioContext;
  if (!Ctor) return null;
  if (!_ctx) _ctx = new Ctor();
  return _ctx;
}

// تفعيل مبكر: أول لمسة/ضغطة حقيقية في أي مكان بالتطبيق تصحّي المحرك،
// قبل ما يوصل المستخدم لأول زر إعجاب أو تعليق أصلاً. once:true فمفيش
// أي تكلفة بعد أول مرة.
function _warmUp() {
  try {
    const ctx = _createContext();
    if (ctx && ctx.state === 'suspended') ctx.resume().catch(() => {});
  } catch { /* تحسين بس */ }
}
['pointerdown', 'touchstart', 'click'].forEach(evt =>
  document.addEventListener(evt, _warmUp, { once: true, capture: true })
);

// نغمة واحدة قصيرة (envelope صعود سريع/هبوط أسّي ناعم) — لبنة بناء
// لكل الأصوات تحت. gain منخفض عمدًا (نقرة خفيفة مش رنة صاخبة).
// بتفصل نودز نفسها لما تخلص (onended) عشان ما تتراكمش مع كثرة الضغط.
function _tone(ctx, { freq, start, duration, gain = 0.1, type = 'sine' }) {
  const osc = ctx.createOscillator();
  const g = ctx.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, start);
  g.gain.setValueAtTime(0, start);
  g.gain.linearRampToValueAtTime(gain, start + 0.008);
  g.gain.exponentialRampToValueAtTime(0.0001, start + duration);
  osc.connect(g);
  g.connect(ctx.destination);
  osc.onended = () => { osc.disconnect(); g.disconnect(); };
  osc.start(start);
  osc.stop(start + duration + 0.02);
}

// "سويش" قصير — ضجيج أبيض مفلتر بفلتر تردده بينزلق من عالي لواطي
// (زي ورقة بتتطاير/رسالة بتنطلق)، مش نغمتين ثابتتين. ده اللي بيدّي
// إحساس "إرسال" الفعلي بدل إحساس "بدء تسجيل" (اللي بييجي من نغمتين
// صاعدتين منفصلتين — نفس نمط صوت بدء التسجيل الصوتي في أغلب التطبيقات).
function _whoosh(ctx, { start, duration = 0.13, gain = 0.10, freqFrom = 2600, freqTo = 500 }) {
  const size = Math.max(1, Math.floor(ctx.sampleRate * duration));
  const buffer = ctx.createBuffer(1, size, ctx.sampleRate);
  const data = buffer.getChannelData(0);
  for (let i = 0; i < size; i++) data[i] = Math.random() * 2 - 1;

  const noise = ctx.createBufferSource();
  noise.buffer = buffer;

  const filter = ctx.createBiquadFilter();
  filter.type = 'bandpass';
  filter.Q.value = 0.85;
  filter.frequency.setValueAtTime(freqFrom, start);
  filter.frequency.exponentialRampToValueAtTime(Math.max(freqTo, 60), start + duration);

  const g = ctx.createGain();
  g.gain.setValueAtTime(0, start);
  g.gain.linearRampToValueAtTime(gain, start + 0.015);
  g.gain.exponentialRampToValueAtTime(0.0001, start + duration);

  noise.connect(filter);
  filter.connect(g);
  g.connect(ctx.destination);
  noise.onended = () => { noise.disconnect(); filter.disconnect(); g.disconnect(); };
  noise.start(start);
  noise.stop(start + duration + 0.02);
}

// بتشغّل build() فورًا لو المحرك شغّال فعلاً، أو تستنى resume() يخلص
// فعليًا (مش مجرد طلبه) قبل ما تجدول — عشان التوقيت يبقى صحيح دايمًا.
function _playWhenReady(build) {
  const ctx = _createContext();
  if (!ctx) return;
  if (ctx.state === 'running') {
    build(ctx, ctx.currentTime);
    return;
  }
  ctx.resume()
    .then(() => build(ctx, ctx.currentTime))
    .catch(() => {});
}

/** "بوب" إعجاب — نغمة واحدة بانزلاق سريع للحدة لأعلى + شيمر هارمونيك
 *  خفيف متزامن معاها (مش نغمتين منفصلتين صاعدتين بالتتابع). النغمتين
 *  المنفصلتين كانتا بتدّوا إحساس "بدء تسجيل صوتي" (نفس نمط بداية
 *  رسالة صوتية في أغلب التطبيقات) بدل إحساس إعجاب فرحان وخفيف.
 *  الانزلاق المتصل + الشيمر يدّوا بوب واحد مندمج بدل تتابع نغمي.
 *  (تُشغَّل وقت التفعيل بس، مش وقت إلغاء الإعجاب). */
export function playLikeSound() {
  try {
    _playWhenReady((ctx, now) => {
      _pop(ctx, { start: now });
    });
  } catch { /* تحسين بصري بس — أي خطأ هنا بيتجاهَل بصمت */ }
}

function _pop(ctx, { start, duration = 0.16, gain = 0.11 }) {
  // الجسم: نغمة واحدة منزلقة من واطي لعالي بسرعة (بوب/فقاعة)
  const osc = ctx.createOscillator();
  const g = ctx.createGain();
  osc.type = 'sine';
  osc.frequency.setValueAtTime(720, start);
  osc.frequency.exponentialRampToValueAtTime(1500, start + 0.07);
  g.gain.setValueAtTime(0, start);
  g.gain.linearRampToValueAtTime(gain, start + 0.012);
  g.gain.exponentialRampToValueAtTime(0.0001, start + duration);
  osc.connect(g);
  g.connect(ctx.destination);
  osc.onended = () => { osc.disconnect(); g.disconnect(); };
  osc.start(start);
  osc.stop(start + duration + 0.02);

  // الشيمر: هارمونيك عالي خفيف يبدأ متأخر شوية عن الجسم (مش نغمة
  // ثانية منفصلة قائمة بذاتها) — بيدّي بريق للبوب بدل نغمة تانية
  // مستقلة تحس القارئ إنها "نقرة ثانية" في تتابع.
  const shimmer = ctx.createOscillator();
  const sg = ctx.createGain();
  shimmer.type = 'sine';
  shimmer.frequency.setValueAtTime(2200, start + 0.02);
  sg.gain.setValueAtTime(0, start + 0.02);
  sg.gain.linearRampToValueAtTime(gain * 0.45, start + 0.032);
  sg.gain.exponentialRampToValueAtTime(0.0001, start + 0.1);
  shimmer.connect(sg);
  sg.connect(ctx.destination);
  shimmer.onended = () => { shimmer.disconnect(); sg.disconnect(); };
  shimmer.start(start + 0.02);
  shimmer.stop(start + 0.12);
}

/** إرسال تعليق أو رد — سويش قصير (زي ورقة بتتطاير/رسالة بتنطلق) +
 *  نقرة وصول خفيفة في آخره. يوصّف فعل "الإرسال" نفسه، مش نغمتين
 *  صاعدتين ثابتتين (كانت بتحس القارئ إنه صوت بدء تسجيل صوتي). */
export function playCommentSound() {
  try {
    _playWhenReady((ctx, now) => {
      _whoosh(ctx, { start: now, duration: 0.13, gain: 0.10, freqFrom: 2600, freqTo: 500 });
      _tone(ctx, { freq: 1200, start: now + 0.10, duration: 0.06, gain: 0.09 });
    });
  } catch { /* نفس الملحوظة فوق */ }
}

/** تصويت "أؤيد" — نغمتين صاعدتين (interval صاعد واضح، زي جرس تأكيد/نجاح
 *  خفيف) عشان يوحي بالقبول والموافقة. مختلفة عن صوت "بوب" الإعجاب
 *  (بوب واحد منزلق) — هنا نغمتين منفصلتين بالعمد لإحساس "تم التسجيل
 *  بنجاح" (زي صوت إشعار نجاح في أغلب التطبيقات) مش مجرد نقرة تفاعل. */
export function playVoteUpSound() {
  try {
    _playWhenReady((ctx, now) => {
      _tone(ctx, { freq: 660, start: now, duration: 0.10, gain: 0.10, type: 'sine' });
      _tone(ctx, { freq: 990, start: now + 0.075, duration: 0.14, gain: 0.11, type: 'sine' });
    });
  } catch { /* تحسين بصري بس */ }
}

/** تصويت "لا أؤيد" — نغمتين هابطتين، هادية ومحترمة مش نغمة خطأ/رفض
 *  حادة (المستخدم بيعبّر عن رأي مش بيرتكب خطأ). فرق واضح عن صوت
 *  "أؤيد" (هابط بدل صاعد) ومسموع بوضوح. */
export function playVoteDownSound() {
  try {
    _playWhenReady((ctx, now) => {
      // gain أعلى + موجة triangle (هارمونيكات أكتر) وتردد أعلى شوية: النسخة
      // القديمة (sine واطي 370-520Hz بـ0.09) كانت تكاد لا تُسمع على سماعة الموبايل.
      _tone(ctx, { freq: 640, start: now, duration: 0.11, gain: 0.22, type: 'triangle' });
      _tone(ctx, { freq: 440, start: now + 0.08, duration: 0.18, gain: 0.22, type: 'triangle' });
    });
  } catch { /* تحسين بصري بس */ }
}
