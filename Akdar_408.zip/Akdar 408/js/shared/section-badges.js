// js/shared/section-badges.js — شبتوت بحري
// ══════════════════════════════════════════════════════════════
//  عدّادات "جديد" الرقمية (نمط شارة الرسائل) على:
//    • بطاقات الرئيسية: الأخبار، المناسبات، الفعاليات (الشارة في ركن البطاقة العلوي الأيسر)
//    • بطاقة "مصنع الأفكار" في الخدمات + تبويب "الخدمات" في الشريط السفلي
//
//  2026-09-28: كانت نقطة بلا رقم (freshness-badge.css). اتحوّلت لعدّاد
//  لأن الرئيسية كانت "باردة" — الرقم بيقول للمستخدم إن فيه حاجة
//  تستاهل يفتح عشانها، والنقطة كانت أهدى من إنها تشدّه.
//
//  الفكرة: نجيب معرّفات نافذة صغيرة من الأحدث في كل قسم، ونعدّ اللي
//  مش في "آخر مرة شفنا القسم" (content-freshness.js). العدّ بيتم محليًا
//  على القائمة المخزّنة، فبعد ما المستخدم يفتح القسم (markSeen) العدّاد
//  ينزل فورًا من غير أي قراءة تانية من الخادم.
//
//  تكلفة القراءات: الجلب من الخادم بيتم مرة كل TTL_MS بالكتير (مخزّن
//  في localStorage)، مش كل فتحة للرئيسية — عشان ما نرجعش لمشكلة
//  بطء/تكلفة الفتح اللي اتصلحت قبل كده (انظر شرح home.js). ومع
//  Firebase: الأخبار والفعاليات = قراءة واحدة (meta/latest، بيحدّثه
//  النشر من لوحة الإدارة تلقائيًا)، والأفكار والمناسبات ≤١٠ قراءات
//  لكل منهما — انظر آخر firebase-adapter.js.
// ══════════════════════════════════════════════════════════════

import { getRecentContentIds } from '../data/db.js';
import { countNewIds, seedIfFirstVisit, SEEN_EVENT } from './content-freshness.js';

const SECTIONS   = ['news', 'occasions', 'events', 'ideas'];
const CACHE_KEY  = 'akdar_recent_ids';
const TTL_MS     = 10 * 60 * 1000; // ١٠ دقائق (توفير قراءات: ~٢٢ قراءة لكل تحديث)
const WINDOW_MAX = 10; // لازم يتطابق مع RECENT_WINDOW في الـadapters — "١٠+" كفاية للفت الانتباه

/** عنصر الأيقونة لكل قسم — نوصل منه للبطاقة اللي بتشيل الشارة */
const CARD_TARGETS = {
  news:      '.home-card--news .home-card__icon',
  occasions: '.home-card--community .home-card__icon',
  events:    '.home-card[data-page="events"] .home-card__icon',
  ideas:     '.service-card[data-page="idea-box"] .service-card__icon',
};

let _ids = null;        // { news: [...], ... } — آخر نافذة معروفة
let _inflight = null;

// ─── التخزين المؤقت ───────────────────────────────────────────

function _readCache() {
  try {
    const raw = JSON.parse(localStorage.getItem(CACHE_KEY) || 'null');
    if (raw && raw.ids && typeof raw.t === 'number') return raw;
  } catch { /* تجاهل */ }
  return null;
}

function _writeCache(ids) {
  try { localStorage.setItem(CACHE_KEY, JSON.stringify({ t: Date.now(), ids })); } catch { /* تجاهل */ }
}

// ─── الجلب ────────────────────────────────────────────────────

/** يجلب النوافذ الأحدث (لو الكاش انتهى) ثم يحدّث كل الشارات.
 *  آمن للاستدعاء من أكتر من مكان في نفس الوقت. */
export function refreshSectionBadges({ force = false } = {}) {
  const cached = _readCache();
  if (!_ids && cached) _ids = cached.ids;

  if (!force && cached && Date.now() - cached.t < TTL_MS) {
    applySectionBadges();
    return Promise.resolve();
  }
  if (_inflight) return _inflight;

  _inflight = (async () => {
    const next = { ...(_ids || {}) };
    await Promise.all(SECTIONS.map(async section => {
      try {
        next[section] = (await getRecentContentIds(section)).map(String);
        seedIfFirstVisit(section, next[section]);
      } catch (err) {
        // فشل قسم واحد ما يوقفش الباقي — نسيب آخر قيمة معروفة (أو نتجاهله)
        console.warn(`[SectionBadges] تعذّر جلب "${section}":`, err);
      }
    }));
    _ids = next;
    _writeCache(next);
    applySectionBadges();
  })().finally(() => { _inflight = null; });

  return _inflight;
}

// ─── الرسم ────────────────────────────────────────────────────

function _label(n) {
  return n >= WINDOW_MAX ? `${WINDOW_MAX}+` : String(n);
}

function _setCardBadge(section, n) {
  const icon = document.querySelector(CARD_TARGETS[section]);
  const card = icon?.closest('.home-card, .service-card');
  if (!icon || !card) return;

  // الشارة ابن مباشر للبطاقة، ومكانها ثابت بالـCSS في ركن البطاقة
  // العلوي الأيسر (top/left)، مش على الأيقونة — فما نحتاج أي قياس
  // بالجافاسكريبت. (الأيقونة هنا بس عشان نوصل للبطاقة: lucide بيستبدل
  // عنصر الأيقونة بـsvg، فالعنصر نفسه ما يصلحش يشيل الشارة.)
  let badge = card.querySelector(':scope > .section-badge');
  if (n <= 0) { badge?.remove(); return; }

  const text = _label(n);
  if (!badge) {
    badge = document.createElement('span');
    badge.className = 'section-badge';
    badge.setAttribute('aria-hidden', 'true');
    card.appendChild(badge);
  } else if (badge.textContent === text) {
    return; // نفس الرقم — ما نعيدش أنيميشن الظهور
  }
  badge.textContent = text;
}

function _setNavBadge(n) {
  const el = document.getElementById('services-badge-count');
  if (!el) return;
  if (n <= 0) {
    el.classList.remove('is-visible');
    el.textContent = '';
    return;
  }
  el.textContent = n > 99 ? '99+' : String(n);
  el.classList.add('is-visible');
}

/** يرسم الشارات من القائمة المخزّنة في الذاكرة — من غير أي جلب.
 *  بتتنادى بعد كل رسم للرئيسية/الخدمات (الأيقونات بتتبدّل بـinnerHTML
 *  عند renderIcons فلازم نعيد الإضافة بعدها) وبعد أي markSeen. */
export function applySectionBadges() {
  if (!_ids) {
    const cached = _readCache();
    if (!cached) return;
    _ids = cached.ids;
  }
  const counts = {};
  for (const section of SECTIONS) {
    counts[section] = _ids[section] ? countNewIds(section, _ids[section]) : 0;
    _setCardBadge(section, counts[section]);
  }
  _setNavBadge(counts.ideas);
}

/** ربط التحديث الفوري بعد ما المستخدم يفتح قسم (markSeen) */
export function initSectionBadges() {
  window.addEventListener(SEEN_EVENT, applySectionBadges);
  // رجوع التطبيق للواجهة (من الخلفية) يحدّث العدّادات لو مضت مدة الكاش
  document.addEventListener('visibilitychange', () => { if (!document.hidden) refreshSectionBadges(); });
  refreshSectionBadges();
}
