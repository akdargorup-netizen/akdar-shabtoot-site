// js/shared/app-splash.js — شبتوت بحري
// ══════════════════════════════════════════════════════════════
//  شاشة انتقالية قصيرة بالشعار — تظهر لحظة فتح التطبيق بعد ما شاشة
//  البداية اللي بيولّدها أندرويد/كروم تلقائياً من manifest.json
//  (خلفية داكنة + الأيقونة) تختفي. مش بديل ليها ولا تتحكم في شكلها
//  (ده خارج نطاقنا)، دي شاشة إضافية من عندنا فوق التطبيق، هدفها بس
//  انتقال ناعم بدل قطع مفاجئ لمحتوى الصفحة الرئيسية.
//
//  عنصرها (#app-splash) موجود جاهز في index.html من البداية (مش
//  بيتولّد من هنا) عشان يبان فوراً حتى قبل ما app.js يتحمّل. الملف
//  ده مسؤوليته الوحيدة: يخفيها بعد وقت ثابت قصير — من غير ما ينتظر
//  أي تحميل بيانات حقيقي (render() أول صفحة أصلاً متزامن وبيبان فورًا
//  تحت الشاشة دي، فمفيش داعي نربط الاختفاء بأي حدث تاني).
// ══════════════════════════════════════════════════════════════

// 2026-09-30 (v4): خروج بدائرة تنطبق على الشعار (clip-path) بدل تلاشي بسيط؛ نفس التوقيت.
// 2026-09-29 (v3): شيلنا التوقيع وقصّرنا المدة لـ ~٣٫٢ث + ٠٫٨ث تلاشي، بحركة أحيا.
// 2026-09-28 (v2): الإنترو اتهدّى لونيًا واتطوّل — ظهور تدريجي (الشعار ←
// خط النيل ← الاسم ← التوقيع) ثم انتقال ناعم. المدة ~٤٫٦ ثانية كلها،
// ولمسة على الشاشة بتخطّيها. ما بننتظرش أي تحميل بيانات.
const VISIBLE_MS_MOTION   = 3400; // مدة الظهور قبل ما تبدأ تتلاشى (خط النيل بيكتمل عند ~٢٫٨ث)
const VISIBLE_MS_REDUCED  = 2800; // لو "تقليل الحركة" مفعّل: ثابتة
const FADE_MS             = 800;  // مدة التلاشي نفسها (لازم تتطابق مع CSS)

export function initAppSplash() {
  const splash = document.getElementById('app-splash');
  if (!splash) return;

  let hidden = false;
  const remove = () => splash.remove();

  const hide = () => {
    if (hidden) return;
    hidden = true;
    splash.classList.add('app-splash--hide');
    // transitionend بتتطلق لكل خاصية اتغيّرت (الشاشة + المحتوى الداخلي)،
    // فنسمع بس لتلاشي الشاشة نفسها.
    splash.addEventListener('transitionend', e => { if (e.target === splash) remove(); });
    // شبكة أمان: لو transitionend ما اتطلقتش لأي سبب (مثلاً التبويب راح
    // للخلفية ومتصفح جمّد الرسوم)، نشيلها بره برضه.
    setTimeout(remove, FADE_MS + 400);
  };

  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  // لمسة على الإنترو = تخطّي (مهم بعد ما اتطوّل).
  // ⚠️ الإنترو بيختفي (pointer-events:none) لحظة الـpointerdown، فالـclick
  // اللي بييجي بعد رفع الإصبع كان بيقع على الزر اللي تحته (ضغطة بالغلط).
  // نبلع أي click/touchend لمدة قصيرة بعد التخطّي.
  const skip = () => {
    if (hidden) return;
    hide();
    const until = Date.now() + 600;
    const swallow = e => {
      if (Date.now() > until) { cleanup(); return; }
      e.preventDefault();
      e.stopPropagation();
    };
    const evts = ['click', 'touchend', 'mouseup', 'pointerup'];
    const cleanup = () => evts.forEach(t => document.removeEventListener(t, swallow, true));
    evts.forEach(t => document.addEventListener(t, swallow, true));
    setTimeout(cleanup, 650);
  };
  splash.addEventListener('pointerdown', skip, { once: true });

  if (reducedMotion) {
    setTimeout(hide, VISIBLE_MS_REDUCED);
    return;
  }

  setTimeout(hide, VISIBLE_MS_MOTION);
}
