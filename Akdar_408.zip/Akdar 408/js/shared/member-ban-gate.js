// js/shared/member-ban-gate.js — شبتوت بحري
// ═══════════════════════════════════════════════════════════════════
//  حارس "الحظر الكامل" — رقابة الأعضاء (admin-members.js).
//
//  الحظر الكامل يمنع العضو من استخدام التطبيق بالكامل (كل الصفحات،
//  بما فيها الرئيسية)، لا مجرد التعليق/المشاركة (ده حظر جزئي، مُنفَّذ
//  في db.js/adapters عند كل فعل كتابة). checkFullBan تُستدعى من
//  router.js في بداية كل navigateTo — فحص مركزي واحد يغطي كل تنقّل
//  بالتطبيق، مش بس أول تحميل، عشان لو الحظر حصل والمستخدم فاتح
//  التطبيق بالفعل يتوقف عند أول ضغطة تنقّل.
//
//  ⚠️ الهوية هنا = uid محلي ثابت (auth.js)، فالعضو المحظور يقدر
//  نظريًا يمسح بيانات المتصفح ويطلع uid جديد (زي أي حماية معتمدة على
//  uid محلي في هذا التطبيق — نفس القيد المذكور في requireRealAuth).
//  بعد تفعيل Firebase الحقيقي وربط الحظر بحساب Google المسجّل، الحماية
//  تبقى أقوى بشكل طبيعي بدون تغيير في هذا الملف.
// ═══════════════════════════════════════════════════════════════════

import { getCurrentUser } from '../data/auth.js';
import { getMemberModeration } from '../data/db.js';
import { escapeHtml } from './sanitize.js';

// نفس رقم واتساب المشرف/الرابطة المستخدم في settings-contact.js —
// قناة التواصل الوحيدة المتاحة لعضو محظور (باقي التطبيق مقفول عليه).
const WHATSAPP_NUMBER = '249114436404';

// ═══════════════════════════════════════════════════════════════════
//  محلي أولاً (v386): كان الفحص هنا استعلامًا حيًّا على الشبكة في بداية **كل**
//  navigateTo (تحميل مكتبة Supabase + انتظار المصادقة حتى ٨ ثوانٍ + استعلام بمهلة
//  ١٥ ثانية) — فكل ضغطة تنقّل في التطبيق كانت تنتظر الإنترنت، وبشبكة القرية
//  الضعيفة تتحوّل لتعليق. الآن: آخر حالة معروفة تُحفظ على الجهاز، والتنقل يقرأها
//  فورًا بلا شبكة، والتحديث من السيرفر يجري بالخلفية (بحد أقصى مرة كل ١٠ دقائق).
//  الحظر الجديد يسري خلال هذه المدة ثم يُطبَّق فورًا على الشاشة المفتوحة (حدث
//  akdar:member-ban-changed يلتقطه router.js). أول فحص على جهاز جديد فقط ينتظر
//  لحظة قصيرة (FIRST_CHECK_WAIT_MS) ثم يكمل التطبيق ولا يعلّق.
// ═══════════════════════════════════════════════════════════════════
const BAN_KEY = 'akdar_ban_status_v1';
const BAN_TTL_MS = 2 * 60 * 1000;        // عمر الحالة المحفوظة قبل تجديدها بالخلفية
const RETRY_AFTER_FAIL_MS = 60 * 1000;   // بعد فشل الجلب (شبكة ضعيفة) لا نكرر قبل دقيقة
const FIRST_CHECK_WAIT_MS = 800;         // أول فحص بلا محفوظ: أقصى انتظار

let _refreshing = null;
let _lastFailAt = 0;

function _readBan() {
  try {
    const raw = JSON.parse(localStorage.getItem(BAN_KEY) || 'null');
    if (raw && raw.uid && typeof raw.at === 'number') return raw;
  } catch { /* تجاهل */ }
  return null;
}

function _writeBan(rec) {
  try { localStorage.setItem(BAN_KEY, JSON.stringify(rec)); } catch { /* التخزين اختياري */ }
}

function _refreshBan(uid) {
  if (_refreshing) return _refreshing;
  if (navigator.onLine === false) return Promise.resolve(null);
  if (Date.now() - _lastFailAt < RETRY_AFTER_FAIL_MS) return Promise.resolve(null);

  _refreshing = (async () => {
    const before = _readBan();
    try {
      const mod = await getMemberModeration(uid);
      const rec = { uid, status: mod?.status ?? 'active', reason: mod?.reason ?? '', at: Date.now() };
      _writeBan(rec);
      const wasBanned = before?.uid === uid && before.status === 'banned-full';
      const isBanned = rec.status === 'banned-full';
      if (wasBanned !== isBanned) {
        try { window.dispatchEvent(new CustomEvent('akdar:member-ban-changed', { detail: { banned: isBanned } })); }
        catch { /* بيئة بلا window */ }
      }
      return rec;
    } catch (err) {
      _lastFailAt = Date.now();
      console.warn('[MemberBanGate] تعذّر تجديد حالة الحظر (نكمل بالمحفوظ):', err?.message || err);
      return null;
    }
  })().finally(() => { _refreshing = null; });

  return _refreshing;
}

/**
 * @returns {Promise<{status:'banned-full', reason:string}|null>} سجل
 *   الحظر لو العضو محظور حظرًا كاملاً، أو null لو مسموح له (نشط أو
 *   محظور حظرًا جزئيًا بس — الجزئي بيتصفح عادي، بيتوقف بس عند فعل مشاركة).
 *   لا تنتظر الشبكة أبدًا إلا في أول فحص على الجهاز (ولمدة قصيرة جدًا).
 */
export async function checkFullBan() {
  const user = getCurrentUser();
  if (!user?.uid) return null;

  const saved = _readBan();
  const mine = saved && saved.uid === user.uid ? saved : null;

  if (mine) {
    if (Date.now() - mine.at >= BAN_TTL_MS) _refreshBan(user.uid); // بالخلفية — بلا await
    return mine.status === 'banned-full' ? mine : null;
  }

  // لا حالة محفوظة لهذا الحساب على هذا الجهاز: انتظار قصير ثم نكمل (الجلب يكمل بالخلفية)
  const first = await Promise.race([
    _refreshBan(user.uid),
    new Promise((resolve) => setTimeout(() => resolve(null), FIRST_CHECK_WAIT_MS)),
  ]);
  return first?.status === 'banned-full' ? first : null;
}

// ═══════════════════════════════════════════════════════════════════
//  فحص المشاركة (حظر جزئي أو كامل) — يُستدعى من requireRealAuth() قبل ما
//  يوصل العضو لأي حقل (إضافة فكرة/مناسبة، تعليق، تصويت، إعجاب، تعديل، إبلاغ).
//  يقرأ المحفوظ فورًا؛ ولو أقدم من ٣٠ ثانية ينتظر تجديدًا قصيرًا (حد أقصى ١٫٢ ثانية)
//  عشان الحظر الجديد يظهر قبل فتح الحقول، من غير ما يعلّق بشبكة القرية الضعيفة.
// ═══════════════════════════════════════════════════════════════════
const PARTICIPATION_FRESH_MS = 30 * 1000;
const PARTICIPATION_WAIT_MS = 1200;

/** @returns {Promise<{status:'banned-full'|'banned-partial', reason:string}|null>} */
export async function checkParticipationBan() {
  const user = getCurrentUser();
  if (!user?.uid || user.isAnonymous) return null;

  const saved = _readBan();
  const mine = saved && saved.uid === user.uid ? saved : null;
  let rec = mine;

  if (!mine || Date.now() - mine.at >= PARTICIPATION_FRESH_MS) {
    const fresh = await Promise.race([
      _refreshBan(user.uid),
      new Promise((resolve) => setTimeout(() => resolve(null), PARTICIPATION_WAIT_MS)),
    ]);
    rec = fresh || _readBan();
    if (rec && rec.uid !== user.uid) rec = null;
  }
  return rec && (rec.status === 'banned-full' || rec.status === 'banned-partial') ? rec : null;
}

/** نص الحظر الموحّد للرسائل */
export function banMessage(ban) {
  const full = ban?.status === 'banned-full';
  const reason = (ban?.reason || '').trim();
  const base = full
    ? 'أنت محظور من استخدام التطبيق'
    : 'أنت محظور من المشاركة (التعليق والتصويت والنشر)';
  return `${base}${reason ? ` — السبب: ${reason}` : ''}`;
}

let _banModalCleanup = null;

/** نافذة "أنت محظور" — بدل ما العضو يفتح الحقول ويكتشف عند الإرسال */
export function showBanNotice(ban) {
  _banModalCleanup?.();
  const full = ban?.status === 'banned-full';
  const reason = (ban?.reason || '').trim();
  const waText = encodeURIComponent('السلام عليكم، حسابي محظور من تطبيق أكدار وحابب أستفسر عن السبب.');
  const waLink = `https://wa.me/${WHATSAPP_NUMBER}?text=${waText}`;

  const backdrop = document.createElement('div');
  backdrop.className = 'overlay-backdrop overlay-backdrop--center';
  backdrop.innerHTML = `
    <div class="modal modal--center login-prompt-modal" role="alertdialog" aria-modal="true" aria-label="أنت محظور">
      <div class="modal__handle"></div>
      <div class="modal__body login-prompt-modal__body">
        <div class="login-prompt-modal__icon"><i data-icon="shield-x"></i></div>
        <h3 class="modal__title login-prompt-modal__title">أنت محظور</h3>
        <p class="login-prompt-modal__desc">
          ${full ? 'تم إيقاف حسابك من قبل الإدارة.' : 'تم منعك من التعليق والتصويت والنشر من قبل الإدارة.'}
          ${reason ? `<br><strong>السبب:</strong> ${escapeHtml(reason)}` : ''}
        </p>
      </div>
      <div class="modal__footer">
        <a class="btn btn--primary btn--full" href="${waLink}" target="_blank" rel="noopener">تواصل مع الإدارة</a>
        <button class="btn btn--ghost btn--full" type="button" data-ban-close>حسنًا</button>
      </div>
    </div>`;
  document.body.appendChild(backdrop);
  import('./icons.js').then(({ renderIcons }) => renderIcons(backdrop)).catch(() => {});

  const close = () => { backdrop.remove(); _banModalCleanup = null; };
  _banModalCleanup = close;
  backdrop.querySelector('[data-ban-close]')?.addEventListener('click', close);
  backdrop.addEventListener('click', (e) => { if (e.target === backdrop) close(); });
}

/**
 * بوابة جاهزة للاستخدام: true = مسموح يكمل، false = محظور (النافذة ظهرت).
 */
export async function requireNotBanned() {
  const ban = await checkParticipationBan();
  if (!ban) return true;
  showBanNotice(ban);
  return false;
}

/**
 * شاشة القفل الكاملة — تحل محل محتوى الصفحة بالكامل (الهيدر والناف
 * السفلي بيتخفوا من نفس المكان اللي بيستدعي الدالة دي، مش من هنا).
 * @param {{ reason?: string }} ban
 */
export function renderBannedScreen(ban) {
  const reason = (ban?.reason || '').trim();
  const waText = encodeURIComponent('السلام عليكم، حسابي محظور من تطبيق أخضر شبتوت بحري وحابب أستفسر عن السبب.');
  const waLink = `https://wa.me/${WHATSAPP_NUMBER}?text=${waText}`;

  return `
    <section class="page not-found-page banned-page">
      <div class="not-found-inner">
        <div class="banned-page__icon"><i data-icon="shield-x"></i></div>
        <h2 class="not-found-title">أنت محظور</h2>
        <p class="not-found-desc">
          تم إيقاف وصولك للتطبيق من قبل الإدارة.
          ${reason ? `<br><strong>السبب:</strong> ${escapeHtml(reason)}` : ''}
        </p>
        <a class="btn btn--primary" href="${waLink}" target="_blank" rel="noopener">
          <i data-icon="message-circle"></i>
          تواصل مع الإدارة
        </a>
      </div>
    </section>
  `;
}
