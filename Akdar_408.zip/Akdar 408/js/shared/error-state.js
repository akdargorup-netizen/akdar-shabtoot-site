// js/shared/error-state.js — شبتوت بحري
// ══════════════════════════════════════════════════════════════
//  حالة فشل تحميل موحّدة لكل قسم بيانات يعتمد على db.js.
//  المشكلة اللي بيحلّها هذا الملف: كل صفحة كانت تكتب بنفسها
//  <p class="error-state">ما قدرنا نحمّل...</p> — نص واحد ثابت
//  سواء كان السبب انقطاع نت أو أي خطأ تاني، من غير أيقونة ومن
//  غير أي طريقة لإعادة المحاولة. في بيئة نت ضعيف/متقطع زي بيئة
//  البلد، حالة "معندناش نت دلوقتي" لازم تتفرّق بصرياً ولفظياً عن
//  "صار خطأ" — وتدي المستخدم فعل يقدر يعمله (إعادة تحميل) بدل ما
//  يوصل لطريق مسدود.
// ══════════════════════════════════════════════════════════════

import { isTripped, retryInMs } from '../data/adapters/rate-guard.js';

// ── إعادة محاولة تلقائية صامتة ────────────────────────────────
// لو القراءات موقوفة مؤقتًا (قاطع الحماية)، أو انقطع النت ثم رجع: بدل ما يضغط المستخدم الزر ويفشل،
// ننتظر لحظة الاستئناف ونضغط "إعادة المحاولة" عنه في كل حالة فشل ما زالت معروضة.
// الصفحات اللي تعرض errorState تربط الزر بدالة التحميل (bindErrorRetry) فيعيد الجلب والرسم وحده.
let _autoTimer = null;

function _clickPendingRetries() {
  document.querySelectorAll('.error-state__retry').forEach((btn) => {
    if (btn.isConnected && !btn.disabled) btn.click();
  });
}

function _armAutoRetry() {
  if (_autoTimer) return;
  const wait = Math.max(retryInMs(), 0) + 800 + Math.random() * 3000; // هامش + عشوائية صغيرة كي لا تعود الأجهزة معًا
  _autoTimer = setTimeout(() => {
    _autoTimer = null;
    if (navigator.onLine === false) return; // بلا نت: ينتظر حدث online
    _clickPendingRetries();
  }, wait);
}

try {
  window.addEventListener('akdar:rate-limited', _armAutoRetry);
  window.addEventListener('online', () => setTimeout(_clickPendingRetries, 600 + Math.random() * 8000)); // انقطاع عام يعيد آلاف الأجهزة معًا: نفرّقها
} catch { /* بيئة بلا window */ }

/**
 * يبني HTML لحالة فشل التحميل، مع تفرقة تلقائية بين الانقطاع
 * والخطأ العام حسب navigator.onLine وقت العرض.
 *
 * الرسالة دايمًا بصيغة "جرّب تاني / اتأكد من الشبكة" — مش "المشكلة
 * عندنا"، لأن الغالبية العظمى من حالات الفشل دي أصلاً سببها نت
 * ضعيف أو متقطع عند المستخدم، مش خطأ في التطبيق. تمرير subject
 * (اسم القسم: "الأخبار"، "المناسبات"...) كفاية عادةً؛ message
 * الكاملة تُستخدم فقط للحالات الخاصة اللي محتاجة صياغة مختلفة.
 *
 * @param {object} [opts]
 * @param {string} [opts.subject] اسم القسم اللي فشل تحميله (تُبنى منه رسالة ذكية جاهزة)
 * @param {string} [opts.message] رسالة كاملة مخصّصة (تتجاوز subject لو الاتنين اتمرروا)
 * @param {string} [opts.code] كود الخطأ التقني (مثل unavailable) — يظهر صغيرًا تحت الرسالة للتشخيص
 * @returns {string}
 */
export function errorState({ subject, message, code } = {}) {
  const offline = typeof navigator !== 'undefined' && !navigator.onLine;

  const icon  = offline ? 'wifi-off' : 'refresh-cw';
  const paused = !offline && isTripped(); // القراءات موقوفة مؤقتًا — لا نذكر السبب للمستخدم أبدًا
  const title = offline ? 'مافي اتصال بالإنترنت هسّع' : (paused ? 'المحتوى سيصل قريبًا' : 'المحتوى لسع ما وصل');

  let desc;
  if (paused) {
    _armAutoRetry();
    desc = 'لحظات ويظهر تلقائيًا — ما تحتاج تعمل شيء.';
  } else if (offline) {
    desc = 'هذا الجزء محتاج اتصال بالنت — تحقق من شبكتك وحاول تاني.';
  } else if (message) {
    desc = message;
  } else if (subject) {
    desc = `جرّب تفتح ${subject} من جديد — غالبًا السبب ضعف الشبكة، خلّها تستقر وجرّب تاني.`;
  } else {
    desc = 'جرّب تفتح الصفحة دي من جديد — غالبًا السبب ضعف الشبكة، خلّها تستقر وجرّب تاني.';
  }

  return `
    <div class="error-state" role="alert">
      <i class="error-state__icon" data-lucide="${icon}"></i>
      <p class="error-state__title">${title}</p>
      <p class="error-state__desc">${desc}</p>
      ${code ? `<p class="error-state__code" dir="ltr" style="font-size:11px;opacity:.55;margin:0 0 8px">${String(code).replace(/[^\w:./ -]/g, '').slice(0, 60)}</p>` : ''}
      <button class="btn btn--secondary btn--sm error-state__retry" type="button" data-action="retry">
        <i data-lucide="refresh-cw"></i>
        <span>إعادة المحاولة</span>
      </button>
    </div>
  `;
}

/**
 * يربط زر "إعادة المحاولة" داخل حاوية بحالة errorState() بدالة إعادة تحميل.
 * تُستدعى مرة وحدة بس (once) عشان لو المستخدم ضغط، والتحميل الجديد
 * رسم error-state تاني، الاستدعاء الجاي لـ_load هو اللي بيربط زر جديد.
 *
 * @param {Element} container العنصر اللي جوّاه error-state
 * @param {() => void} handler دالة إعادة التحميل (نفس دالة _load الأصلية عادةً)
 */
export function bindErrorRetry(container, handler) {
  container?.querySelector('[data-action="retry"]')
    ?.addEventListener('click', handler, { once: true });
}
