// js/shared/content-freshness.js — شبتوت بحري
// ═══════════════════════════════════════════════════════════════════
//  تتبّع "فيه جديد؟" لكل قسم (أخبار/مناسبات/أفكار...) — نقطة على
//  بطاقة الرئيسية + شارة "جديد" على العنصر نفسه جوّه القائمة.
//
//  ليه بالمعرّف (ID) مش بالتاريخ؟ الأقسام دي مش كلها عندها حقل تاريخ
//  موثوق نقدر نرتّب أو نقارن بيه: الأخبار عندها publishedAt،
//  المناسبات/الأفكار عندها createdAt، لكن الفعاليات مرتّبة بمقارنة
//  نصّية لمعرّفها مش تاريخ حقيقي، ومقالات التاريخ/الرابطة أصلاً
//  مالهاش أي ترتيب زمني (محتوى مرجعي بيتضاف بين حين وآخر مش تغذية
//  زمنية). التتبّع بالمعرّف بيشتغل صح مهما كان شكل البيانات: أي
//  عنصر معرّفه مش موجود في "آخر مرة شُفنا فيها القسم دا" يبقى جديد،
//  من غير ما نحتاج نفترض حاجة عن شكل التواريخ.
//
//  التخزين محلي بالكامل (localStorage) — نفس فلسفة باقي تفضيلات
//  الجهاز في التطبيق (حجم الخط، الثيم). أول زيارة لأي قسم (مفيش
//  سجل محفوظ بعد) ما بنعتبرش كل المحتوى القديم "جديد" — بنسجّل
//  الوضع الحالي بصمت ونبدأ المقارنة من الزيارة اللي بعدها.
// ═══════════════════════════════════════════════════════════════════

const _STORAGE_PREFIX = 'akdar_seen_';
const _MAX_TRACKED_IDS = 300; // سقف تخزين معقول حتى لأكثر الأقسام نشاطًا

function _key(section) {
  return _STORAGE_PREFIX + section;
}

function _readSeen(section) {
  try {
    const raw = localStorage.getItem(_key(section));
    return raw ? new Set(JSON.parse(raw)) : null; // null = لسع ما زرناش القسم دا خالص
  } catch {
    return null;
  }
}

function _writeSeen(section, ids) {
  try {
    const capped = ids.slice(-_MAX_TRACKED_IDS);
    localStorage.setItem(_key(section), JSON.stringify(capped));
  } catch {
    // التخزين المحلي مش متاح (خصوصية متصفح، أو الذاكرة ممتلئة) —
    // نتجاهل بهدوء؛ أسوأ حالة إن ميزة "جديد" ما بتشتغلش، مش إننا نكسر الصفحة.
  }
}

/**
 * أي معرّفات من القائمة الحالية "جديدة" (مش موجودة في آخر زيارة مسجّلة)؟
 * @param {string} section مفتاح القسم — 'news' / 'occasions' / 'ideas' ...
 * @param {Array<{id: string|number}>} items القائمة الحالية المجلوبة من الخادم
 * @returns {Set<string>} معرّفات العناصر الجديدة (كنصوص)
 */
export function getNewIds(section, items) {
  const seen = _readSeen(section);
  if (!seen) return new Set(); // أول زيارة — مفيش "جديد"، بس سجّل الوضع الحالي
  return new Set(items.filter(it => !seen.has(String(it.id))).map(it => String(it.id)));
}

/** سجّل القائمة الحالية كـ"مشوفة" — يُستدعى بعد ما المستخدم يفتح صفحة
 *  القسم فعليًا ويشوف القائمة (مش مجرد نظرة على نقطة الرئيسية).
 *  بيبلّغ الشارات (section-badges.js) عبر حدث عشان تنزل فورًا. */
export function markSeen(section, items) {
  _writeSeen(section, items.map(it => String(it.id)));
  try { window.dispatchEvent(new CustomEvent(SEEN_EVENT, { detail: { section } })); } catch { /* بيئة بلا window */ }
}

/** اسم الحدث اللي بيتطلق بعد أي markSeen() */
export const SEEN_EVENT = 'akdar-content-seen';

/** كم معرّف من القائمة دي جديد (مش في آخر زيارة مسجّلة)؟ — للعدّاد الرقمي.
 *  @param {string} section
 *  @param {Array<string|number>} ids معرّفات الأحدث فقط (نافذة صغيرة، مش القسم كله)
 *  @returns {number} */
export function countNewIds(section, ids) {
  const seen = _readSeen(section);
  if (!seen) return 0; // مفيش أساس مقارنة — انظر seedIfFirstVisit
  return ids.reduce((n, id) => n + (seen.has(String(id)) ? 0 : 1), 0);
}

/** أول مرة نشوف القسم دا على الجهاز (مفيش سجل بعد): نسجّل الوضع
 *  الحالي كأساس بصمت، فالعدّاد يبدأ من الصفر ويعدّ اللي ينزل بعد كده
 *  بس — بدل ما يظهر "٣٠ جديد" لمستخدم جديد على محتوى قديم. */
export function seedIfFirstVisit(section, ids) {
  if (_readSeen(section)) return;
  _writeSeen(section, ids.map(String));
}

