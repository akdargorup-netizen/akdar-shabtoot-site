// js/shared/relative-time.js — شبتوت بحري
// دالة نقية (تاريخ ISO → نص نسبي بالعربي) — اتنقلت هنا من local-adapter.js
// عشان firebase-adapter ما يضطرش يحمّل ملف البيانات التجريبية (~105KB)
// لأجل دالة واحدة. local-adapter.js لسه يعيد تصديرها للتوافق.

/** يحوّل توقيت ISO لنص نسبي بالعربي — يُحسب وقت الطلب لا وقت التخزين */
export function formatRelativeTime(iso) {
  if (!iso) return '';
  // يقبل كمان Timestamp من Firestore (toDate) كشبكة أمان
  if (typeof iso.toDate === 'function') iso = iso.toDate().toISOString();
  const diffMs = Date.now() - new Date(iso).getTime();
  const min    = Math.floor(diffMs / 60000);
  const hour   = Math.floor(diffMs / 3600000);
  const day    = Math.floor(diffMs / 86400000);

  if (min < 1)   return 'الآن';
  if (min < 60)  return `منذ ${min} دقيقة`;
  if (hour < 24) return `منذ ${hour} ساعة`;
  if (day === 1) return 'أمس';
  if (day < 7)   return `منذ ${day} أيام`;

  return new Date(iso).toLocaleDateString('ar-EG', { day: 'numeric', month: 'long' });
}
