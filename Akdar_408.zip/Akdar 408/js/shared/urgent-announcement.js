// js/shared/urgent-announcement.js — شبتوت بحري
// ══════════════════════════════════════════════════════════════
//  عرض النداء الإنساني العاجل (متبرع بالدم / حالة مرضية مستعجلة)
//  في 3 أماكن: الرئيسية (بدل صورة الهيرو)، الأخبار (بدل/فوق الخبر
//  العاجل)، بيت المناسبات (أعلى الخلاصة). مصدر البيانات واحد
//  (db.getActiveUrgentAnnouncement)، والعرض هنا موحّد بدل ما كل
//  صفحة تكرر نفس الـ HTML بثلاث نسخ مختلفة قليلاً.
//
//  الضغط على النداء بيفتح نافذة بتفاصيل الحالة كاملة (العنوان والنص
//  بفواصل الأسطر، ورقم الاتصال لو موجود)، وفيها زر إغلاق فقط. الربط بـdelegation واحد على document (مرة واحدة
//  عند تحميل الملف) عشان الصفحات التلاتة ما تحتاج تربط شيء بنفسها.
// ══════════════════════════════════════════════════════════════

import { getActiveUrgentAnnouncement } from '../data/db.js';
import { escapeHtml } from './sanitize.js';
import { renderIcons } from './icons.js';

const DISMISS_KEY = 'urgent-dismissed';

function _keyOf(a) {
  return String(a.id || a.publishedAt || `${a.title}|${a.expiresAt || ''}`);
}
function _isDismissed(a) {
  try { return localStorage.getItem(DISMISS_KEY) === _keyOf(a); } catch { return false; }
}
function _dismiss(a) {
  try { localStorage.setItem(DISMISS_KEY, _keyOf(a)); } catch { /* ignore */ }
}

// آخر نداء اتعرض — النافذة بتقرا منه عند الضغط
let _current = null;

const TYPE_META = {
  blood_donor:      { icon: 'droplet',    label: 'نداء تبرع بالدم' },
  medical_donation: { icon: 'hand-coins', label: 'نداء تبرع عاجل' },
};

/**
 * يجيب النداء العاجل الحالي لو موجود — بيبتلع أي خطأ (نداء عاجل
 * غير أساسي لعرض الصفحة، فشل جلبه ما ينفعش يوقف الصفحة كلها).
 * @returns {Promise<Object|null>}
 */
export async function fetchUrgentAnnouncement() {
  try {
    return await getActiveUrgentAnnouncement();
  } catch {
    return null;
  }
}

/**
 * HTML لبطاقة النداء العاجل.
 * @param {Object} a - النداء (من fetchUrgentAnnouncement)
 * @param {'home'|'news'|'occasions'} variant
 * @returns {string}
 */
export function renderUrgentBanner(a, variant) {
  const meta = TYPE_META[a.type] || { icon: 'siren', label: 'نداء عاجل' };
  _current = a;
  if (_isDismissed(a)) return '';

  return `
    <div class="urgent-banner-wrap">
    <button type="button" class="urgent-banner urgent-banner--${variant}" data-urgent-open aria-haspopup="dialog" aria-label="عرض تفاصيل ${escapeHtml(a.title)}">
      <span class="urgent-banner__badge">
        <i data-icon="siren"></i>
        نداء إنساني عاجل · مؤقت
      </span>
      <div class="urgent-banner__row">
        <span class="urgent-banner__icon"><i data-icon="${meta.icon}"></i></span>
        <div class="urgent-banner__body">
          <h3 class="urgent-banner__title">${escapeHtml(a.title)}</h3>
          <p class="urgent-banner__text">${escapeHtml(a.body)}</p>
        </div>
        <i class="urgent-banner__arrow" data-icon="chevron-left"></i>
      </div>
    </button>
    <button type="button" class="urgent-banner__dismiss" data-urgent-dismiss aria-label="إخفاء النداء"><i data-icon="x"></i></button>
    </div>
  `;
}

// ── نافذة تفاصيل النداء ─────────────────────────────────────────────
function _openDetails(a) {
  document.querySelector('.urgent-details-backdrop')?.remove();
  const meta  = TYPE_META[a.type] || { icon: 'siren', label: 'نداء عاجل' };
  const phone = String(a.contactPhone || '').trim();

  const backdrop = document.createElement('div');
  backdrop.className = 'overlay-backdrop urgent-details-backdrop';
  backdrop.innerHTML = `
    <div class="modal urgent-details" role="dialog" aria-modal="true" aria-label="${escapeHtml(a.title)}">
      <div class="modal__handle"></div>
      <div class="modal__header">
        <h3 class="modal__title">${escapeHtml(a.title)}</h3>
      </div>
      <div class="modal__body">
        <p class="urgent-details__text">${escapeHtml(a.body)}</p>
        ${phone ? `
          <a class="cta-button cta-button--full urgent-details__call" href="tel:${escapeHtml(phone)}">
            <i data-icon="phone"></i> اتصال بأهل الحالة
          </a>` : ''}
      </div>
      <div class="modal__footer">
        <button type="button" class="btn btn--ghost" data-urgent-close>إغلاق</button>
      </div>
    </div>
  `;
  document.body.appendChild(backdrop);
  renderIcons(backdrop);

  const close = () => { backdrop.remove(); document.removeEventListener('keydown', onKey); };
  const onKey = e => { if (e.key === 'Escape') close(); };
  document.addEventListener('keydown', onKey);

  backdrop.addEventListener('click', e => {
    if (e.target === backdrop || e.target.closest('[data-urgent-close]')) close();
  });
}

document.addEventListener('click', e => {
  const x = e.target.closest('[data-urgent-dismiss]');
  if (x) {
    if (_current) _dismiss(_current);
    x.closest('.urgent-banner-wrap')?.remove();
    document.dispatchEvent(new CustomEvent('urgent-dismissed'));
    return;
  }
  if (!e.target.closest('[data-urgent-open]')) return;
  if (_current) _openDetails(_current);
});
