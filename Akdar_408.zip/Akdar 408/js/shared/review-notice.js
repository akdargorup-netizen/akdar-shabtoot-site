// js/shared/review-notice.js — شبتوت بحري
// ═══════════════════════════════════════════════════════════════════
//  رسالة شكر بتظهر لصاحب الفكرة/المناسبة مكان بطاقته وهي لسه تحت
//  مراجعة المشرفين (moderation === 'pending')، بدل الكرت الكامل
//  وبدل toast عابر. بتفضل ظاهرة لحد ما تتم الموافقة فتتبدل بالبطاقة.
// ═══════════════════════════════════════════════════════════════════

const COPY = {
  idea: {
    icon: 'heart-handshake',
    title: 'جزاك الله خيرًا على مساهمتك',
    text: 'فكرتك تحت مراجعة المشرفين، سنراجعها وننشرها في أقرب وقت.',
  },
  occasion: {
    icon: 'sparkles',
    title: 'شكرًا لمشاركة مناسبتك',
    text: 'سننشرها في أقرب وقت بعد مراجعتها.',
  },
};

/** @param {'idea'|'occasion'} kind @param {string|number} id */
export function renderReviewNotice(kind, id) {
  const c = COPY[kind];
  return `
    <article class="review-notice review-notice--${kind}" data-review-notice="${kind}" data-${kind}-notice-id="${id}" role="status">
      <span class="review-notice__icon" aria-hidden="true"><i data-icon="${c.icon}"></i></span>
      <h3 class="review-notice__title">${c.title}</h3>
      <p class="review-notice__text">${c.text}</p>
    </article>
  `;
}
