// js/shared/notif-badge.js — شبتوت بحري
// ══════════════════════════════════════════════════════════════
//  مصدر واحد لتحديث شارة عداد الرسائل (نمط واتساب) في الناف
//  السفلي. تُستدعى من: app.js عند الإقلاع، notifications.js بعد
//  القراءة، push.js عند وصول إشعار، وadmin-notifications.js بعد
//  الإرسال — بدل ما كل ملف يحدّث الـ DOM بمنطقه الخاص.
// ══════════════════════════════════════════════════════════════

import { getUnreadNotificationsCount } from '../data/db.js';
import { waitForAuthReady, onAuthChange } from '../data/auth.js';

/** يجلب عدد غير المقروء ويحدّث الشارة على أيقونة الجرس.
 *  fresh: يتخطّى الذاكرة القصيرة (٩٠ ث) في المحوّل — لوصول push بس. */
export async function refreshNotifBadge({ fresh = false } = {}) {
  try {
    const count = await getUnreadNotificationsCount({ fresh });
    setNotifBadge(count);
  } catch (err) {
    console.error('[NotifBadge] فشل التحديث:', err);
  }
}

/** يضبط الشارة مباشرة برقم (بدون جلب من db) — للتحديث الفوري بعد إجراء */
export function setNotifBadge(count) {
  const el = document.getElementById('notif-badge-count');
  if (!el) return;

  if (!count || count <= 0) {
    el.classList.remove('is-visible', 'animate-breathe');
    el.textContent = '';
    return;
  }

  el.textContent = count > 99 ? '99+' : String(count);
  el.classList.add('is-visible', 'animate-breathe');
}

// ══════════════════════════════════════════════════════════════
//  تحديث تلقائي للشارة — إشعارات التفاعل الشخصي (تعليق/إعجاب...) ليس لها push،
//  فالشارة كانت تُحسب مرة واحدة عند الإقلاع من النسخة المحفوظة (وقبل جاهزية
//  الحساب أحيانًا، فتُستبعد الإشعارات الشخصية) ثم لا تتحدّث أبدًا. الآن تتحدّث عند:
//   1) وصول نسخة أحدث من السيرفر (akdar:data-refreshed للإشعارات)
//   2) جاهزية الحساب / تغيّره (تسجيل دخول أو خروج)
//   3) رجوع المستخدم للتطبيق أو عودة الاتصال (بحد أدنى ٦٠ ثانية بين كل جلب)
// ══════════════════════════════════════════════════════════════
let _autoBound = false;
let _lastFresh = 0;
let _debounce = null;

function _scheduleRefresh(opts) {
  clearTimeout(_debounce);
  _debounce = setTimeout(() => refreshNotifBadge(opts), 250);
}

function _refreshFreshThrottled() {
  const now = Date.now();
  if (now - _lastFresh < 60000) return;
  _lastFresh = now;
  _scheduleRefresh({ fresh: true });
}

function _bindAutoRefresh() {
  if (_autoBound || typeof window === 'undefined') return;
  _autoBound = true;

  window.addEventListener('akdar:data-refreshed', (e) => {
    if (e.detail?.collection !== 'notifications') return;
    // صفحة الرسائل مفتوحة: هي تعالج القراءة وتصفّر الشارة بنفسها
    if (document.getElementById('notifications-feed')) return;
    _scheduleRefresh();
  });

  waitForAuthReady().then(() => _scheduleRefresh()).catch(() => {});

  let first = true;   // onAuthChange يستدعي callback فورًا بالحالة الحالية — نتجاهل هذه المرة
  onAuthChange(() => {
    if (first) { first = false; return; }
    _scheduleRefresh({ fresh: true });
  });

  document.addEventListener('visibilitychange', () => { if (!document.hidden) _refreshFreshThrottled(); });
  window.addEventListener('online', _refreshFreshThrottled);
}

_bindAutoRefresh();
