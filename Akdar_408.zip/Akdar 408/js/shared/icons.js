// js/shared/icons.js — شبتوت بحري
// ══════════════════════════════════════════════════════════════
//  نقطة موحّدة لعرض أيقونات lucide في كل مكان بالمشروع.
//
//  المشكلة اللي بيحلّها هذا الملف:
//  عناصر الأيقونات بتُكتب بصفة data-icon="اسم" (مش data-lucide
//  مباشرة). router.js بيحوّل data-icon → data-lucide مرة وحدة بس
//  وقت فتح الصفحة (navigateTo). أي محتوى بيتضاف بعد كده — بيانات
//  async، تعليقات، فورمز، نتائج بحث... إلخ — بيفضل عنده data-icon
//  بس، فمكتبة lucide (اللي بتدوّر على data-lucide) ما بتشوفهوش،
//  والأيقونة تفضل فاضية بصمت من غير أي خطأ ظاهر.
//
//  الحل: أي مكان بيضيف أيقونات ديناميكيًا (بعد الـ render الأولي
//  للصفحة) يستدعي renderIcons() بدل ما يستدعي
//  `if (window.lucide) lucide.createIcons();` مباشرة.
//
//  ⚠️ تذكير لأي حد (أو أداة ذكاء اصطناعي) بيضيف صفحة/مكوّن جديد:
//  لو بتضيف عنصر أيقونة ديناميكي بعد التحميل الأول للصفحة، استخدم
//  renderIcons() هنا بدل الاستدعاء المباشر لـ lucide.createIcons().
// ══════════════════════════════════════════════════════════════

/**
 * يحوّل كل data-icon داخل root إلى data-lucide، ثم يطلب من lucide
 * يرسم كل الأيقونات الموجودة في الصفحة (lucide.createIcons() نفسه
 * بيدوّر على المستند كله دايمًا، مفيش scoping في النسخة المستخدمة
 * هنا — فمرّرنا root بس لخطوة التحويل، مش لاستدعاء lucide نفسه).
 *
 * @param {ParentNode} [root=document] العنصر اللي نبحث جواه عن data-icon
 */
export function renderIcons(root = document) {
  root.querySelectorAll('[data-icon]').forEach(el => {
    el.setAttribute('data-lucide', el.getAttribute('data-icon'));
  });
  if (window.lucide) window.lucide.createIcons();
}
