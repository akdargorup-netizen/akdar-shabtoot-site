// js/shared/permission-onboarding.js — شبتوت بحري
// ═══════════════════════════════════════════════════════════════════
//  نافذة "فعّل الإشعارات" — تظهر إجباريًا أول مرة يفتح فيها المستخدم
//  التطبيق (مرة واحدة بس، عمر التطبيق كله، عبر localStorage). بنفس
//  فلسفة login-prompt-modal.js تمامًا: نافذة JS بتتلحق بالـ body، من
//  مكوّنات CSS موجودة أصلاً (modal, btn) + كلاسات خاصة للأيقونة/العنوان.
//
//  ⚠️ الفرق المتعمّد عن باقي النوافذ (login-prompt، admin-gate):
//  زرار واحد بس ("موافقة ومتابعة")، بدون زرار "بعدين"، وبدون إغلاق
//  بالضغط على الخلفية — القرار الوحيد المتاح هو الموافقة والمتابعة.
//
//  ⚠️ حد تقني لازم يكون واضح: احنا نقدر نجبر المستخدم إنه "يوافق" على
//  نافذتنا احنا (مفيش طريقة تانية يكمل بيها للتطبيق)، لكن مستحيل تقنيًا
//  أي موقع يجبر المتصفح نفسه يرجّع "Allow" في نافذة إذن النظام الحقيقية
//  اللي بتظهر بعدها — لو المستخدم ضغط "Block" هناك، الإذن هيتسجّل
//  مرفوض، وده قرار المتصفح مش بتاعنا. اللي بنضمنه هو إن كل مستخدم
//  هيتعرض للطلب فعليًا مرة واحدة على الأقل، مش إنه هيوافق فعلاً.
// ═══════════════════════════════════════════════════════════════════

import { initPush, requestPermission } from './push.js';
import { renderIcons } from './icons.js';
import { RUNTIME_CONFIG } from '../data/runtime-config.js';

const SEEN_KEY = 'permission-onboarding-seen';

export async function initPermissionOnboarding() {
  // اتعرضت قبل كده (بغض النظر عن نتيجة الإذن) — ما تتكررش تاني
  if (localStorage.getItem(SEEN_KEY) === 'true') return;

  // في وضع البناء لا نطلب إذن المتصفح ولا نوقف تجربة التطبيق بنافذة إجبارية؛
  // Push الخارجي معطّل أصلًا من runtime-config.js.
  if (!RUNTIME_CONFIG.enableRealPush) {
    localStorage.setItem(SEEN_KEY, 'true');
    return;
  }

  // المتصفح لا يدعم إشعارات الويب أصلاً — مفيش داعي نعرض حاجة
  const supported = ('Notification' in window) && ('serviceWorker' in navigator) && ('PushManager' in window);
  if (!supported) {
    localStorage.setItem(SEEN_KEY, 'true');
    return;
  }

  // المستخدم سبق قرر (من زيارة سابقة أو من متصفح تاني بنفس الجهاز) —
  // ما تتكررش تاني، وسجّل إننا "عرضنا" الموضوع
  if (Notification.permission !== 'default') {
    localStorage.setItem(SEEN_KEY, 'true');
    return;
  }

  await initPush().catch(() => {});
  _showModal();
}

function _showModal() {
  const backdrop = document.createElement('div');
  backdrop.className = 'overlay-backdrop overlay-backdrop--center';
  backdrop.innerHTML = `
    <div class="modal modal--center login-prompt-modal" role="dialog" aria-modal="true" aria-label="تفعيل الإشعارات">
      <div class="modal__body login-prompt-modal__body">
        <div class="login-prompt-modal__icon"><i data-lucide="bell-ring"></i></div>
        <h3 class="modal__title login-prompt-modal__title">فعّل الإشعارات</h3>
        <p class="login-prompt-modal__desc">
          حتى توصل ليك أخبار البلد والمناسبات والتنبيهات المهمة أول بأول،
          حتى لو التطبيق قافل. التطبيق محتاج إذنك للإشعارات لكي يشتغل صح.
        </p>
      </div>
      <div class="modal__footer">
        <button class="btn btn--primary btn--full" id="perm-onboarding-agree">موافقة ومتابعة</button>
      </div>
    </div>
  `;
  document.body.appendChild(backdrop);
  renderIcons(backdrop);

  const agreeBtn = backdrop.querySelector('#perm-onboarding-agree');
  agreeBtn.addEventListener('click', async () => {
    agreeBtn.disabled = true;
    agreeBtn.textContent = 'جاري التفعيل...';

    let closed = false;
    const finish = () => {
      if (closed) return;
      closed = true;
      localStorage.setItem(SEEN_KEY, 'true');
      backdrop.remove();
    };

    // شبكة أمان: لو ما رجعش رد الإذن (بعض المتصفحات/الأغلفة تتجاهل إغلاق نافذة
    // الإذن بزر الرجوع) نقفل النافذة بدل ما تفضل معلّقة. القرار (لو جاء متأخرًا)
    // يتسجّل عند المتصفح، والاشتراك يكمل تلقائيًا بعدها.
    const watchdog = setTimeout(finish, 20000);
    try {
      await requestPermission();
    } catch (_) { /* نقفل في كل الأحوال */ }
    clearTimeout(watchdog);
    finish();
  });
}
