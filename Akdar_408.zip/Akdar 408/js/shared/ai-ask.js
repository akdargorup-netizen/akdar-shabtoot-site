// js/shared/ai-ask.js — شبتوت بحري
// ══════════════════════════════════════════════════════════════
//  عميل الذكاء الاصطناعي: يجمّع سياقًا من كل مصادر التطبيق المسجَّلة في
//  ai-sources.js (المفعّل الآن: مقالات التاريخ، مقالات مسيرة الرابطة، معلومات "هل تعلم")
//  ثم يسأل دالة /ask. المساعد يكبر مع التطبيق: أي محتوى جديد في هذه المصادر
//  يدخل تلقائيًا في البحث. (واجهته في js/pages/ai.js).
//
//  ليش مش search(q) مباشرة؟ لأن search() بتطلب تطابق كل كلمات السؤال مع
//  *العنوان* فقط، و"وين الصيدلية في البلد؟" ما بيطابق شي. فبنفكّك السؤال
//  لكلمات مفتاحية، نبحث بكل كلمة، ندمج النتائج بالتكرار، ثم نجيب نص
//  أهم النتائج (مقالات التاريخ/الأخبار/مسيرة الرابطة) لأن العنوان وحده
//  ما يكفي النموذج ليجاوب.
//
//  الخصوصية: ما نرسل أرقام هواتف ولا محتوى المستخدمين (أفكار/تعليقات)
//  للنموذج — الطبقة المجانية عند Google ممكن تستخدم المدخلات في التدريب.
// ══════════════════════════════════════════════════════════════

import { loadAiPool } from './ai-sources.js';
import { prepareQuery, normalizeText } from './arabic-search.js';
import { getCachedAnswer, putCachedAnswer } from './ai-answer-cache.js';

// الدالة على Supabase Edge Functions (supabase/functions/ask)
const ENDPOINT = 'https://rtgrkugcokqxseedzunr.supabase.co/functions/v1/ask';
/** نداء خفيف يوقظ دالة /ask قبل أول سؤال (البداية الباردة). صامت، مرة واحدة لكل جلسة. */
let _warmed = false;
export function warmAskFunction() {
  if (_warmed) return;
  const conn = navigator.connection;
  if (conn && conn.saveData) return;
  _warmed = true;
  fetch(ENDPOINT, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ mode: 'warm' }),
    keepalive: true,
  }).catch(() => {});
}

const MAX_ARTICLES_FOR_AI = 4;   // مستندات يُرسل منها فقرات مختارة (من كل المصادر)
const MAX_INDEX = 180;           // أقصى عدد عناوين في فهرس البحث بالنموذج (يكبر التطبيق ولا يكبر الطلب)
const MIN_PER_SOURCE = 12;       // حصة دنيا لكل مصدر في الفهرس عند التقليص
const MIN_ARTICLE_SCORE = 2.5;     // أقل درجة لاعتبار المقال ذا صلة (الكلمات الشائعة وحدها لا تكفي)
const REL_FLOOR = 0.6;           // نحتفظ بالمقالات القريبة من الأفضل فقط
const PARAS_PER_ARTICLE = 2;
const TEXT_PER_ARTICLE = 950;

// كلمات شائعة تتشال من السؤال قبل البحث (مطبّعة بنفس normalizeText)
const STOP = new Set([
  'ما', 'ماذا', 'من', 'متي', 'اين', 'وين', 'كيف', 'ليش', 'لماذا', 'هل', 'ايش', 'شنو', 'مين', 'متى',
  'في', 'علي', 'عن', 'الي', 'الى', 'مع', 'هو', 'هي', 'هذا', 'هذه', 'ده', 'دي', 'دا', 'ذلك', 'التي', 'الذي',
  'كان', 'كانت', 'يكون', 'فيه', 'عندكم', 'عندنا', 'لو', 'ممكن', 'عايز', 'اريد', 'ابغي', 'اعرف', 'قول', 'قولي',
  'لي', 'لنا', 'بتاع', 'بتاعت', 'تاع', 'كل', 'شي', 'شيء', 'بلد', 'البلد', 'قريه', 'القريه', 'شبتوت', 'بحري',
  // صيغ السؤال عن اللغة (لا تدل على مقال معيّن؛ النية تُعالَج بنقطة إضافية لمستندات القاموس والعبارات)
  'اقول', 'نقول', 'يقال', 'تقال', 'نوبيه', 'النوبيه', 'بالنوبيه', 'انداندي', 'بالانداندي', 'ترجم', 'ترجمه',
].map(normalizeText));

function keywords(question) {
  const pq = prepareQuery(question);
  const seen = new Set();
  return pq.tokens
    .map((t) => t.stripped)
    .filter((w) => w.length >= 2 && !STOP.has(w) && !seen.has(w) && seen.add(w))
    .slice(0, 5);
}

// ── كل المصادر: اختيار الفقرات الأنسب من النص الكامل ──────────────
const _normCache = new Map(); // معرّف المقال → { len, title, paras }

function normalized(a) {
  const paras = a.paras || [];
  const key = `${a.type}|${a.id}`;
  const len = paras.reduce((n, p) => n + p.length, 0);
  const hit = _normCache.get(key);
  if (hit && hit.len === len) return hit;
  const rec = { len, title: normalizeText(a.title || ''), paras, norm: paras.map(normalizeText) };
  _normCache.set(key, rec);
  return rec;
}

// وزن الكلمة: الكلمة النادرة في المقالات (إنذار قوي) أثقل من الكلمة الشائعة
// ("الأمانة" مثلًا تظهر في عدة مقالات فلا يجوز أن تُرجّح مقالًا عن مصر ولبنان)
function wordWeights(pool, words) {
  const N = Math.max(pool.length, 1);
  const w = {};
  words.forEach((word) => {
    const df = pool.reduce((n, a) => {
      const r = normalized(a);
      return n + (r.title.includes(word) || r.norm.some((p) => p.includes(word)) ? 1 : 0);
    }, 0);
    w[word] = df ? Math.log(1 + N / df) : 0;
  });
  return w;
}

function scoreArticle(a, words, weight, boost = 0) {
  const rec = normalized(a);
  let titleScore = 0;
  words.forEach((w) => { if (rec.title.includes(w)) titleScore += 3 * weight[w]; });
  const scores = rec.norm.map((p) => words.reduce((n, w) => n + (p.includes(w) ? weight[w] : 0), 0));
  const sorted = [...scores].sort((x, y) => y - x);
  let total = titleScore + (sorted[0] || 0) + 0.5 * (sorted[1] || 0);
  // نية لغوية ("كيف أقول ... بالنوبية"): نرفع مستندات القاموس والعبارات متى طابقت كلمة
  if (boost && total > 0 && String(a.type).startsWith('nubian')) total += boost;
  return { total, scores, rec };
}

function buildArticleItem(a, scored) {
  const { scores, rec } = scored;
  // أعلى فقرتين تطابقًا، ثم نرجعهما بترتيبهما الأصلي في المقال
  const idx = a.keepAll
    // مستند قصير كامل المعنى (مشروع: وصف + حالة + تمويل): نرسله كله بترتيبه
    ? rec.paras.map((_, i) => i).slice(0, a.maxParas || PARAS_PER_ARTICLE)
    : scores
      .map((s, i) => ({ s, i }))
      .sort((x, y) => y.s - x.s || x.i - y.i)
      .slice(0, a.maxParas || PARAS_PER_ARTICLE)
      .filter((x, k) => k === 0 || x.s > 0)
      .map((x) => x.i)
      .sort((x, y) => x - y);
  let text = idx.map((i) => rec.paras[i]).join(' ');
  if (text.length > TEXT_PER_ARTICLE) text = text.slice(0, TEXT_PER_ARTICLE);
  if (a.date) text = `(بتاريخ ${a.date}) ${text}`;
  if (a.source) text = `(المصدر: ${a.source}) ${text}`;
  return { type: a.label || 'تاريخ', title: a.title, text };
}

async function loadPool() {
  return loadAiPool();
}

// فهرس العناوين المرسَل للنموذج: كله إن كان صغيرًا، وإلا نقلّصه بحصة دنيا لكل مصدر
// ثم الأعلى تطابقًا محليًا (فلا يطغى مصدر كبير كالأخبار على التاريخ).
function buildIndex(pool, words, boost = 0) {
  if (pool.length <= MAX_INDEX) return pool;
  const weight = wordWeights(pool, words);
  const scored = pool.map((a, i) => ({ a, i, t: scoreArticle(a, words, weight, boost).total }));
  const keep = new Set();
  const bySource = new Map();
  scored.forEach((x) => {
    if (!bySource.has(x.a.type)) bySource.set(x.a.type, []);
    bySource.get(x.a.type).push(x);
  });
  bySource.forEach((list) => {
    list.sort((x, y) => y.t - x.t || x.i - y.i).slice(0, MIN_PER_SOURCE).forEach((x) => keep.add(x.i));
  });
  [...scored].sort((x, y) => y.t - x.t || x.i - y.i).forEach((x) => {
    if (keep.size < MAX_INDEX) keep.add(x.i);
  });
  return pool.filter((_, i) => keep.has(i));
}

// ترتيب محلي بالكلمات (احتياطي، وأيضًا لاختيار الفقرات داخل المقال)
function rankLocal(pool, words, boost = 0) {
  const weight = wordWeights(pool, words);
  const ranked = pool
    .map((a) => ({ a, sc: scoreArticle(a, words, weight, boost) }))
    .filter((x) => x.sc.total >= MIN_ARTICLE_SCORE)
    .sort((x, y) => y.sc.total - x.sc.total);
  return { ranked, weight };
}

// ── بحث بالنموذج: يختار المقالات الأنسب من فهرس العناوين ───────────
// يفيد حين تختلف صيغة السؤال عن ألفاظ المقال (إمام/خطيب، فيضان/غرق...).
// أي فشل أو تأخّر → null فنرجع للبحث المحلي بدون أن يلاحظ المستخدم.
const ROUTE_TIMEOUT_MS = 2000;   // كان 4500 ثم 3000: الإجابة تنتظر هذا النداء، فنقصّر أقصى انتظار
// تطابق محلي بهذه الدرجة أو أعلى = واضح كفاية، نوفّر نداء النموذج كاملًا (أسرع وأوفر للحصة).
// (نفس عتبة "التطابق القوي" المستخدمة تحت لإضافة أفضل نتيجة محلية)
const ROUTE_SKIP_SCORE = 10;
const ROUTE_PAUSE_MS = 10 * 60 * 1000; // بعد "موقوف" أو "ازدحام الموقع" لا نكرر الطلب لفترة
let _routeOffUntil = 0;

async function routeWithModel(question, index) {
  if (Date.now() < _routeOffUntil) return null;
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), ROUTE_TIMEOUT_MS);
  try {
    const res = await fetch(ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ mode: 'route', question, titles: index.map((a) => `${a.label}: ${a.title}`) }),
      signal: ctrl.signal,
    });
    if (res.status === 429) {
      const d = await res.json().catch(() => ({}));
      if (d.error === 'daily-limit-site') _routeOffUntil = Date.now() + ROUTE_PAUSE_MS;
      return null;
    }
    if (!res.ok) return null;
    const data = await res.json();
    if (data.disabled) { _routeOffUntil = Date.now() + 24 * 60 * 60 * 1000; return null; }
    const idx = (Array.isArray(data.articles) ? data.articles : [])
      .map((n) => Number(n) - 1)
      .filter((i) => Number.isInteger(i) && i >= 0 && i < index.length);
    const words = Array.isArray(data.words) ? data.words.map(String).slice(0, 6) : [];
    return { idx, words };
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

/** يجمّع أفضل سياق للسؤال من كل مصادر التطبيق: مستندات يختارها النموذج من الفهرس
 *  (+ أقوى تطابق محلي). لو تعذّر النموذج نرجع للبحث المحلي بالكلمات. */
// هل السؤال عن اللغة النوبية؟ (ترجمة كلمة/عبارة)
function nubianIntent(question) {
  return /نوب|اندندي|انداندي|ترجم|(كيف|شلون) (اقول|نقول|يقال)/.test(normalizeText(question));
}

export async function gatherContext(question) {
  const words = keywords(question);
  if (!words.length) return [];
  const boost = nubianIntent(question) ? 8 : 0;

  const pool = await loadPool();
  const index = buildIndex(pool, words, boost);
  // الترتيب المحلي أولًا (سريع، بدون شبكة)؛ لو التطابق قوي نتخطّى نداء التوجيه بالنموذج
  // فتصير الإجابة بنداء واحد بدل اثنين. وإلا نسأل النموذج كما كان.
  const local = rankLocal(pool, words, boost);
  const strongLocal = (local.ranked[0]?.sc.total || 0) >= ROUTE_SKIP_SCORE;
  // مفاتيح تجربة (للمطوّر فقط، من console): localStorage['ai-route']='off' يوقف التوجيه بالنموذج،
  // و localStorage['ai-debug']='1' يطبع المسار المستخدم والزمن — لمقارنة جودة الإجابات قبل وبعد.
  const flag = (k) => { try { return localStorage.getItem(k); } catch { return null; } };
  const routeOff = flag('ai-route') === 'off';
  const t0 = performance.now();
  let route = (index.length && !strongLocal && !routeOff) ? await routeWithModel(question, index) : null;
  if (flag('ai-debug') === '1') {
    const path = routeOff ? 'محلي (التوجيه موقوف تجريبيًا)' : strongLocal ? 'محلي (تطابق قوي)' : route ? 'نموذج' : 'محلي (فشل/فراغ التوجيه)';
    console.info(`[ai] المسار: ${path} | أعلى درجة محلية: ${(local.ranked[0]?.sc.total || 0).toFixed(1)} | زمن التوجيه: ${Math.round(performance.now() - t0)}ms`);
  }
  // رد فاضي تمامًا (لا مستندات ولا كلمات) = غير حاسم، نرجع للبحث المحلي كأن النموذج لم يُستشَر
  if (route && !route.idx.length && !route.words.length) route = null;

  let articles = [];
  if (route) {
    const extra = keywords(route.words.join(' '));
    const allWords = [...new Set([...words, ...extra])];
    const weight = wordWeights(pool, allWords);
    const chosen = route.idx.map((i) => index[i]);
    const items = chosen.map((a) => buildArticleItem(a, scoreArticle(a, allWords, weight, boost)));
    // أقوى تطابق محلي يُضاف لو كان قويًا فعلًا ولم يختره النموذج
    const top = local.ranked[0];
    if (top && top.sc.total >= 15 && !chosen.includes(top.a)) items.push(buildArticleItem(top.a, top.sc));
    articles = items.slice(0, MAX_ARTICLES_FOR_AI);
  } else if (local.ranked.length) {
    const floor = local.ranked[0].sc.total * REL_FLOOR;
    articles = local.ranked.filter((x) => x.sc.total >= floor)
      .slice(0, MAX_ARTICLES_FOR_AI).map((x) => buildArticleItem(x.a, x.sc));
  }

  return articles;
}

/** يلصق نتائج البحث المحلي بالخطأ — تُعرض كبديل لو الذكاء الاصطناعي متوقف */
function withItems(err, items, detail) {
  err.items = items;
  if (detail) err.detail = detail;
  return err;
}


// ── تسمية المصادر: العنوان وحده مُبهم، فنضيف نوع المصدر قبله (مقالة «…» / خبر «…» …) ──
const SOURCE_KIND = {
  'تاريخ': 'مقالة', 'رابطة': 'مقالة', 'خبر': 'خبر', 'مشروع': 'مشروع',
  'فيديو مناسبة': 'فيديو', 'فيديو ذاكرة': 'فيديو',
  'قاموس نوبي': 'قاموس الكلمات', 'عبارات نوبية': 'تعلّم الكلام',
  'جهة عامة': 'دليل الاتصال', 'معلومة': 'هل تعلم؟',
  'نبذة الرابطة': '', 'الدستور': '', 'لوائح الرابطة': '',   // عناوينها نفسها تحمل النوع (دستور الرابطة — ...)
};
function labelSources(sources, items) {
  const list = Array.isArray(sources) ? sources : [];
  return list.filter(Boolean).map((t) => {
    const hit = (items || []).find((i) => i && i.title === t);
    const kind = hit ? SOURCE_KIND[hit.type] : '';
    return kind ? `${kind} «${t}»` : String(t);
  });
}

// أعطال لا تنفع معها إعادة المحاولة (إعداد/حصة/طلب خاطئ)
const FINAL_FAILURES = new Set(['no-key', 'key-rejected', 'model-missing', 'quota', 'bad-request']);

async function postOnce(q, items) {
  let res;
  try {
    res = await fetch(ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ question: q, items }),
    });
  } catch {
    throw withItems(new Error('network'), items);
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    // رد غير JSON (مثل ٥٠٢/٥٠٤ عند انتهاء مهلة الدالة) → رمز http-<الحالة>
    const detail = data.detail || (data.error ? '' : `http-${res.status}`);
    throw withItems(new Error(data.error || 'unavailable'), items, detail);
  }
  return { answer: data.answer, sources: labelSources(data.sources, items), items };
}

/** يسأل المساعد. يرمي Error برمز مفهوم: unavailable | too-many-requests | daily-limit-* | network
 *  عطل مؤقت (مهلة/٥xx) → إعادة واحدة تلقائية قبل إظهار الخطأ للمستخدم. */
export async function askAkdar(question) {
  const q = String(question || '').trim();
  if (!q) throw new Error('empty');
  const items = await gatherContext(q);
  try {
    return await postOnce(q, items);
  } catch (err) {
    const retryable = err.message === 'unavailable' && !FINAL_FAILURES.has(err.detail);
    if (!retryable) throw err;
    await new Promise((r) => setTimeout(r, 700));
    return postOnce(q, items);
  }
}

// ── بث الإجابة (SSE) ──────────────────────────────────────────────
// onText(النص_المتراكم) يُستدعى كلما وصل جزء جديد. الخادم قد يرد JSON عاديًا (كاش أو
// احتياطي مزوّد آخر) فنعالج الحالتين بنفس الدالة. الأعطال قبل وصول أي نص ترمي نفس
// أكواد askAkdar؛ لو انقطع البث بعد ظهور نص نرجّع ما وصل بدل خطأ.
async function streamOnce(q, items, onText) {
  let res;
  try {
    res = await fetch(ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ question: q, items, stream: true }),
    });
  } catch {
    throw withItems(new Error('network'), items);
  }

  const isSse = (res.headers.get('content-type') || '').includes('text/event-stream');
  if (!isSse || !res.body) {
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      const detail = data.detail || (data.error ? '' : `http-${res.status}`);
      throw withItems(new Error(data.error || 'unavailable'), items, detail);
    }
    return { answer: data.answer, sources: labelSources(data.sources, items), items };
  }

  const reader = res.body.getReader();
  const dec = new TextDecoder();
  let buf = '';
  let text = '';
  let final = null;
  let errEvt = null;

  const handle = (line) => {
    if (!line.startsWith('data:')) return;
    let ev;
    try { ev = JSON.parse(line.slice(5)); } catch { return; }
    if (typeof ev.t === 'string' && ev.t) { text += ev.t; if (onText) onText(text); }
    else if (ev.done) final = ev;
    else if (ev.error) errEvt = ev;
  };

  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      let nl;
      while ((nl = buf.indexOf('\n')) >= 0) {
        handle(buf.slice(0, nl).replace(/\r$/, ''));
        buf = buf.slice(nl + 1);
      }
    }
    if (buf.trim()) handle(buf.replace(/\r$/, ''));
  } catch {
    if (!text && !final) throw withItems(new Error('network'), items);
  }

  if (final && final.answer) return { answer: final.answer, sources: labelSources(final.sources, items), items };
  if (text.trim()) return { answer: text.trim(), sources: [], items }; // انقطع بعد ظهور نص
  throw withItems(new Error((errEvt && errEvt.error) || 'unavailable'), items, (errEvt && errEvt.detail) || 'empty-reply');
}

/** مثل askAkdar لكن بث تدريجي: onText يستلم النص أولًا بأول. نفس أكواد الأخطاء ونفس الإعادة التلقائية. */
export async function askAkdarStream(question, { onText } = {}) {
  const q = String(question || '').trim();
  if (!q) throw new Error('empty');
  const items = await gatherContext(q);
  // كاش الجهاز أولًا: سؤال اتجاوب قبل كده بنفس السياق يرجع فورًا بلا شبكة وبلا حصة
  const local = getCachedAnswer(q, items);
  if (local) return { answer: local.answer, sources: local.sources, items, cached: true };
  // بلا اتصال وبلا إجابة مخزّنة: نعلن ذلك فورًا بدل انتظار فشل الطلب وإعادته
  if (typeof navigator !== 'undefined' && navigator.onLine === false) throw withItems(new Error('network'), items);
  let res;
  try {
    res = await streamOnce(q, items, onText);
  } catch (err) {
    // الخادم يجرّب عدة مزوّدات احتياطية بنفسه قبل أن يعلن العطل، فإعادة الطلب كاملًا لا تفيد
    // (تضاعف الانتظار فقط). نعيد مرة واحدة فقط لو انقطعت الشبكة لحظيًا قبل أي رد.
    if (err.message !== 'network') throw err;
    await new Promise((r) => setTimeout(r, 700));
    res = await streamOnce(q, items, onText);
  }
  putCachedAnswer(q, items, res.answer, res.sources);
  return res;
}

/** رسائل جاهزة للمستخدم حسب رمز الخطأ (+ سبب التعطّل إن أرجعه الخادم) */
export function aiErrorMessage(code, detail) {
  switch (code) {
    case 'too-many-requests': return 'انتظر شوية وجرّب تاني';
    case 'daily-limit-user':  return 'وصلت للحد اليومي للأسئلة — جرّب بكرة';
    case 'daily-limit-site':  return 'الذكاء الاصطناعي مشغول الآن — جرّب بعد شوية';
    case 'network':           return 'لا يوجد اتصال بالإنترنت';
    default:
      // الحصة المجانية عند المزوّد خلصت: نفس معنى "مشغول" عند المستخدم
      if (detail === 'quota') return 'الذكاء الاصطناعي مشغول الآن — جرّب بعد شوية';
      return 'الذكاء الاصطناعي مشغول الآن — جرّب بعد شوية';
  }
}

/** رمز تشخيص قصير يظهر بخط صغير تحت رسالة العطل (لصاحب التطبيق عند الإبلاغ عن مشكلة) */
export function aiDiagCode(code, detail) {
  if (code === 'network') return '';
  if (code === 'unavailable' || !code) return detail || 'unavailable';
  return '';
}

/** تقييم إجابة 👍/👎 — يُرسل بلا انتظار ولا يرمي خطأ (غير حرج). بلا هوية: السؤال والإجابة فقط. */
export function sendAiFeedback(question, answer, vote) {
  try {
    fetch(ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ mode: 'feedback', question, answer, vote: vote === 'up' ? 'up' : 'down' }),
      keepalive: true,
    }).catch(() => { /* غير حرج */ });
  } catch { /* غير حرج */ }
}
