// js/shared/staff-badge.js — شبتوت بحري
// ══════════════════════════════════════════════════════════════
//  وسم الصفة بجانب الاسم (مطوّر / مشرف / مشرف آنداندي).
//
//  مصدر واحد لأسماء الوسوم والعرض. الحقل المخزَّن مع المحتوى اسمه
//  staffRole وقيمته واحدة من: 'developer' | 'admin' | 'nubian'.
//  أي قيمة غير معروفة تتجاهل ولا تُعرض (حماية من محتوى مزوَّر).
//
//  ملاحظة: اسم الوسم هنا مستقل عن ROLE_LABEL في admin-activity.js
//  (ذاك لسجل النشاط داخل لوحة الإدارة).
// ══════════════════════════════════════════════════════════════

import { getStaffRole } from '../data/admin-auth.js';

export const STAFF_BADGE_LABELS = {
  developer: 'مطوّر',
  admin:     'مشرف',
  nubian:    'مشرف آنداندي',
};

/** يرجع الدور لو معروف، وإلا ''. */
export function normalizeStaffRole(role) {
  return Object.prototype.hasOwnProperty.call(STAFF_BADGE_LABELS, role) ? role : '';
}

/** HTML الوسم، أو سلسلة فاضية لو ما في صفة. */
export function staffBadge(role) {
  const r = normalizeStaffRole(role);
  if (!r) return '';
  return `<span class="staff-badge staff-badge--${r}">${STAFF_BADGE_LABELS[r]}</span>`;
}

/** حقل جاهز للدمج وقت الإرسال: { staffRole } لو صاحب الحساب له صفة، وإلا {}.
 *  (سياسات RLS في Supabase تتحقق إن القيمة مطابقة لصلاحية حسابه الفعلية.) */
export function staffRoleField() {
  const r = normalizeStaffRole(getStaffRole());
  return r ? { staffRole: r } : {};
}
