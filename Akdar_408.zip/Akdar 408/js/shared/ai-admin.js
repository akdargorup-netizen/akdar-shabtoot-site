// js/shared/ai-admin.js — شبتوت بحري
// ══════════════════════════════════════════════════════════════
//  عميل أدوات المطوّر للذكاء الاصطناعي (صفحة admin-ai): حالة المزوّدين وحصصهم + تجربة نموذج.
//  يستدعي دالة /ask بـ mode:'admin'. التحقق الحقيقي في الخادم: توكن المستخدم + is_owner في user_roles.
//  لا مفاتيح تمر من هنا ولا تُعرض: نرسل اسم المزوّد فقط.
// ══════════════════════════════════════════════════════════════

import { getIdToken } from '../data/auth.js';

// نفس ENDPOINT في ai-ask.js (مكرَّر عمدًا حتى لا تُحمَّل أدوات البحث مع صفحة الإدارة)
const ENDPOINT = 'https://rtgrkugcokqxseedzunr.supabase.co/functions/v1/ask';

async function _call(body, timeoutMs) {
  const token = await getIdToken();
  if (!token) { const e = new Error('no-session'); e.code = 'no-session'; throw e; }
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ mode: 'admin', ...body }),
      signal: ctrl.signal,
    });
    let data = null;
    try { data = await res.json(); } catch { /* رد غير JSON */ }
    if (!res.ok) {
      const e = new Error(data?.error || `http-${res.status}`);
      e.code = res.status === 403 ? 'forbidden' : res.status === 429 ? 'rate-limited' : 'http';
      e.reason = data?.reason || '';
      throw e;
    }
    return data;
  } catch (err) {
    if (err?.name === 'AbortError') { const e = new Error('timeout'); e.code = 'timeout'; throw e; }
    throw err;
  } finally {
    clearTimeout(timer);
  }
}

/** حالة كل مزوّد (مضبوط؟ في استراحة؟) + عدّادات آخر 7 أيام من الجدول. */
export function getAiAdminStatus() {
  return _call({ op: 'status' }, 15000);
}

/** يجرّب مزوّدًا واحدًا بسؤال. يرجّع { ok, answer?, detail?, ms, rate? } — فشل المزوّد لا يرمي خطأ. */
export function testAiProvider(provider, question) {
  return _call({ op: 'test', provider, question }, 30000);
}

/** رؤى المساعد: أكثر الأسئلة التي لم يجد لها جوابًا + ملخص تقييمات 👍/👎. */
export function getAiInsights() {
  return _call({ op: 'insights' }, 15000);
}
