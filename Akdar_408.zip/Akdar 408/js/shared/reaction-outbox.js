// js/shared/reaction-outbox.js — شبتوت بحري
// ═══════════════════════════════════════════════════════════════════
//  طابور التفاعلات (إعجاب المناسبات + أؤيد/لا أؤيد في مصنع الأفكار) وقت ضعف الشبكة
//  أو توقف الخادم (حد Supabase). نفس روح comment-outbox.js لكن بفرق جوهري:
//
//   • التعليق عملية "إضافة" فيلزمها clientId لمنع التكرار.
//   • الإعجاب والتصويت "حالة مطلوبة" لا "عملية": نخزّن ما يريده المستخدم أن يكون
//     (معجب/غير معجب، أؤيد/لا أؤيد) بمفتاح واحد لكل (النوع + الهدف + الحساب).
//     ضغطتان متتاليتان أوفلاين = آخر حالة فقط. وإعادة الإرسال آمنة بطبيعتها
//     (setOccasionLike / voteIdea يضبطان الحالة ولا يقلبانها) فلا حاجة لمعرّف عملية.
//
//  دورة الإرسال في _drain: نكتب الحالة في الطابور أولًا (لو أُغلق التطبيق وسط الإرسال لا تضيع)،
//  ثم نجرّب الإرسال فورًا. نجح → نشيلها. فشل مؤقت (شبكة/مهلة/ضغط) → تبقى ونعيد لاحقًا.
//  رُفضت نهائيًا (حظر/صلاحية) → نشيلها ونُعلم المستخدم. ولو غيّر المستخدم رأيه أثناء
//  الإرسال (rev جديد) فلا نشيل الجديدة، ونرسلها في الدورة التالية داخل نفس الحلقة.
// ═══════════════════════════════════════════════════════════════════

import { isTransientFailure, shouldQueue } from './transient-error.js';

const KEY = 'akdar_reaction_outbox';
const MAX_AGE_MS = 3 * 24 * 3600 * 1000; // أقدم من ثلاثة أيام: لم يعد يمثّل رغبة المستخدم
const KINDS = ['idea-vote', 'occasion-like'];
// فشل غير مفهوم (ليس شبكة/ضغط ولا رفضًا نهائيًا مؤكّدًا): نعيد المحاولة هذا العدد من الدورات قبل أن نتخلّى ونُعلم المستخدم
const MAX_UNKNOWN_TRIES = 6;

const _keyOf = (kind, targetId, uid) => `${kind}|${targetId}|${uid}`;

function _readAll() {
  try {
    const v = JSON.parse(localStorage.getItem(KEY) || '{}');
    return v && typeof v === 'object' ? v : {};
  } catch {
    return {};
  }
}

function _writeAll(all) {
  try {
    if (Object.keys(all).length) localStorage.setItem(KEY, JSON.stringify(all));
    else localStorage.removeItem(KEY);
  } catch {
    /* تخزين ممتلئ/غير متاح (وضع خاص): الإرسال المباشر يظل يعمل، فقط لا يُحفظ عند الفشل */
  }
}

function _put(kind, targetId, uid, desired) {
  const all = _readAll();
  const rev = `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
  all[_keyOf(kind, targetId, uid)] = { kind, targetId: String(targetId), uid: String(uid), desired, rev, at: Date.now() };
  _writeAll(all);
  return rev;
}

function _removeIfRev(key, rev) {
  const all = _readAll();
  if (all[key] && all[key].rev === rev) {
    delete all[key];
    _writeAll(all);
  }
}

function _bumpTries(key, rev) {
  const all = _readAll();
  if (!all[key] || all[key].rev !== rev) return 0;
  all[key].tries = (all[key].tries || 0) + 1;
  _writeAll(all);
  return all[key].tries;
}

function _hasQueued() {
  return Object.keys(_readAll()).length > 0;
}

/** الحالة المطلوبة المعلّقة (لم تصل الخادم بعد) لهذا الهدف، أو undefined. تُستخدم لتلوين الأزرار بعد إعادة فتح الصفحة. */
export function getPendingReaction(kind, targetId, uid) {
  if (!uid) return undefined;
  return _readAll()[_keyOf(kind, targetId, uid)]?.desired;
}

/** كل المعلّق من نوع معيّن للحساب الحالي (لوسم الأزرار بعد رسم القائمة). */
export function listPendingReactions(kind, uid) {
  return Object.values(_readAll()).filter(e => e.kind === kind && e.uid === String(uid));
}

async function _send(e) {
  const { voteIdea, setOccasionLike } = await import('../data/db.js');
  return e.kind === 'idea-vote'
    ? voteIdea(e.targetId, e.uid, e.desired)
    : setOccasionLike(e.targetId, e.uid, e.desired);
}

const _inflight = new Set();

/**
 * يرسل الحالة المطلوبة لهذا المفتاح حتى يفرغ الطابور له.
 * interactive=true: الفشل النهائي يُرمى للصفحة لتتراجع وتعرض رسالتها.
 * interactive=false (خلفية): الفشل النهائي يُطلق akdar:reaction-failed ويُعرض toast.
 * @returns {Promise<{pending: boolean, result?: object, transient?: boolean}>}
 */
async function _drain(key, interactive) {
  if (_inflight.has(key)) return { pending: true }; // إرسال جارٍ لنفس المفتاح — سيلتقط الحلقة آخر rev
  _inflight.add(key);
  let last = null;
  try {
    for (;;) {
      const e = _readAll()[key];
      if (!e) return last ? { pending: false, result: last } : { pending: false };

      if (Date.now() - e.at > MAX_AGE_MS) { _removeIfRev(key, e.rev); continue; }

      // الإرسال يكون بالحساب الحالي فقط (حساب آخر سجّل دخوله على نفس الجهاز: نتركها له)
      const { getCurrentUser } = await import('../data/auth.js');
      if (String(getCurrentUser()?.uid || '') !== e.uid) return { pending: true };

      let res;
      try {
        res = await _send(e);
      } catch (err) {
        // شبكة/ضغط، أو فشل غير مفهوم (جلسة لم تجهز، خطأ عابر بالخادم…): يبقى بالطابور والمستخدم يراه ناجحًا
        if (isTransientFailure(err)) return { pending: true, transient: true };
        if (shouldQueue(err) && _bumpTries(key, e.rev) < MAX_UNKNOWN_TRIES) return { pending: true, transient: true };
        _removeIfRev(key, e.rev); // رفض نهائي مؤكّد (أو فشل متكرر بلا أمل): لا فائدة من التكرار
        if (interactive) throw err;
        window.dispatchEvent(new CustomEvent('akdar:reaction-failed', {
          detail: { kind: e.kind, targetId: e.targetId, desired: e.desired, message: err?.message || '' },
        }));
        try {
          const { showToast } = await import('./toast.js');
          showToast(err?.message || 'تفاعلك ما اتسجّل — جرّب تاني', 'error');
        } catch { /* اختياري */ }
        return { pending: false };
      }

      last = res;
      _removeIfRev(key, e.rev);
      window.dispatchEvent(new CustomEvent('akdar:reaction-synced', {
        detail: { kind: e.kind, targetId: e.targetId, uid: e.uid, desired: e.desired, result: res },
      }));
      // لو وصلت rev أحدث أثناء الإرسال ستلتقطها الدورة التالية؛ وإلا يفرغ الطابور ونخرج
    }
  } finally {
    _inflight.delete(key);
  }
}

async function _react(kind, targetId, uid, desired) {
  if (!KINDS.includes(kind)) throw new Error('نوع تفاعل غير معروف');
  _put(kind, targetId, uid, desired);
  // بلا شبكة فعلية: لا نضيّع ١٥ ثانية في انتظار مهلة — يبقى معلّقًا فورًا
  if (typeof navigator !== 'undefined' && navigator.onLine === false) return { pending: true };
  return _drain(_keyOf(kind, targetId, uid), true);
}

/**
 * أؤيد/لا أؤيد على فكرة.
 * @returns {Promise<{pending: boolean, result?: {votesUp:number, votesDown:number}}>}
 */
export function sendIdeaVote(ideaId, uid, value) {
  return _react('idea-vote', ideaId, uid, value);
}

/**
 * إعجاب/إلغاء إعجاب بمناسبة (الحالة المطلوبة، لا قلب).
 * @returns {Promise<{pending: boolean, result?: {liked:boolean, likesCount:number}}>}
 */
export function sendOccasionLike(occasionId, uid, liked) {
  return _react('occasion-like', occasionId, uid, !!liked);
}

// ── الإرسال الخلفي ────────────────────────────────────────────────
let _failStreak = 0; // نمدّ الفاصل (٣٠ث ← ٥ دقائق) كي لا نضغط خادمًا مشغولًا
let _nextAt = 0;

export async function flushReactions() {
  if (!navigator.onLine || !_hasQueued() || Date.now() < _nextAt) return;
  let stillPending = false;
  for (const key of Object.keys(_readAll())) {
    const out = await _drain(key, false);
    if (out.transient) stillPending = true;
  }
  if (stillPending) {
    _failStreak = Math.min(_failStreak + 1, 6);
    _nextAt = Date.now() + Math.min(30000 * 2 ** (_failStreak - 1), 300000) + Math.random() * 10000;
  } else { _failStreak = 0; _nextAt = 0; }
}

// عودة الاتصال: نبدأ من جديد (مع تفريق عشوائي حتى لا تعود آلاف الأجهزة معًا)
window.addEventListener('online', () => { _nextAt = 0; setTimeout(flushReactions, Math.random() * 8000); });
// جلسة سابقة تركت طابورًا والشبكة متوفرة الآن؟ نحاول فورًا
flushReactions();
// بعض أجهزة أندرويد لا تُطلق 'online' بثبات — محاولة احتياطية خفيفة طول ما يوجد معلّق
setInterval(() => { if (_hasQueued()) flushReactions(); }, 30000);
