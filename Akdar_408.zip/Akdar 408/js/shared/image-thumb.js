// js/shared/image-thumb.js — شبتوت بحري
// ══════════════════════════════════════════════════════════════
//  النسخة المصغّرة للصور في القوائم والبطاقات (توفير نقل بيانات Supabase).
//  image-upload-field.js يرفع مع كل صورة جديدة نسخة مصغّرة باسم  <الاسم>_t.<الامتداد>.
//  هنا نشتق رابطها من رابط الأصلية — فقط للصور المرفوعة بعد THUMB_EPOCH (قبلها لا توجد نسخة مصغّرة،
//  فنتجنب طلبًا فاشلًا لكل صورة قديمة). لو غابت النسخة لأي سبب نعود للأصلية تلقائيًا (مستمع error أدناه).
//  الصور القديمة تبقى كما هي، والصفحات التي تعرض الصورة كبيرة (القارئ/التفاصيل/العارض) تستخدم الأصلية.
// ══════════════════════════════════════════════════════════════

import { escapeHtml } from './sanitize.js';

// وقت تفعيل رفع النسخ المصغّرة (ms). عدّله إلى وقت النشر الفعلي إن شئت؛ الصور الأقدم تبقى بلا اشتقاق.
const THUMB_EPOCH = 1792088511608;

const _RE = /^(https:\/\/[^/]+\/storage\/v1\/object\/public\/akdar-images\/(?:[a-zA-Z0-9_-]+\/)*(\d{13})-[0-9a-f]{12})\.(webp|jpg|png)$/;

/** رابط النسخة المصغّرة لو متوقعة، وإلا الرابط كما هو. */
export function thumbUrl(url) {
  const m = typeof url === 'string' ? _RE.exec(url) : null;
  if (!m || Number(m[2]) < THUMB_EPOCH) return url;
  return `${m[1]}_t.${m[3]}`;
}

/** سمات <img> جاهزة: src للمصغّرة + data-full-src للأصلية (للرجوع عند الفشل). */
export function thumbImgAttrs(url) {
  const t = thumbUrl(url);
  return t === url
    ? `src="${escapeHtml(url)}"`
    : `src="${escapeHtml(t)}" data-full-src="${escapeHtml(url)}"`;
}

// error لا ينتشر (bubble) لكنه يُلتقط في مرحلة capture: مستمع واحد للصفحة كلها، متوافق مع CSP بلا سمات inline.
if (typeof window !== 'undefined' && typeof document !== 'undefined' && !window.__akdarThumbFallback) {
  window.__akdarThumbFallback = true;
  document.addEventListener('error', (e) => {
    const img = e.target;
    if (!img || img.tagName !== 'IMG') return;
    const full = img.getAttribute('data-full-src');
    if (!full) return;
    img.removeAttribute('data-full-src'); // مرة واحدة فقط، لا حلقة
    img.src = full;
  }, true);
}
