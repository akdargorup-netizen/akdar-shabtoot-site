// js/shared/abadol-sound.js — شبتوت بحري
// ═══════════════════════════════════════════════════════════════════
//  مؤثرات لعبة آنداندي: نقرات أوتار قريبة من الكِسِر (الليرة النوبية)، مولَّدة
//  برمجيًا بـ Web Audio API — لا ملفات صوتية، لا طلبات شبكة، لا مساحة إضافية.
//  السلّم خماسي (ري صول لا ري) لإحساس نوبي هادئ، وكل النغمات منخفضة الصوت.
//
//  تحسين بحت: أي فشل (متصفح قديم، سياق صوت مرفوض) يُتجاهَل بصمت ولا يوقف
//  اللعبة. المفتاح (تشغيل/إيقاف) محفوظ على جهاز اللاعب في localStorage.
//  لا يتشارك سياق الصوت مع sound-fx.js (ذاك للإعجاب والتعليقات).
// ═══════════════════════════════════════════════════════════════════

const STORE_KEY = 'andandi_game_sound';

// ─── مفتاح التشغيل (الافتراضي: مفعّل) ───────────────────────────────
export function isSoundOn() {
  try { return localStorage.getItem(STORE_KEY) !== 'off'; } catch { return true; }
}
export function setSoundOn(on) {
  try { localStorage.setItem(STORE_KEY, on ? 'on' : 'off'); } catch { /* بلا حفظ */ }
}

// ─── سياق الصوت ──────────────────────────────────────────────────
let _ctx = null;
function _context() {
  const Ctor = window.AudioContext || window.webkitAudioContext;
  if (!Ctor) return null;
  if (!_ctx) _ctx = new Ctor();
  return _ctx;
}

// تُستدعى من أول لمسة داخل اللعبة (داخل حدث ضغط) لتصحية المحرّك قبل أول صوت.
export function unlockAudio() {
  try {
    const ctx = _context();
    if (ctx && ctx.state === 'suspended') ctx.resume().catch(() => {});
  } catch { /* تحسين فقط */ }
}

function _playWhenReady(build) {
  if (!isSoundOn()) return;
  try {
    const ctx = _context();
    if (!ctx) return;
    if (ctx.state === 'running') { build(ctx, ctx.currentTime); return; }
    ctx.resume().then(() => build(ctx, ctx.currentTime)).catch(() => {});
  } catch { /* تحسين فقط */ }
}

// ─── نقرة وتر: مثلثة + جيبية أخف في الأوكتاف، مع فلتر يُغلق سريعًا (نقر الوتر) ─
function _pluck(ctx, { freq, start, gain = 0.16, decay = 0.7 }) {
  const out = ctx.createGain();
  out.gain.setValueAtTime(0, start);
  out.gain.linearRampToValueAtTime(gain, start + 0.006);
  out.gain.exponentialRampToValueAtTime(0.0001, start + decay);

  const lp = ctx.createBiquadFilter();
  lp.type = 'lowpass';
  lp.frequency.setValueAtTime(freq * 7, start);
  lp.frequency.exponentialRampToValueAtTime(freq * 1.6, start + decay * 0.6);

  const body = ctx.createOscillator();
  body.type = 'triangle';
  body.frequency.setValueAtTime(freq, start);

  const over = ctx.createOscillator();
  const og = ctx.createGain();
  over.type = 'sine';
  over.frequency.setValueAtTime(freq * 2, start);
  og.gain.setValueAtTime(0.35, start);

  body.connect(lp);
  over.connect(og); og.connect(lp);
  lp.connect(out); out.connect(ctx.destination);

  const end = start + decay + 0.03;
  let left = 2;
  const done = () => {
    if (--left > 0) return;
    [body, over, og, lp, out].forEach(n => { try { n.disconnect(); } catch { /* مفصول */ } });
  };
  body.onended = done; over.onended = done;
  body.start(start); over.start(start);
  body.stop(end); over.stop(end);
}

// الخماسي: ري٤ صول٤ لا٤ ري٥ صول٥ (هرتز)
const D4 = 293.66, G4 = 392.0, A4 = 440.0, D5 = 587.33, G5 = 784.0, E4 = 329.63;

/** لمسة خفيفة (اختيار زوج في المطابقة / فتح الصوت) */
export function playTap() {
  _playWhenReady((ctx, t) => _pluck(ctx, { freq: E4, start: t, gain: 0.10, decay: 0.35 }));
}

/** بدء جولة */
export function playStart() {
  _playWhenReady((ctx, t) => {
    _pluck(ctx, { freq: D4, start: t, gain: 0.13, decay: 0.55 });
    _pluck(ctx, { freq: G4, start: t + 0.12, gain: 0.13, decay: 0.7 });
  });
}

/** إجابة صحيحة: نغمتان صاعدتان */
export function playCorrect() {
  _playWhenReady((ctx, t) => {
    _pluck(ctx, { freq: G4, start: t, gain: 0.16, decay: 0.55 });
    _pluck(ctx, { freq: D5, start: t + 0.09, gain: 0.17, decay: 0.8 });
  });
}

/** توصيل زوج صحيح في المطابقة */
export function playPair() {
  _playWhenReady((ctx, t) => {
    _pluck(ctx, { freq: A4, start: t, gain: 0.15, decay: 0.45 });
    _pluck(ctx, { freq: D5, start: t + 0.07, gain: 0.15, decay: 0.5 });
  });
}

/** إجابة خاطئة: نغمتان هابطتان هادئتان (لا صوت رفض حاد) */
export function playWrong() {
  _playWhenReady((ctx, t) => {
    _pluck(ctx, { freq: A4 / 2, start: t, gain: 0.17, decay: 0.5 });
    _pluck(ctx, { freq: D4 * 0.75, start: t + 0.1, gain: 0.17, decay: 0.65 });
  });
}

/** نتيجة الجولة: arpeggio صاعد يطول بعدد النجوم */
export function playResult(stars) {
  _playWhenReady((ctx, t) => {
    if (stars <= 0) { _pluck(ctx, { freq: D4, start: t, gain: 0.16, decay: 0.9 }); return; }
    const notes = [D4, G4, A4, D5, G5].slice(0, stars === 1 ? 3 : stars === 2 ? 4 : 5);
    notes.forEach((f, i) => _pluck(ctx, { freq: f, start: t + i * 0.11, gain: 0.16, decay: i === notes.length - 1 ? 1.1 : 0.6 }));
  });
}

/** صوت آبادول: عزفة قصيرة على الكِسِر تناسب حالته (ترحيب/تفكير/فرح/حماس/فوز/حزن) عند لمسه أو نطقه */
export function playAbadolVoice(mood = 'hi') {
  const seq = {
    hi:    [D4, G4, A4],
    think: [A4, G4, E4],
    happy: [G4, D5, G5],
    cheer: [D4, G4, D5, G5],
    win:   [D4, G4, A4, D5, G5],
    sad:   [A4, E4, D4],
    time:  [A4, E4],
  }[mood] || [D4, G4, A4];
  _playWhenReady((ctx, t) => seq.forEach((f, i) =>
    _pluck(ctx, { freq: f, start: t + i * 0.12, gain: 0.15, decay: i === seq.length - 1 ? 0.95 : 0.55 })));
}
