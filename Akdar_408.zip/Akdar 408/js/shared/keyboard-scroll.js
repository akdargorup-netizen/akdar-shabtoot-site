// js/shared/keyboard-scroll.js — شبتوت بحري
// ═══════════════════════════════════════════════════════════════════
// v158 — إعادة كتابة كاملة: الكيبورد يُقاس فعليًا، والحاوية تتكيّف معه.
//
// المشكلة القديمة: كنا بنضيف padding-bottom تحت الحاوية (٥٥vh ثابتة،
// أو ارتفاع الكيبورد + ٢٤px) عشان "نخلق" مساحة تمرير. النتيجة فراغ
// فاضي ظاهر تحت الحقل ("مساحة تنفّس") وتعارض مع أشرطة الكتابة الملتصقة
// بأسفل الشاشة (sticky composer) اللي اضطرينا نعطّلها مؤقتًا.
//
// الحل الجديد: مفيش أي padding مصطنع. بدل كده:
//   ١) نقيس المنطقة المرئية فعلاً (visualViewport + window.innerHeight
//      مقارنةً بالارتفاع الأصلي قبل فتح الكيبورد) — الإشارتين مع بعض
//      بتغطّي الحالتين: كروم بـ interactive-widget=resizes-content
//      (الصفحة نفسها بتصغر) والحالة اللي الكيبورد فيها بيغطي الصفحة.
//   ٢) نكتب الجزء المغطّى في متغيّر CSS اسمه --kb-inset ونحط كلاس
//      kb-open على <body>. الـCSS (layout.css / modal.css) بيقصّ
//      حاوية التمرير والمودال على المنطقة المرئية بالظبط، ويخفي الشريط
//      السفلي أثناء الكتابة عشان ما ياكلش مساحة فوق الكيبورد.
//   ٣) نمرّر الحقل بالمسافة الناقصة بس (لو محتاج) داخل المنطقة المرئية
//      — مش بنتوقّع ولا نخمّن.
//
// احتياطي (للـWebViews اللي ما بتديش أي إشارة قياس): لو بعد ~٦٠٠ms من
// التركيز على حقل كتابة على جهاز لمس ما وصلناش أي تغيّر في المنطقة
// المرئية، بنفترض كيبورد بنسبة ثابتة من الشاشة (٤٥%) لحد ما نتأكد من
// قياس حقيقي أو يفقد الحقل التركيز. ده آخر حل، مش الأساسي.
// ═══════════════════════════════════════════════════════════════════

const KB_MIN_PX        = 100;  // أقل نقصان في الارتفاع نعتبره كيبورد (أشرطة المتصفح أصغر من كده)
const EDGE_GAP_PX      = 12;   // هامش بسيط بين الحقل وحافة المنطقة المرئية
const SYNC_DELAYS_MS   = [120, 320]; // إعادة قياس بعد التركيز (أنيميشن الكيبورد على أجهزة أبطأ)
const NO_SIGNAL_MS     = 600;  // انتظار قبل اللجوء للاحتياطي
const FALLBACK_RATIO   = 0.45; // نسبة الكيبورد من الشاشة في الاحتياطي فقط
const INPUT_DEBOUNCE_MS = 100;
const BLUR_GRACE_MS    = 200;  // انتقال سريع بين حقلين ما يفتحش ويقفل الكيبورد

const _root = document.documentElement;
const _vv   = window.visualViewport || null;

let _baseH        = window.innerHeight; // ارتفاع الصفحة والكيبورد مقفول
let _field        = null;               // حقل الكتابة المركّز عليه
let _fallbackOn   = false;
let _raf          = 0;
let _noSignalTimer = 0;
let _blurTimer    = 0;
let _inputTimer   = 0;
let _syncTimers   = [];

// ─── أدوات ────────────────────────────────────────────────────────

/** حقول بتفتح كيبورد فعلاً (مش checkbox/زرار/select...). */
function _isTextEntry(el) {
  if (!el || el.nodeType !== 1) return false;
  if (el.isContentEditable) return true;
  if (el.tagName === 'TEXTAREA') return true;
  if (el.tagName !== 'INPUT') return false;
  return !/^(button|submit|reset|checkbox|radio|range|file|color|image|hidden)$/i.test(el.type);
}

const _isTouchDevice = () => window.matchMedia('(pointer: coarse)').matches;

/** المنطقة المرئية الفعلية بإحداثيات الـlayout viewport. */
function _measure() {
  const scale = _vv ? _vv.scale : 1;
  if (_vv && scale > 1.01) {
    // المستخدم عامل تكبير (pinch) — ارتفاع visualViewport بيصغر لسبب مالوش
    // علاقة بالكيبورد، فما نقيسش.
    return { shrunk: 0, covered: 0, visTop: 0, visBottom: window.innerHeight };
  }
  const layoutH   = window.innerHeight;
  const visTop    = _vv ? _vv.offsetTop : 0;
  const visH      = _vv ? _vv.height : layoutH;
  const visBottom = visTop + visH;
  return {
    shrunk:  _baseH - visH,                    // إجمالي اللي اتاكل من الارتفاع الأصلي
    covered: Math.max(0, layoutH - visBottom), // الجزء اللي لسع مغطّى فوق الصفحة (مش مصغّرها)
    visTop,
    visBottom,
  };
}

function _apply(open, covered) {
  _root.style.setProperty('--kb-inset', `${Math.round(covered)}px`);
  document.body.classList.toggle('kb-open', open);
}

/** أقرب حاوية تمرير فعلية للحقل (مودال أو .app-content أو أي حاوية وسيطة). */
function _scrollParent(el) {
  for (let p = el.parentElement; p && p !== document.body; p = p.parentElement) {
    const oy = getComputedStyle(p).overflowY;
    if ((oy === 'auto' || oy === 'scroll') && p.scrollHeight > p.clientHeight + 1) return p;
  }
  return el.closest('.modal, .app-content');
}

/** يظهّر الحقل داخل المنطقة المرئية بأقل تمرير لازم — لو ظاهر أصلاً مفيش حركة. */
function _reveal() {
  if (!_field || !_field.isConnected) return;
  const sc = _scrollParent(_field);
  if (!sc) return;

  const m   = _measure();
  const box = sc.getBoundingClientRect();
  const top    = Math.max(box.top, m.visTop) + EDGE_GAP_PX;
  const bottom = Math.min(box.bottom, m.visBottom) - EDGE_GAP_PX;
  const r = _field.getBoundingClientRect();

  let dy = 0;
  if (r.top < top) {
    dy = r.top - top;                                  // فوق المنطقة المرئية → نطلّعه
  } else if (r.bottom > bottom) {
    dy = Math.min(r.bottom - bottom, r.top - top);     // تحت → ننزّله، بس من غير ما قمّته تختفي (حقل طويل)
  }
  if (Math.abs(dy) > 1) sc.scrollBy({ top: dy });
}

// ─── الحالة ───────────────────────────────────────────────────────

function _release() {
  clearTimeout(_noSignalTimer);
  clearTimeout(_blurTimer);
  clearTimeout(_inputTimer);
  _syncTimers.forEach(clearTimeout);
  _syncTimers = [];
  _field = null;
  _fallbackOn = false;
  _apply(false, 0);
}

/** يقيس ويطبّق. بيتنادى عند التركيز، وعند أي تغيّر في المنطقة المرئية. */
function _sync() {
  if (!_field || !_field.isConnected) { _release(); return; }

  const m = _measure();
  if (m.shrunk > KB_MIN_PX) {
    // قياس حقيقي — بيلغي أي احتياطي.
    clearTimeout(_noSignalTimer);
    _fallbackOn = false;
    _apply(true, m.covered);
    _reveal();
  } else if (!_fallbackOn) {
    // الكيبورد اتقفل (مثلاً زرار الرجوع في أندرويد بيقفله والحقل لسع مركّز).
    _apply(false, 0);
  }
}

/** بداية دورة كتابة على حقل (تركيز أو لمسة تانية على حقل مركّز أصلاً). */
function _arm(field) {
  clearTimeout(_blurTimer);
  clearTimeout(_noSignalTimer);
  _syncTimers.forEach(clearTimeout);

  _field = field;
  _sync();
  _syncTimers = SYNC_DELAYS_MS.map(ms => setTimeout(_sync, ms));

  if (!_isTouchDevice()) return; // لوحة مفاتيح فعلية — مفيش كيبورد على الشاشة أصلاً
  _noSignalTimer = setTimeout(() => {
    if (!_field || !_field.isConnected) return;
    if (_measure().shrunk > KB_MIN_PX) return; // وصلت إشارة حقيقية
    _fallbackOn = true;
    _apply(true, Math.round(window.innerHeight * FALLBACK_RATIO));
    _reveal();
  }, NO_SIGNAL_MS);
}

// ─── مستمعات الأحداث ─────────────────────────────────────────────

function _onFocusIn(e) {
  if (_isTextEntry(e.target)) _arm(e.target);
}

// لمسة على حقل مركّز أصلاً بعد ما الكيبورد اتقفل (زرار الرجوع) — focusin
// ما بيتطلقش تاني، فنعيد الدورة من هنا.
function _onPointerUp(e) {
  if (_isTextEntry(e.target) && e.target === document.activeElement && e.target === _field) _arm(e.target);
}

function _onFocusOut(e) {
  if (e.target !== _field) return;
  clearTimeout(_blurTimer);
  _blurTimer = setTimeout(() => {
    if (_isTextEntry(document.activeElement)) return; // انتقل لحقل تاني
    _release();
  }, BLUR_GRACE_MS);
}

// أثناء الكتابة (textarea بيكبر، سطر جديد): نتأكد إن مكان الكتابة لسع ظاهر.
function _onInput(e) {
  if (e.target !== _field) return;
  clearTimeout(_inputTimer);
  _inputTimer = setTimeout(() => {
    if (document.body.classList.contains('kb-open')) _reveal();
  }, INPUT_DEBOUNCE_MS);
}

function _onViewportChange() {
  if (!_field) {
    // مفيش حقل مركّز = الكيبورد مقفول: نحدّث الارتفاع الأصلي (دوران الشاشة/أشرطة المتصفح).
    _baseH = Math.max(window.innerHeight, _vv ? _vv.height * (_vv.scale || 1) : 0);
    return;
  }
  cancelAnimationFrame(_raf);
  _raf = requestAnimationFrame(_sync);
}

// حقل اتشال من الصفحة (مودال اتقفل، تغيير صفحة) من غير focusout — ننضّف.
function _validate() {
  if (_field && !_field.isConnected) _release();
}

export function initKeyboardScroll() {
  document.addEventListener('focusin',  _onFocusIn);
  document.addEventListener('focusout', _onFocusOut);
  document.addEventListener('input',    _onInput, true);
  document.addEventListener('pointerup', _onPointerUp, true);
  document.addEventListener('pointerdown', () => setTimeout(_validate, 350), true);
  window.addEventListener('hashchange', () => setTimeout(_validate, 300));
  window.addEventListener('popstate',   () => setTimeout(_validate, 300));

  window.addEventListener('resize', _onViewportChange);
  window.addEventListener('orientationchange', () => {
    // بعد الدوران الارتفاع الأصلي بيتغيّر — نعيد القياس لما يستقر.
    setTimeout(() => { if (!_field) _baseH = window.innerHeight; }, 350);
  });
  if (_vv) {
    _vv.addEventListener('resize', _onViewportChange);
    _vv.addEventListener('scroll', _onViewportChange);
  }
}
