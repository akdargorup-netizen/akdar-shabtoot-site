// js/shared/notif-prefs.js — شبتوت بحري
// ══════════════════════════════════════════════════════════════
//  مرآة IndexedDB لتفضيلات تصنيفات الإشعارات (settings-notifications.js).
//
//  ليه IndexedDB مش بس localStorage؟ لأن service-worker.js هو اللي
//  بيستقبل الـ push ويقرر يعرضه ولا لأ (حدث 'push')، وservice worker
//  مالوش وصول لـlocalStorage أبداً (قيد من المتصفح، مش نقص كود) —
//  IndexedDB هو التخزين المشترك الوحيد بين الصفحة والـ service worker.
//
//  الاستخدام: صفحة الإعدادات تفضل تكتب/تقرا من localStorage زي ما هي
//  (مفيش تغيير هناك لسرعة القراءة المتزامنة في الواجهة) وبعدين تنادي
//  setPref() هنا كمان عشان تتزامن النسخة اللي service-worker.js
//  بيقرا منها.
// ══════════════════════════════════════════════════════════════

const DB_NAME    = 'shabtoot-prefs';
const STORE_NAME = 'notif-toggles';
const DB_VERSION = 1;

function _openDb() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      if (!req.result.objectStoreNames.contains(STORE_NAME)) {
        req.result.createObjectStore(STORE_NAME);
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror   = () => reject(req.error);
  });
}

/** يكتب قيمة تصنيف واحد (key من NOTIF_GROUPS) في IndexedDB */
export async function setPref(key, value) {
  try {
    const db = await _openDb();
    await new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      tx.objectStore(STORE_NAME).put(!!value, key);
      tx.oncomplete = resolve;
      tx.onerror    = () => reject(tx.error);
    });
    db.close();
  } catch (e) {
    console.warn('[notif-prefs] فشل كتابة التفضيل', key, e);
  }
}

/** يزامن كل تفضيلات localStorage الحالية دفعة واحدة إلى IndexedDB
 *  (يُنادى مرة عند تحميل صفحة الإعدادات عشان يضمن إن IndexedDB
 *  محدّثة حتى لو المستخدم غيّر السويتشات في نسخة قديمة قبل هذا التحديث) */
export async function syncAllPrefsFromLocalStorage(keys) {
  try {
    const db = await _openDb();
    await new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      keys.forEach((key) => {
        const raw = localStorage.getItem(key);
        const value = raw === null ? true : raw === 'true';
        store.put(value, key);
      });
      tx.oncomplete = resolve;
      tx.onerror    = () => reject(tx.error);
    });
    db.close();
  } catch (e) {
    console.warn('[notif-prefs] فشل مزامنة التفضيلات', e);
  }
}
