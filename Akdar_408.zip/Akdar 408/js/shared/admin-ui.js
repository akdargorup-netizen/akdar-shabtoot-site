// js/shared/admin-ui.js — شبتوت بحري
// ═══════════════════════════════════════════════════════════════════
//  مساعدات مشتركة لصفحات لوحة الإدارة، هدفها إن المشرف (مش بس المطوّر)
//  يفهم اللوحة ويستخدمها بثقة:
//
//   • canHardDelete()  — الحذف النهائي للمطوّر بس. سياسات RLS في Supabase بتحصر
//     delete في token.owner، فبنخفي زراير الحذف وتنظيف الأرشيف عن
//     المشرف بدل ما يضغطها ويطلع له خطأ. المشرف عنده "أرشفة" بدلها.
//   • confirmDelete()  — نافذة تأكيد حذف باسم العنصر نفسه (بدل confirm()
//     الافتراضية للمتصفح اللي بتقول "حذف هذا الخبر؟" بلا اسم).
//   • confirmPurge()   — نفس الشيء لتنظيف الأرشيف نهائياً.
//   • confirmAction()  — تأكيد عام لأي فعل حساس تاني (استيراد، رفع حظر...).
// ═══════════════════════════════════════════════════════════════════

import { getAdminRole } from '../data/admin-auth.js';
import { openConfirm } from './confirm-modal.js';
import { escapeHtml } from './sanitize.js';
import { renderIcons } from './icons.js';

/** الحذف النهائي وتنظيف الأرشيف: دور المطوّر بس (يطابق سياسات RLS في Supabase). */
export function canHardDelete() {
  return getAdminRole() === 'developer';
}

/** اسم العنصر المعروض في صفه (عنوان الصف) — للاستخدام في رسالة التأكيد. */
export function rowTitle(el) {
  const row = el?.closest?.('.admin-content-row, .settings-item, .admin-gallery-tile');
  const title = row?.querySelector('h4, [class*="__title"]')?.textContent?.trim();
  return title || '';
}

/**
 * تأكيد حذف نهائي.
 * @param {{ what: string, name?: string, note?: string }} o
 *   what: "الخبر" / "المناسبة"... — name: عنوان العنصر — note: تنبيه إضافي
 * @returns {Promise<boolean>}
 */
export function confirmDelete({ what, name = '', note = '' } = {}) {
  const target = name ? `${escapeHtml(what)} «${escapeHtml(name)}»` : escapeHtml(what);
  return openConfirm({
    title: `حذف ${escapeHtml(what)} نهائياً؟`,
    message: `${target} حيتحذف ولا يمكن استرجاعه.${note ? ' ' + escapeHtml(note) : ''}`,
    confirmLabel: 'احذف نهائياً',
    cancelLabel: 'تراجع',
    danger: true,
    icon: 'trash-2',
  });
}

/** تأكيد تنظيف الأرشيف نهائياً (what مثلاً: "الأخبار المؤرشفة"). */
export function confirmPurge({ what } = {}) {
  return openConfirm({
    title: `حذف ${escapeHtml(what)} نهائياً؟`,
    message: `كل ${escapeHtml(what)} حتتحذف وما بتقدر ترجّعها.`,
    confirmLabel: 'امسح الكل نهائياً',
    cancelLabel: 'تراجع',
    danger: true,
    icon: 'trash-2',
  });
}

/** تأكيد عام. title/message نص عادي — بنعمل لهم escape هنا. */
export function confirmAction({ title, message, confirmLabel = 'موافق', danger = false, icon } = {}) {
  return openConfirm({
    title: escapeHtml(title),
    message: escapeHtml(message).replace(/\n/g, '<br>'),
    confirmLabel,
    cancelLabel: 'تراجع',
    danger,
    icon: icon || (danger ? 'alert-triangle' : 'help-circle'),
  });
}


// ═══════════════════════════════════════════════════════════════════
//  تحسينات تلقائية لأي صفحة إدارة محتوى — تُستدعى مرة واحدة من init:
//    • بحث داخل القائمة (بيظهر بس لما القائمة تطوّل، وبيتحدّث لوحده
//      كل ما القائمة تتعاد رسمها بعد إضافة/حذف/تعديل)
//    • نص الشرح الطويل أعلى الصفحة بيتطوي لسطرين مع "اقرأ المزيد"
// ═══════════════════════════════════════════════════════════════════


const SEARCH_MIN_ROWS = 6;   // أقل من كده القائمة قصيرة ومافي داعي للبحث
const HELP_CLAMP_CHARS = 130; // نص أقصر من كده يفضل ظاهر كامل

/** توحيد النص العربي للبحث: بدون تشكيل، وأ/إ/آ=ا، ى=ي، ة=ه. */
function _norm(text) {
  return String(text || '')
    .toLowerCase()
    .replace(/[\u064B-\u065F\u0670\u0640]/g, '')
    .replace(/[أإآٱ]/g, 'ا')
    .replace(/ى/g, 'ي')
    .replace(/ة/g, 'ه')
    .replace(/\s+/g, ' ')
    .trim();
}

function _clampHelp(page) {
  const p = page.querySelector('.admin-content-toolbar > p');
  if (!p || p.textContent.trim().length <= HELP_CLAMP_CHARS) return;

  p.classList.add('admin-help-clamped');
  const toggle = document.createElement('button');
  toggle.type = 'button';
  toggle.className = 'admin-help-toggle';
  toggle.textContent = 'اقرأ المزيد';
  toggle.setAttribute('aria-expanded', 'false');
  toggle.addEventListener('click', () => {
    const open = p.classList.toggle('admin-help-clamped') === false;
    toggle.textContent = open ? 'إخفاء' : 'اقرأ المزيد';
    toggle.setAttribute('aria-expanded', String(open));
  });
  p.after(toggle);
}

function _attachSearch(page) {
  const list = page.querySelector('.admin-content-list');
  if (!list || page.querySelector('.admin-list-search')) return;

  const wrap = document.createElement('div');
  wrap.className = 'admin-list-search hidden';
  wrap.innerHTML = `
    <div class="search-bar">
      <span class="search-bar__icon" data-icon="search"></span>
      <input type="search" class="search-bar__input" placeholder="ابحث في القائمة..." aria-label="ابحث في القائمة" autocomplete="off">
    </div>
    <p class="admin-list-search__empty hidden">ما في نتائج مطابقة.</p>
  `;
  list.before(wrap);
  renderIcons(wrap);

  const input = wrap.querySelector('input');
  const empty = wrap.querySelector('.admin-list-search__empty');

  const rowsOf = () => [...list.querySelectorAll(':scope > .admin-content-row')];

  const apply = () => {
    const q = _norm(input.value);
    const rows = rowsOf();
    // يظهر البحث لما القائمة تطول، أو لو المستخدم كاتب فيه أصلاً
    wrap.classList.toggle('hidden', rows.length < SEARCH_MIN_ROWS && !q);

    let shown = 0;
    for (const row of rows) {
      const match = !q || _norm(row.textContent).includes(q);
      row.classList.toggle('admin-row-filtered', !match);
      if (match) shown++;
    }
    empty.classList.toggle('hidden', !(q && rows.length && shown === 0));
  };

  input.addEventListener('input', apply);
  // القائمة بتتعاد رسمها (innerHTML) بعد كل تعديل — نعيد تطبيق الفلتر
  new MutationObserver(apply).observe(list, { childList: true });
  apply();
}

/**
 * @param {Element} page جذر صفحة الإدارة
 * @param {{ search?: boolean }} [o] search:false لو الصفحة ما فيها قائمة صفوف
 */
export function enhanceAdminPage(page, { search = true } = {}) {
  if (!page) return;
  _clampHelp(page);
  if (search) _attachSearch(page);
}
