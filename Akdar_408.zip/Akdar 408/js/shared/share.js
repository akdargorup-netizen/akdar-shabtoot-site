// js/shared/share.js
// Web Share API موحّد — يُستخدم من أي مكان في التطبيق

import { showToast } from './toast.js';

/**
 * يشارك محتوى عبر Web Share API أو ينسخ الرابط كاحتياط
 * @param {{ title: string, text?: string, url?: string }} data
 */
export async function shareContent({ title, text = '', url = location.href }) {
  if (navigator.share) {
    try {
      await navigator.share({ title, text, url });
    } catch (err) {
      // المستخدم ألغى المشاركة — لا نعرض خطأ
      if (err.name !== 'AbortError') {
        fallbackCopy(url);
        showToast('اتنسخ الرابط ✓', 'success');
      }
    }
  } else {
    fallbackCopy(url);
    showToast('اتنسخ الرابط ✓', 'success');
  }
}

function fallbackCopy(text) {
  if (navigator.clipboard) {
    navigator.clipboard.writeText(text).catch(() => legacyCopy(text));
  } else {
    legacyCopy(text);
  }
}

function legacyCopy(text) {
  const ta = document.createElement('textarea');
  ta.value = text;
  ta.style.cssText = 'position:fixed;opacity:0;';
  document.body.appendChild(ta);
  ta.select();
  document.execCommand('copy');
  document.body.removeChild(ta);
}
