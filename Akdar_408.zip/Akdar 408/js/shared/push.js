// js/shared/push.js — شبتوت بحري
// ══════════════════════════════════════════════════════════════
//  طبقة إشعارات Push — Web Push API القياسي (VAPID) + رفع الاشتراكات
//  مركزياً لـ Supabase (push_subscriptions) عبر دالة register_push_subscription.
//
//  ملاحظة: مفتاح VAPID هنا مستقل تماماً عن Firebase — المرسل الفعلي
//  مبني على GitHub Actions بمكتبة web-push، والاشتراكات في Supabase.
//
//  حالة التفعيل الحالية:
//  ✅ VAPID_PUBLIC_KEY مُفعّل — الاشتراك من جهة العميل يعمل فعلياً.
//  ✅ الاشتراكات تُرفع لـ Supabase (push_subscriptions) تلقائياً.
//  ✅ الإرسال الفعلي مُفعّل (sendPush → Supabase Edge Function آمنة
//     → GitHub Actions. التوكن محفوظ فقط كسر في Supabase، ولا يظهر
//     أبداً في كود العميل).
// ══════════════════════════════════════════════════════════════

import { saveNotification }  from '../data/db.js';
import { refreshNotifBadge } from './notif-badge.js';
import { getDeviceId }       from './device-id.js';
import { RUNTIME_CONFIG }     from '../data/runtime-config.js';

// ─── الصق المفتاح العام هنا عند الجاهزية ─────────────────────────────
const VAPID_PUBLIC_KEY = 'BLn2CTxKGtebUDGwDvO-2AB5wgorUQ7e0-xmQLGZWI9R9NlfwG5inZJ_NexXSvpqc5EcPUIxtQWDHXuMhIwGT3c';
// ─────────────────────────────────────────────────────────────────────

const STORAGE_KEY = 'push_subscription';
const UPLOADED_KEY = 'push_subscription_uploaded_v2'; // v2: يُجبر كل الأجهزة على إعادة رفع اشتراكها لـ Supabase مرة واحدة
const UPLOADED_AT_KEY = 'push_subscription_uploaded_at_v2';
const UPLOADED_ENDPOINT_KEY = 'push_subscription_uploaded_endpoint_v2';
// (v413) كان الرفع يتكرر عند كل فتح للتطبيق (كتابة بالقاعدة لكل فتحة). الآن نكتفي بمرة كل ٣ أيام
// لنفس الاشتراك (نفس الـendpoint) — يبقى العلاج الذاتي لو اتفرّغ الجدول (يتصلّح خلال ٣ أيام كحد أقصى).
const UPLOAD_REFRESH_MS = 3 * 24 * 3600 * 1000;
function _uploadIsFresh(subscription) {
  try {
    const at = Number(localStorage.getItem(UPLOADED_AT_KEY) || 0);
    return Boolean(subscription?.endpoint)
      && localStorage.getItem(UPLOADED_ENDPOINT_KEY) === subscription.endpoint
      && at > 0 && Date.now() - at < UPLOAD_REFRESH_MS;
  } catch { return false; }
}
const RESYNC_AFTER_MS = 3 * 24 * 60 * 60 * 1000; // نجدّد تسجيل الجهاز عند الخادم كل ٣ أيام


// ══════════════════════════════════════════════════════════════
//  التهيئة الرئيسية — تُستدعى مرة واحدة من app.js أو settings
// ══════════════════════════════════════════════════════════════

export async function initPush() {
  if (!RUNTIME_CONFIG.enableRealPush) {
    console.info('[Push] معطّل في وضع التطوير');
    return { supported: false, disabled: true };
  }
  if (!('Notification' in window)) {
    console.info('[Push] المتصفح لا يدعم الإشعارات');
    return { supported: false };
  }

  if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
    console.info('[Push] Push API غير متاح على هذا المتصفح');
    return { supported: false };
  }

  // ملاحظة iOS: الإشعارات تعمل فقط بعد إضافة التطبيق للشاشة الرئيسية
  // (Add to Home Screen) على iOS 16.4 فما فوق — حتى لو الإذن "متاح" تقنياً.
  const isIOS = /iphone|ipad|ipod/i.test(navigator.userAgent);
  const isStandalone = window.matchMedia('(display-mode: standalone)').matches
    || window.navigator.standalone === true;

  if (isIOS && !isStandalone) {
    return { supported: true, permission: Notification.permission, requiresInstallOnIOS: true };
  }

  return { supported: true, permission: Notification.permission };
}


// ══════════════════════════════════════════════════════════════
//  طلب الإذن + الاشتراك
// ══════════════════════════════════════════════════════════════

/**
 * يطلب إذن الإشعارات من المستخدم ويشترك في Push.
 *
 * ⚠️ لا ننتظر الاشتراك هنا عمدًا: الإذن نفسه يكون قد تم، أما الاشتراك فيمر عبر
 * خدمة Push البعيدة وقد يتأخر أو يتعلق (شبكة بطيئة/محجوبة، service worker لم
 * يُفعَّل بعد). كان الانتظار هنا يترك زر "جاري التفعيل..." معلّقًا للأبد حتى
 * مع منح الإذن. الاشتراك يكمل في الخلفية، ويُعاد تلقائيًا عند كل فتح للتطبيق
 * (syncPushSubscription) إن لم ينجح.
 * @returns {Promise<'granted'|'denied'|'default'>}
 */
export async function requestPermission() {
  if (!('Notification' in window)) return 'denied';

  let result;
  try {
    result = await Notification.requestPermission();
  } catch (_) {
    result = Notification.permission;
  }

  if (result === 'granted') {
    ensureSubscribed();
  }

  return result;
}

/**
 * يضمن وجود اشتراك Push (وجهة الاشتراك مرفوعة لـ Supabase) في الخلفية —
 * بدون انتظار من المستدعي، وبمهل زمنية حتى لا يعلق شيء. آمن للاستدعاء
 * المتكرر (يشتغل مرة واحدة في كل وقت).
 */
let _subscribing = null;
export function ensureSubscribed() {
  if (!RUNTIME_CONFIG.enableRealPush) return Promise.resolve(null);
  if (_subscribing) return _subscribing;
  _subscribing = _subscribe()
    .catch(() => null)
    .finally(() => { _subscribing = null; });
  return _subscribing;
}

/**
 * يُستدعى عند فتح التطبيق: لو الإذن ممنوح أصلاً (مثلاً من إعدادات الجهاز، أو
 * فشل الاشتراك أول مرة) ولا يوجد اشتراك مرفوع — يحاول الاشتراك الآن.
 */
export function syncPushSubscription() {
  if (!RUNTIME_CONFIG.enableRealPush) return;
  try {
    if (!('Notification' in window) || !('serviceWorker' in navigator) || !('PushManager' in window)) return;
    if (Notification.permission !== 'granted') return;
    // علاج ذاتي: عند كل فتح للتطبيق نعيد رفع الاشتراك الحالي لـ Supabase (upsert رخيص بنفس
    // device_id) بدل الاعتماد على علم محلي "اترفع". العلم كان سبب تعطّل صامت: لو الجدول
    // اتفرّغ أو اتغيّر المشروع يفضل الجهاز مقتنعًا إنه مسجّل ولا يعيد الرفع أبدًا.
    // ensureSubscribed آمن للتكرار (يشتغل مرة واحدة في كل وقت).
    if (_syncedThisSession) return;
    _syncedThisSession = true;
    ensureSubscribed();
  } catch (_) { /* لا شيء يوقف التطبيق */ }
}
let _syncedThisSession = false;

/** يرفض الوعد إن لم ينتهِ خلال المدة (بدل التعليق للأبد) */
function _withTimeout(promise, ms, label) {
  let timer;
  const timeout = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new Error(`timeout:${label}`)), ms);
  });
  return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
}


// ══════════════════════════════════════════════════════════════
//  الاشتراك عبر Push API القياسي
// ══════════════════════════════════════════════════════════════

async function _subscribe() {
  if (!VAPID_PUBLIC_KEY) {
    console.warn('[Push] VAPID_PUBLIC_KEY فارغ — لم يتم الاشتراك بعد');
    return null;
  }

  try {
    const registration = await _withTimeout(navigator.serviceWorker.ready, 15000, 'sw-ready');

    let subscription = await registration.pushManager.getSubscription();
    const existed = Boolean(subscription);

    if (!subscription) {
      subscription = await _withTimeout(registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: _urlBase64ToUint8Array(VAPID_PUBLIC_KEY),
      }), 30000, 'push-subscribe');
    }

    localStorage.setItem(STORAGE_KEY, JSON.stringify(subscription));
    console.info('[Push] تم الاشتراك بنجاح');

    if (existed && _uploadIsFresh(subscription)) return subscription; // مرفوع حديثًا — لا حاجة لكتابة جديدة

    // ارفع الاشتراك لـ Supabase (push_subscriptions) عشان المرسل الموثوق
    // (Cloud Function لاحقاً) يعرف يوصل لكل الأجهزة. فشل الرفع لا يوقف
    // شيء — الاشتراك المحلي والإشعارات داخل التطبيق تفضل شغالة زي ما هي.
    _uploadSubscription(subscription).catch(async (err) => {
      console.error('[Push] فشل رفع الاشتراك لـ Supabase (الاشتراك المحلي سليم):', err);
      // ما كناش بنبلّغ المستخدم بأي حاجة هنا قبل كده — فكان الزرار يبان
      // "بيشتغل" (إذن المتصفح بيتاخد فعلاً) بينما الاشتراك الحقيقي بيفشل
      // بصمت وراه. نبلّغ الآن عشان أي عطل مستقبلي (زي provider مش مفعّل)
      // يبان فوراً بدل ما يتكشف بعد أيام في المرسل (0 اشتراكات).
      try {
        const { showToast } = await import('./toast.js');
        showToast('تسجيل جهازك للإشعارات فشل: ' + (err?.message || err?.code || 'خطأ غير معروف'), 'error', 10000);
      } catch (_) { /* toast اختياري */ }
    });

    return subscription;
  } catch (err) {
    console.error('[Push] فشل الاشتراك:', err);
    try {
      const { showToast } = await import('./toast.js');
      showToast('فشل اشتراك الإشعارات: ' + (err?.message || err?.name || 'خطأ غير معروف'), 'error', 10000);
    } catch (_) { /* toast اختياري */ }
    return null;
  }
}

/**
 * يرفع/يحدّث الاشتراك في جدول push_subscriptions على Supabase عبر الدالة
 * register_push_subscription (الجدول نفسه مقفول — راجع schema.sql)،
 * باستخدام معرّف الجهاز الثابت (device-id.js) — عشان إعادة الاشتراك
 * (نفس الجهاز) تحدّث نفس الصف بدل ما تكرره.
 * @param {PushSubscription} subscription
 */
async function _uploadSubscription(subscription) {
  // (v524) الجلسة المجهولة لا تُنشأ عند فتح التطبيق؛ نضمنها هنا عند الاشتراك فعلاً
  const { ensureSession, getCurrentUser } = await import('../data/auth.js');
  await ensureSession();
  if (!getCurrentUser()?.uid) throw new Error('push-owner-unavailable');

  const { getSupabase } = await import('../data/supabase-client.js');
  const sb = await getSupabase();
  const { error } = await sb.rpc('register_push_subscription', {
    p_device_id: getDeviceId(),
    p_subscription: subscription.toJSON(),
  });
  if (error) throw error;

  try {
    localStorage.setItem(UPLOADED_KEY, '1');
    localStorage.setItem(UPLOADED_AT_KEY, String(Date.now()));
    localStorage.setItem(UPLOADED_ENDPOINT_KEY, String(subscription.endpoint || ''));
  } catch (_) { /* تجاهل */ }
  console.info('[Push] تم رفع الاشتراك لـ Supabase');
}

/** تحويل مفتاح VAPID من Base64Url إلى Uint8Array (مطلوب من Push API) */
function _urlBase64ToUint8Array(base64String) {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
  const rawData = window.atob(base64);
  return Uint8Array.from([...rawData].map((c) => c.charCodeAt(0)));
}


// ══════════════════════════════════════════════════════════════
//  الاستماع للإشعارات (foreground + من الـ service worker)
// ══════════════════════════════════════════════════════════════

/**
 * يبدأ الاستماع للإشعارات القادمة من service-worker.js
 * يحفظها في db ويعرض toast للمستخدم
 */
export function listenForMessages() {
  navigator.serviceWorker?.addEventListener('message', async (event) => {
    if (event.data?.type === 'PUSH_RECEIVED') {
      await _handleIncoming(event.data.payload);
    }
    if (event.data?.type === 'NOTIFICATION_CLICKED') {
      const { navigateTo, hasPage } = await import('../core/router.js');
      const page = event.data.page;
      navigateTo(hasPage(page) ? page : 'notifications', true);
    }
  });
}

async function _handleIncoming({ title, body, page } = {}) {
  // 1. حفظ في db
  await saveNotification({ title, body, page });

  // 2. عرض toast داخل التطبيق (فقط لو التطبيق مفتوح فعلاً)
  try {
    const { showToast } = await import('./toast.js');
    showToast(`🔔 ${title}`, 'info', 5000);
  } catch (_) { /* toast اختياري */ }

  // 3. تحديث شارة التنبيهات في الناف (fresh: الإشعار الجديد لازم يبان فورًا)
  refreshNotifBadge({ fresh: true });
}


// ══════════════════════════════════════════════════════════════
//  نقطة الربط بالمرسل الموثوق — عبر دالة سيرفر آمنة (Supabase Edge Function)
// ══════════════════════════════════════════════════════════════
//  الإرسال الفعلي يشتغل عن طريق نداء دالة سيرفر خاصة بينا
//  (supabase/functions/send-notification)، وهي اللي بتمسك توكن
//  GitHub (GITHUB_DISPATCH_TOKEN) كسر في Supabase — التوكن ما
//  بيتحمّلش أبداً لمتصفح الزائر.
//
//  الدالة نفسها هي اللي بتنادي GitHub Actions (repository_dispatch)،
//  والأتمتة (.github/workflows/send-notification.yml) هي اللي تمسك
//  باقي المفاتيح الحساسة (VAPID الخاص، مفتاح Supabase السري)
//  كـ GitHub Secrets.
// ─────────────────────────────────────────────────────────────────────
const NOTIFY_ENDPOINT = 'https://rtgrkugcokqxseedzunr.supabase.co/functions/v1/send-notification';
// ─────────────────────────────────────────────────────────────────────

/**
 * يطلب من الدالة السيرفر تشغيل المرسل فوراً (بث الرسالة كإشعار Push
 * حقيقي لكل المشتركين — يصل حتى لو التطبيق مغلق تماماً وعلى شاشة
 * القفل). تُستدعى من admin-notifications.js بعد نجاح addNotification.
 * @param {{title: string, body: string, page?: string, type?: string}} payload
 * @param {string} [pushKey] مفتاح الإرسال المرحلي (ADMIN_PUSH_KEY في أسرار Supabase) —
 *   اختياري لو المشرف مسجّل دخول بحساب admin (يُرسل توكنه تلقائيًا). بيتبعت في X-Push-Key.
 * @returns {Promise<{sent: boolean, reason?: string}>}
 */
export async function sendPush(payload, pushKey) {
  if (!RUNTIME_CONFIG.enableRealPush) {
    console.info('[Push] لم يتم إرسال Push: الميزة معطّلة في وضع التطوير');
    return { sent: false, reason: 'disabled-in-development' };
  }
  try {
    // طريقان للتحقق (الدالة بتقبل أيهما): توكن حساب المشرف، ومفتاح الإرسال المرحلي
    const headers = { 'Content-Type': 'application/json' };
    const { getIdToken } = await import('../data/auth.js');
    const idToken = await getIdToken();
    if (idToken) headers['Authorization'] = `Bearer ${idToken}`;
    if (pushKey) headers['X-Push-Key'] = pushKey;

    const res = await fetch(NOTIFY_ENDPOINT, {
      method: 'POST',
      headers,
      body: JSON.stringify(payload),
    });

    const data = await res.json().catch(() => ({}));

    if (!res.ok) {
      console.error('[Push] فشل تشغيل المرسل الفعلي (الحفظ المحلي سليم):', data);
      return { sent: false, reason: data.reason || data.error || 'server-error', status: data.status ?? res.status };
    }

    return { sent: true };
  } catch (err) {
    // فشل تشغيل المرسل لا يوقف أي شيء — الرسالة محفوظة محلياً بأمان أصلاً
    console.error('[Push] فشل تشغيل المرسل الفعلي (الحفظ المحلي سليم):', err);
    return { sent: false, reason: 'network-error' };
  }
}


/** إلغاء الاشتراك وحذفه (محلياً وعلى Supabase) */
export async function unsubscribe() {
  try {
    const registration = await navigator.serviceWorker.ready;
    const subscription = await registration.pushManager.getSubscription();
    if (subscription) await subscription.unsubscribe();
  } catch (err) {
    console.error('[Push] خطأ أثناء إلغاء الاشتراك:', err);
  }

  localStorage.removeItem(STORAGE_KEY);
  console.info('[Push] تم إلغاء الاشتراك');

  // احذف صف الاشتراك من Supabase كمان — فشل الحذف هنا لا يهم كثيراً
  // (المرسل بينظّف الاشتراكات المنتهية الصلاحية أثناء الإرسال)
  try {
    const { waitForAuthReady } = await import('../data/auth.js');
    await waitForAuthReady();
    const { getSupabase } = await import('../data/supabase-client.js');
    const sb = await getSupabase();
    const { error } = await sb.rpc('unregister_push_subscription', { p_device_id: getDeviceId() });
    if (error) throw error;
  } catch (err) {
    console.error('[Push] فشل حذف الاشتراك من Supabase:', err);
  }
}
