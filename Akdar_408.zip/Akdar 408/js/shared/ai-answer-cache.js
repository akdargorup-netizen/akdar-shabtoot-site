// js/shared/ai-answer-cache.js — شبتوت بحري
// ══════════════════════════════════════════════════════════════
//  كاش إجابات المساعد على الجهاز نفسه (localStorage).
//  الغرض: السؤال اللي اتجاوب قبل كده يرجع فورًا بلا شبكة وبلا استهلاك من حصة الذكاء الاصطناعي،
//  والأسئلة المقترحة في الصفحة تُؤخذ من هنا فقط — يعني أي اقتراح يُضغط عليه جاهز من الكاش.
//
//  المفتاح = السؤال بعد التطبيع + بصمة السياق المحلي (نفس فكرة مفتاح الكاش في الخادم):
//  لو اتغيّر محتوى المقالات المرتبط بالسؤال تتغير البصمة والإجابة القديمة ما تُستخدم.
//  ما نخزّن إلا الإجابات اللي لها مصادر (ردّ «لا توجد معلومة» ما يتخزّن).
// ══════════════════════════════════════════════════════════════

const KEY = 'akdar-ai-answers-v1';
const MAX_ENTRIES = 24;
const TTL_MS = 3 * 24 * 60 * 60 * 1000;   // ٣ أيام

const norm = (s) => String(s || '')
  .replace(/[\u064B-\u0652\u0670\u0640]/g, '').replace(/[أإآٱ]/g, 'ا').replace(/ة/g, 'ه').replace(/ى/g, 'ي')
  .replace(/[^\u0621-\u064A0-9\s]/g, ' ').replace(/\s+/g, ' ').trim();

// بصمة خفيفة (djb2) لنص السياق المرسل للنموذج
function fingerprint(items) {
  const s = (items || []).map((i) => `${i.type}\u0001${i.title}\u0001${i.text}`).join('\u0003');
  let h = 5381;
  for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0;
  return String(h >>> 0);
}

function readAll() {
  try {
    const a = JSON.parse(localStorage.getItem(KEY) || '[]');
    return Array.isArray(a) ? a : [];
  } catch { return []; }
}
function writeAll(list) {
  try { localStorage.setItem(KEY, JSON.stringify(list)); } catch { /* ممتلئ/ممنوع — غير حرج */ }
}
const fresh = (e) => e && typeof e.q === 'string' && Date.now() - (e.t || 0) < TTL_MS;

/** إجابة محفوظة لنفس السؤال ونفس السياق، أو null. */
export function getCachedAnswer(question, items) {
  const n = norm(question);
  if (!n) return null;
  const f = fingerprint(items);
  const hit = readAll().find((e) => fresh(e) && e.n === n && e.f === f);
  return hit ? { answer: hit.a, sources: Array.isArray(hit.s) ? hit.s : [] } : null;
}

/** يحفظ إجابة (الأحدث أولًا، سقف MAX_ENTRIES). يتجاهل الإجابات بلا مصادر. */
export function putCachedAnswer(question, items, answer, sources) {
  const n = norm(question);
  if (!n || !answer || !Array.isArray(sources) || !sources.length) return;
  const f = fingerprint(items);
  const list = readAll().filter((e) => fresh(e) && !(e.n === n && e.f === f));
  list.unshift({ q: String(question).trim(), n, f, a: answer, s: sources, t: Date.now() });
  writeAll(list.slice(0, MAX_ENTRIES));
}

/** الأسئلة اللي إجاباتها محفوظة الآن (الأحدث أولًا) — مصدر الأسئلة المقترحة. */
export function cachedQuestions() {
  return readAll().filter(fresh).map((e) => e.q);
}
