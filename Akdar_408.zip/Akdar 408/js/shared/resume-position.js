// js/shared/resume-position.js — شبتوت بحري
// ═══════════════════════════════════════════════════════════════════
//  حفظ وتتبّع "أين توقّف المستخدم" في القوائم الطويلة.
//  لما يرجع للصفحة بعد ما يقفل التطبيق أو يخرج منها، يلاقي نفسه في
//  نفس المكان (مثلًا عند المقال رقم 40) بدل ما يبدأ من أول القائمة.
//
//  • الصفحات المشمولة: RESUME_PAGES تحت (المقالات، الفعاليات،
//    حصص الشهادة المتوسطة والسودانية).
//  • التخزين: localStorage بمفتاح لكل صفحة (sbb:resume:<page>) — محلي
//    بالكامل، بلا شبكة، فيشتغل أوفلاين وعلى النت الضعيف.
//  • الحفظ: مع السكرول (debounce)، وعند مغادرة الصفحة، وعند إخفاء
//    التطبيق (visibilitychange/pagehide) عشان لو اتقفل من الـrecents.
//  • الاستعادة: يتولّاها الراوتر بعد ما تخلص init (القائمة اترسمت
//    بارتفاعها الكامل). رجوع السهم داخل نفس الجلسة له آلية مستقلة
//    (history_stack) وله الأولوية — ده للدخول الجديد فقط.
//  • لو فيه فلتر تصنيف غير "الكل" شغّال لا نحفظ الموضع (الموضع بدون
//    فلتر ما يتطابقش معاه) ونرجع للأعلى عند الدخول.
// ═══════════════════════════════════════════════════════════════════

const KEY_PREFIX = 'sbb:resume:';
const MAX_AGE_MS = 1000 * 60 * 60 * 24 * 60;   // ٦٠ يوم، بعدها نبدأ من الأعلى
const MIN_TOP    = 120;                         // أقل من كدا يعتبر "في الأعلى" — لا نحفظه

export const RESUME_PAGES = new Set([
  'history-articles',             // مقالاتنا
  'events',                       // الفعاليات
  'student-videos-intermediate',  // حصص الشهادة المتوسطة
  'student-videos-secondary',     // حصص الشهادة السودانية
]);

let _armed = false;
let _timer = null;

export const isResumePage = (page) => RESUME_PAGES.has(page);

function _filterIsAll(container) {
  const f = container.querySelector('.filter-chip.active')?.dataset.filter;
  return !f || f === 'all';
}

export function saveResume(page, container) {
  if (!_armed || !isResumePage(page) || !container) return;
  try {
    const top = Math.round(container.scrollTop);
    if (top < MIN_TOP || !_filterIsAll(container)) {
      localStorage.removeItem(KEY_PREFIX + page);
      return;
    }
    localStorage.setItem(KEY_PREFIX + page, JSON.stringify({ top, t: Date.now() }));
  } catch (_) { /* تخزين غير متاح — تجاهل بصمت */ }
}

export function readResume(page) {
  if (!isResumePage(page)) return null;
  try {
    const raw = JSON.parse(localStorage.getItem(KEY_PREFIX + page) || 'null');
    if (!raw || typeof raw.top !== 'number' || raw.top < MIN_TOP) return null;
    if (Date.now() - (raw.t || 0) > MAX_AGE_MS) return null;
    return raw.top;
  } catch (_) { return null; }
}

/** الراوتر ينادي ده قبل تبديل الصفحة: نفضّ الحفظ لحد ما الصفحة الجديدة تستقر. */
export function disarmResume() {
  _armed = false;
  clearTimeout(_timer);
}

/** وبعد ما يحدّد موضع السكرول للصفحة الجديدة. */
export function armResume() {
  _armed = true;
}

/** يُربط مرة واحدة على حاوية المحتوى. */
export function bindResume(container) {
  if (!container || container.__resumeBound) return;
  container.__resumeBound = true;

  const cur = () => container.dataset.currentPage;

  container.addEventListener('scroll', () => {
    if (!_armed || !isResumePage(cur())) return;
    clearTimeout(_timer);
    _timer = setTimeout(() => saveResume(cur(), container), 250);
  }, { passive: true });

  const flush = () => { clearTimeout(_timer); saveResume(cur(), container); };
  document.addEventListener('visibilitychange', () => { if (document.hidden) flush(); });
  window.addEventListener('pagehide', flush);
}
