// js/shared/admin-activity.js — شبتوت بحري
// ══════════════════════════════════════════════════════════════
//  نقطة استدعاء واحدة لكل صفحات الإدارة عشان تسجّل إجراءاتها في
//  "سجل النشاط" (admin-activity-log.js). بتحل هوية الفاعل (الاسم
//  والدور) من جلسة admin-auth.js المحلية تلقائيًا — الصفحات نفسها
//  بس بتبعت "إيش حصل" (action) و"على إيه" (summary).
//
//  ⚠️ الهوية هنا = جلسة admin-auth.js المحلية (نفس القيد الموضّح في
//  تعليقها هي: قفل واجهة محلي، مش صلاحية Firebase حقيقية). يعني لو
//  شخصين بيستخدموا نفس حساب "مشرف" المشترك، السجل هيسجّل اسم الحساب
//  مش الشخص الفعلي. لما يتفعّل ربط الحسابات الحقيقي (Google + custom
//  claims)، الأفضل تحويل المصدر هنا لهوية Firebase Auth بدل الجلسة
//  المحلية — بدون ما يتغيّر أي استدعاء في صفحات الإدارة نفسها.
//
//  فشل التسجيل (مثلاً قاعدة بيانات مقفولة أو نت مقطوع) ما يوقفش
//  الإجراء الإداري الأصلي أبداً — بيتلوج في الكونسول بس.
// ══════════════════════════════════════════════════════════════

import { getAdminRole, getAdminAccountId, getAdminAccounts, getAdminActorName } from '../data/admin-auth.js';
import { logAdminAction as _persistLog, getActivityLog as _fetchLog } from '../data/db.js';

const ROLE_LABEL = { developer: 'مطوّر', admin: 'مشرف', nubian: 'مشرف الرُطانة' };

function _actorName() {
  const real = getAdminActorName(); // وضع claims: اسم حساب جوجل الفعلي
  if (real) return real;
  const id = getAdminAccountId();
  if (id === 'recovery') return 'مفتاح الاسترجاع';
  const account = getAdminAccounts().find(a => a.id === id);
  return account?.name || 'حساب محذوف';
}

/**
 * سجّل إجراءً إداريًا. لا تنتظر (await) نتيجتها إلا لو محتاج تتأكد
 * إنها خلصت — الاستدعاء الطبيعي: `logAdminAction('نشر خبر', title);`
 * بعد نجاح العملية الأصلية مباشرة.
 * @param {string} action وصف قصير للإجراء (زي: "نشر خبر"، "حذف مناسبة")
 * @param {string} [summary] تفاصيل إضافية (زي: عنوان العنصر)
 */
export async function logAdminAction(action, summary = '') {
  try {
    await _persistLog({
      actorName: _actorName(),
      actorRole: ROLE_LABEL[getAdminRole()] || 'غير معروف',
      action,
      summary,
    });
  } catch (err) {
    console.warn('[AdminActivity] فشل تسجيل الإجراء (الإجراء نفسه سليم):', err);
  }
}

/**
 * سجل النشاط الكامل — للعرض في admin-activity-log.js.
 * @param {{ limit?: number }} [options]
 */
export async function getActivityLog(options = {}) {
  return _fetchLog(options);
}
