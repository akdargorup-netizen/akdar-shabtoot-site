// js/shared/secret-trigger.js
// ═══════════════════════════════════════════════════════════════════
// أداة عامة لربط "بوابة سرية" بأي عنصر في الواجهة: عدد نقرات محدد
// خلال نافذة زمنية معيّنة يستدعي callback. لا ترتبط بأي صفحة بعينها —
// تُستخدم لتوزيع نقاط دخول لوحة الإدارة في أماكن غير متوقعة (شعار،
// رقم الإصدار، أيقونة في صفحة "عن التطبيق"، ... إلخ) دون تكرار الكود.
//
// الاستخدام:
//   import { bindSecretTap } from '../shared/secret-trigger.js';
//   bindSecretTap(document.querySelector('.privacy-hero__icon'), {
//     taps: 7,
//     onUnlock: () => { ... },
//   });
// ═══════════════════════════════════════════════════════════════════

/**
 * @param {Element|null} el          العنصر المستهدف (يُتجاهل الطلب إن كان null بأمان)
 * @param {object} opts
 * @param {number} [opts.taps=7]      عدد النقرات المطلوب خلال النافذة الزمنية
 * @param {number} [opts.windowMs=2000] مهلة تصفير العدّاد بين نقرة وأخرى (بالمللي ثانية)
 * @param {() => void} opts.onUnlock  يُستدعى عند اكتمال عدد النقرات
 * @returns {() => void} دالة لإلغاء الربط (تنظيف عند إعادة الرسم)
 */
export function bindSecretTap(el, { taps = 7, windowMs = 2000, onUnlock }) {
  if (!el || typeof onUnlock !== 'function') return () => {};

  let count = 0;
  let timer = null;

  const reset = () => { count = 0; timer = null; };

  const handler = () => {
    count += 1;
    if (timer) clearTimeout(timer);
    timer = setTimeout(reset, windowMs);

    if (count >= taps) {
      reset();
      onUnlock();
    }
  };

  el.addEventListener('click', handler);

  return () => {
    el.removeEventListener('click', handler);
    if (timer) clearTimeout(timer);
  };
}
