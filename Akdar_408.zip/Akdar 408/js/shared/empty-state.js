// js/shared/empty-state.js
// دالة مساعدة تُنتج HTML لحالة "لا يوجد محتوى"

/**
 * @param {object} opts
 * @param {string} opts.icon   - اسم أيقونة Lucide
 * @param {string} opts.title
 * @param {string} [opts.desc]
 */
export function emptyState({ icon = 'inbox', title, desc = '' }) {
  return `
    <div class="empty-state" role="status" aria-label="${title}">
      <i class="empty-state__icon" data-lucide="${icon}"></i>
      <p class="empty-state__title">${title}</p>
      ${desc ? `<p class="empty-state__description">${desc}</p>` : ''}
    </div>
  `;
}

/**
 * فلتر جانب العميل (تصنيف / حالة / "الأسبوع دا") بيخفي الكروت بـ`hidden`
 * أو `display:none` من غير ما يعيد رسم القائمة — فلو الفلتر المختار ما
 * فيه كرت واحد يطابقه، الصفحة كانت بتفضل فاضية تمامًا بلا أي رسالة.
 * هذه الدالة بتُستدعى بعد كل تطبيق فلتر: لو الكروت موجودة وكلها مخفية
 * بتحطّ رسالة "لا يوجد" جوّه نفس القائمة (feed)، ولو ظهر أي كرت بتشيلها.
 * الرسالة جوّه الـfeed نفسه عمدًا، فأي إعادة رسم للقائمة (innerHTML)
 * بتمسحها تلقائيًا من غير حاجة لتنظيف يدوي.
 *
 * ملاحظة: بعد الاستدعاء، الصفحة اللي بتناديها لازم تستدعي renderIcons()
 * لو دايرة أيقونة الرسالة تترسم (نفس قاعدة emptyState() الأصلية).
 *
 * @param {Element|null} feed          حاوية القائمة
 * @param {string}       cardSelector  محدد كروت القائمة (بدون كروت الـskeleton)
 * @param {object}       opts          نفس خيارات emptyState()
 * @returns {boolean} true لو الرسالة اتعرضت
 */
export function syncFilterEmpty(feed, cardSelector, opts = {}) {
  if (!feed) return false;

  feed.querySelector('[data-filter-empty]')?.remove();

  const cards = Array.from(feed.querySelectorAll(cardSelector));
  if (!cards.length) return false; // مفيش كروت أصلاً — ده شغل emptyState() الأساسي مش الفلتر

  const anyVisible = cards.some(card => !card.hidden && card.style.display !== 'none');
  if (anyVisible) return false;

  feed.insertAdjacentHTML('beforeend', `
    <div data-filter-empty>
      ${emptyState({ icon: 'search-x', ...opts })}
    </div>
  `);
  return true;
}
