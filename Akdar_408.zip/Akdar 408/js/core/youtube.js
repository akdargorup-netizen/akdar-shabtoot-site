// js/core/youtube.js — شبتوت بحري
// دوال مشتركة لبناء روابط وثامبنيلات يوتيوب

export const thumb  = id => `https://img.youtube.com/vi/${id}/hqdefault.jpg`;
export const ytLink = id => `https://youtu.be/${id}`;

// ── استخراج youtubeId من أي صيغة رابط يلصقها الأدمن ─────────────
// يدعم: youtu.be/ID ، youtube.com/watch?v=ID ، /shorts/ID ،
// /embed/ID ، /live/ID ، أو ID خام (١١ حرف) بدون رابط أصلاً.
// يرجّع null لو الإدخال مش رابط يوتيوب صالح ولا ID بالشكل المتوقع.
export function extractYouTubeId(input) {
  if (!input) return null;
  const raw = input.trim();

  // ID خام مباشرة (١١ حرف: أحرف/أرقام/شرطة/شرطة سفلية)
  if (/^[\w-]{11}$/.test(raw)) return raw;

  let url;
  try {
    url = new URL(raw);
  } catch {
    return null; // مش رابط صالح ولا ID خام
  }

  const host = url.hostname.replace(/^www\./, '');

  if (host === 'youtu.be') {
    return url.pathname.split('/').filter(Boolean)[0] || null;
  }

  if (host === 'youtube.com' || host === 'm.youtube.com') {
    if (url.searchParams.has('v')) return url.searchParams.get('v');
    const parts = url.pathname.split('/').filter(Boolean);
    if (['shorts', 'embed', 'live'].includes(parts[0])) return parts[1] || null;
  }

  return null;
}
