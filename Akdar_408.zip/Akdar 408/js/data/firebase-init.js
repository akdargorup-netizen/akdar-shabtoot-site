// js/data/firebase-init.js — شبتوت بحري
// ══════════════════════════════════════════════════════════════
//  تهيئة Firebase — لنافذة تسجيل الدخول بجوجل فقط (مشروع akdar-shabtoot).
//  auth.js يحمّلها كسولًا عند الدخول: نافذة جوجل تعطينا Google ID token
//  ثم يُسلَّم لـSupabase (signInWithIdToken) ويُسجَّل خروج Firebase فورًا.
//  البيانات والتخزين والإشعارات كلها على Supabase؛ Firebase للاستضافة
//  ولنافذة جوجل فقط.
// ══════════════════════════════════════════════════════════════

import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.13.0/firebase-app.js';

const firebaseConfig = {
  apiKey:            "AIzaSyAymJsfrCXmPTirS4lRYxHDtpRlA0C7VDk",
  authDomain:        "akdar-shabtoot.firebaseapp.com",
  projectId:         "akdar-shabtoot",
  storageBucket:     "akdar-shabtoot.firebasestorage.app",
  messagingSenderId: "469658689914",
  appId:             "1:469658689914:web:be1a0e2829d5b2a0bbb6c3",
};

export const app = initializeApp(firebaseConfig);
