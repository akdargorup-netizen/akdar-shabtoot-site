// js/data/admin-auth.js — شبتوت بحري
// ══════════════════════════════════════════════════════════════
//  بوابة قفل لوحة الإدارة — طبقة مؤقتة/تمهيدية بصلاحيتين:
//
//  - "مطوّر" (developer): وصول كامل — كل الأقسام + أقسام النظام
//    الحساسة (صلاحيات المشرفين، سجل النشاط، إلخ).
//  - "مشرف" (admin): وصول لأقسام المحتوى فقط (أخبار، مناسبات،
//    مشاريع...) — بدون أقسام النظام أو إدارة صلاحيات مشرفين آخرين.
//
//  مفتاحين للدخول:
//  1) مفتاح الاسترجاع (كود، ثابت أدناه) — هاش SHA-256 مكتوب في
//     الكود نفسه. آخر خط دفاع لو ضاعت كل الحسابات، ما بيظهرش في
//     أي قائمة ولا ينحذف من الواجهة أبداً.
//  2) سجل حسابات مشرفين حقيقي (ADMIN_ACCOUNTS_KEY في localStorage)
//     — كل حساب: اسم + كلمة سر خاصة به (هاش) + دور. يُدار من صفحة
//     "صلاحيات المشرفين" (admin-permissions.js) داخل قسم "النظام":
//     إضافة شخص بكلمة سر خاصة به، حذف شخص، أو تصفير كلمة سره —
//     بدون مشاركة كلمة سر المطوّر الأساسية مع حد.
//
//  ليست بديلاً عن isAdmin() في auth.js (تلك مبنية على custom claims
//  حقيقية من Firebase Admin SDK عبر scripts/admin/set-claims.js —
//  ومنح تلك الصلاحية الحقيقية يبقى دائماً خارج نطاق الواجهة، بقصد،
//  زي ما موثّق في scripts/admin/README.md). هذه الطبقة فقط قفل محلي
//  (localStorage/sessionStorage على نفس الجهاز) يمنع الوصول العرضي
//  قبل اكتمال نموذج البيانات وربط الصلاحيات الحقيقية.
//
//  تفعيل مفتاح الاسترجاع:
//  1) افتح console المتصفح ونفّذ:
//       await crypto.subtle.digest('SHA-256', new TextEncoder().encode('كلمة_السر_هنا'))
//         .then(buf => [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2,'0')).join(''))
//     انسخ الناتج (هاش) وضعه في RECOVERY_PASSWORD_HASH أدناه.
//  2) لو تُرك فارغاً، يبقى مفتاح الاسترجاع مقفولاً (يفضل سجل
//     الحسابات هو الطريقة الوحيدة للدخول).
//
//  لاحقاً: عند اكتمال نموذج البيانات وتفعيل Firebase الحقيقي، يُفترض
//  استبدال هذه الطبقة بالكامل بشرط isAdmin() / role من custom claims
//  عبر auth.js، وحذف هذا الملف.
//
//  ── مفتاح التشغيل ADMIN_AUTH_MODE (الجزء 7) ──
//  'local'  (الافتراضي): السلوك القديم بالظبط — كلمات سر + localStorage.
//  'claims': الصلاحيات الحقيقية — الدخول بحساب Google فقط، والدور من
//            custom claims في التوكن: owner→developer، admin→admin،
//            nubian→nubian (فلا يتغير router.js ولا admin-panel.js).
//            كلمات السر ومفتاح الاسترجاع وسجل الحسابات المحلي كلها
//            بتتعطّل تمامًا في هذا الوضع (مفيش باب خلفي).
//  ⚠️ ما تفعّلش 'claims' قبل ما تنجح في set-claims.js لحسابك وتشوف
//  owner فعلًا في التوكن — وإلا هتنقفل برّه اللوحة. الرجوع = تغيير
//  الثابت تحت لـ 'local'.
// ══════════════════════════════════════════════════════════════

import { getCurrentUser, waitForAuthReady } from './auth.js';
import { IS_DEVELOPMENT } from './runtime-config.js';

/** @type {'local'|'claims'} */
export const ADMIN_AUTH_MODE = 'claims';

// مفتاح التطوير يعمل محليًا فقط. لا نسمح بباب استرجاع ثابت على نسخة منشورة.
// يظل الهاش موجودًا مؤقتًا لتسهيل البناء المحلي، لكنه غير فعّال خارج localhost.
const RECOVERY_PASSWORD_HASH = IS_DEVELOPMENT &&
  ['localhost', '127.0.0.1', '[::1]'].includes(location.hostname)
  ? '84998ac03625b20558ccbf98fd27f7a36767be620676806b1635262ceafb8924'
  : '';

const SESSION_KEY       = 'admin_gate_unlocked';
const SESSION_ROLE_KEY  = 'admin_gate_role';    // 'developer' | 'admin' | 'nubian'
const SESSION_ACCOUNT_KEY = 'admin_gate_account_id'; // معرّف الحساب المسجَّل دخوله الآن، أو 'recovery'

const ACCOUNTS_KEY = 'admin_accounts'; // localStorage — سجل حسابات المشرفين الحقيقي

async function _sha256Hex(text) {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
  return [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, '0')).join('');
}

function _genId() {
  return crypto?.randomUUID?.() || `acc-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}


// ══════════════════════════════════════════════════════════════
//  وضع 'claims' — الدور من توكن Firebase الحقيقي (مش من localStorage)
// ══════════════════════════════════════════════════════════════

const _isClaimsMode = () => ADMIN_AUTH_MODE === 'claims';

// "خروج" من اللوحة في وضع claims = قفل ناعم في الذاكرة لنفس الحساب (من
// غير تسجيل خروج جوجل كامل، عشان ما يضيعش الاسم الظاهر). يتصفّر لو
// الحساب اتغيّر، أو لو الشخص دخل اللوحة تاني من البوابة.
let _softLockedUid = null;

function _claimsRole() {
  const u = getCurrentUser();
  if (!u || u.isAnonymous) return null; // الجلسة المجهولة ما تفتحش إدارة أبداً
  const c = u.claims || {};
  // المطوّر (owner) أولًا. ثم مشرف الرُطانة (nubian): دوره محصور بقسم آنداندي فقط (admin-access.js يمنعه من
  // أي صفحة إدارية أخرى، وسياسات RLS في Supabase تقصر كتابته على جداول القاموس وbucket الصوت).
  // دور admin العام يبقى غير معترف به هنا كما كان.
  if (c.owner === true) return 'developer';
  if (c.nubian === true) return 'nubian';
  return null;
}

function _activeClaimsRole() {
  const u = getCurrentUser();
  if (u && _softLockedUid && u.uid === _softLockedUid) return null;
  return _claimsRole();
}

/**
 * ينتظر أول حالة مصادقة قبل قرار الحارس (وضع claims بس؛ في 'local' يرجع
 * فورًا). بمهلة عشان ما يعلّقش الراوتر للأبد لو Supabase مش متاح.
 */
export async function whenAdminAuthReady(timeoutMs = 8000) {
  if (!_isClaimsMode()) return;
  await Promise.race([
    waitForAuthReady(),
    new Promise(resolve => setTimeout(resolve, timeoutMs)),
  ]);
}

/**
 * وضع claims: يفتح جلسة اللوحة للحساب الحالي لو عنده دور فعلي في التوكن.
 * @returns {Promise<'developer'|'admin'|'nubian'|false>}
 */
export async function enterAdminWithClaims() {
  if (!_isClaimsMode()) return false;
  _softLockedUid = null;
  return _claimsRole() || false;
}

/** اسم الفاعل لسجل النشاط في وضع claims (اسم حساب جوجل)، وإلا null. */
export function getAdminActorName() {
  if (!_isClaimsMode()) return null;
  return getCurrentUser()?.displayName || 'حساب بدون اسم';
}


// ══════════════════════════════════════════════════════════════
//  سجل الحسابات (تخزين محلي — localStorage)
// ══════════════════════════════════════════════════════════════

function _readAccounts() {
  try {
    const raw = localStorage.getItem(ACCOUNTS_KEY);
    const list = raw ? JSON.parse(raw) : [];
    return Array.isArray(list) ? list : [];
  } catch {
    return [];
  }
}

function _writeAccounts(list) {
  localStorage.setItem(ACCOUNTS_KEY, JSON.stringify(list));
}

/**
 * قائمة حسابات المشرفين الحالية (بدون هاش كلمة السر — للعرض في الواجهة فقط).
 * @returns {Array<{id:string, name:string, role:'developer'|'admin'|'nubian', createdAt:string}>}
 */
export function getAdminAccounts() {
  return _readAccounts()
    .map(({ id, name, role, createdAt }) => ({ id, name, role, createdAt }))
    .sort((a, b) => a.createdAt.localeCompare(b.createdAt));
}

/**
 * إضافة حساب مشرف جديد بكلمة سر خاصة به.
 * الدور 'nubian' = "مشرف الرُطانة" — وصول محصور بقسم القاموس النوبي
 * بس (راجع roles في router.js وفلترة admin-panel.js)، لأشخاص متخصصين
 * باللغة (باحثين نوبيين مثلاً) بدون إعطائهم صلاحية باقي المحتوى.
 *
 * ⚠️ هذا الدور حاليًا قفل واجهة محلي بس (زي admin/developer تمامًا) —
 * لسع مش متوصّل بحساب حقيقي. المكافئ الحقيقي على مستوى قاعدة البيانات
 * جاهز أصلاً: العمود is_nubian في جدول user_roles على Supabase.
 * @param {{name:string, password:string, role:'developer'|'admin'|'nubian'}} input
 * @returns {Promise<{id:string, name:string, role:string, createdAt:string}>}
 */
export async function addAdminAccount({ name, password, role }) {
  if (_isClaimsMode()) throw new Error('الحسابات المحلية معطّلة — الصلاحيات من جدول user_roles في Supabase');
  const trimmedName = (name || '').trim();
  if (!trimmedName) throw new Error('الاسم مطلوب');
  if (!password || password.length < 4) throw new Error('كلمة السر لازم ٤ حروف/أرقام على الأقل');
  if (!['developer', 'admin', 'nubian'].includes(role)) throw new Error('الدور ما معروف');

  const accounts = _readAccounts();
  const passwordHash = await _sha256Hex(password);

  const account = {
    id: _genId(),
    name: trimmedName,
    role,
    passwordHash,
    createdAt: new Date().toISOString(),
  };

  accounts.push(account);
  _writeAccounts(accounts);

  const { id, name: n, role: r, createdAt } = account;
  return { id, name: n, role: r, createdAt };
}

/**
 * حذف حساب مشرف. لو كانت الجلسة الحالية مسجّلة دخول بنفس هذا الحساب،
 * تُقفل الجلسة تلقائياً بعد الحذف.
 * @param {string} id
 */
export function removeAdminAccount(id) {
  if (_isClaimsMode()) return;
  const accounts = _readAccounts().filter(a => a.id !== id);
  _writeAccounts(accounts);

  if (sessionStorage.getItem(SESSION_ACCOUNT_KEY) === id) {
    lockAdminSession();
  }
}

/**
 * تصفير كلمة سر حساب موجود (بدل حذفه وإعادة إنشائه).
 * @param {string} id
 * @param {string} newPassword
 */
export async function resetAdminAccountPassword(id, newPassword) {
  if (_isClaimsMode()) throw new Error('الحسابات المحلية متعطلة — الصلاحيات بتجي من جدول user_roles في Supabase');
  if (!newPassword || newPassword.length < 4) throw new Error('كلمة السر لازم ٤ حروف/أرقام على الأقل');

  const accounts = _readAccounts();
  const account = accounts.find(a => a.id === id);
  if (!account) throw new Error('الحساب ما موجود');

  account.passwordHash = await _sha256Hex(newPassword);
  _writeAccounts(accounts);
}


// ══════════════════════════════════════════════════════════════
//  الجلسة — دخول / خروج
// ══════════════════════════════════════════════════════════════

/**
 * محاولة فتح البوابة بكلمة سر — تتحقق أولاً من مفتاح الاسترجاع،
 * ثم من سجل الحسابات الحقيقي، وتحدد الدور المطابق.
 * @param {string} password
 * @returns {Promise<'developer'|'admin'|false>} الدور عند النجاح، أو false
 */
export async function unlockAdminSession(password) {
  if (_isClaimsMode()) return false; // كلمات السر ومفتاح الاسترجاع معطّلين في وضع claims
  if (!password) return false;

  const hash = await _sha256Hex(password);

  if (RECOVERY_PASSWORD_HASH && hash === RECOVERY_PASSWORD_HASH) {
    sessionStorage.setItem(SESSION_KEY, '1');
    sessionStorage.setItem(SESSION_ROLE_KEY, 'developer');
    sessionStorage.setItem(SESSION_ACCOUNT_KEY, 'recovery');
    return 'developer';
  }

  const account = _readAccounts().find(a => a.passwordHash === hash);
  if (account) {
    sessionStorage.setItem(SESSION_KEY, '1');
    sessionStorage.setItem(SESSION_ROLE_KEY, account.role);
    sessionStorage.setItem(SESSION_ACCOUNT_KEY, account.id);
    return account.role;
  }

  return false;
}

/** هل الجلسة الحالية مفتوحة (بأي دور)؟ تُقفل تلقائياً عند إغلاق التبويب/المتصفح. */
export function isAdminSessionUnlocked() {
  if (_isClaimsMode()) return _activeClaimsRole() !== null;
  return sessionStorage.getItem(SESSION_KEY) === '1';
}

/** دور الجلسة الحالية، أو null لو مقفولة. */
export function getAdminRole() {
  if (_isClaimsMode()) return _activeClaimsRole();
  if (!isAdminSessionUnlocked()) return null;
  return sessionStorage.getItem(SESSION_ROLE_KEY) || null;
}

/**
 * صفة صاحب الحساب لوسم الاسم بجانب المحتوى ('developer'|'admin'|'nubian'|'').
 * وضع claims: من توكن الحساب مباشرة (مستقلة عن «قفل اللوحة الناعم» — الصفة
 * صفة الشخص مو حالة جلسة). الوضع المحلي: دور جلسة اللوحة المفتوحة حاليًا.
 */
export function getStaffRole() {
  if (_isClaimsMode()) return _claimsRole() || '';
  return getAdminRole() || '';
}

/** معرّف حساب الجلسة الحالية، أو 'recovery' لو دخلت بمفتاح الاسترجاع، أو null لو مقفولة. */
export function getAdminAccountId() {
  if (_isClaimsMode()) return _activeClaimsRole() ? (getCurrentUser()?.uid || null) : null;
  if (!isAdminSessionUnlocked()) return null;
  return sessionStorage.getItem(SESSION_ACCOUNT_KEY) || null;
}

/** اختصار: هل الجلسة الحالية بدور "مطوّر" (أعلى صلاحية)؟ */
export function isDeveloperSession() {
  return getAdminRole() === 'developer';
}

/** قفل الجلسة يدوياً (زر خروج من لوحة الإدارة). */
export function lockAdminSession() {
  if (_isClaimsMode()) {
    _softLockedUid = getCurrentUser()?.uid || null;
    return;
  }
  sessionStorage.removeItem(SESSION_KEY);
  sessionStorage.removeItem(SESSION_ROLE_KEY);
  sessionStorage.removeItem(SESSION_ACCOUNT_KEY);
}

/** هل البوابة مُفعّلة أصلاً (مفتاح استرجاع أو حساب واحد على الأقل)؟ يفيد لعرض رسالة واضحة بدل فشل صامت. */
export function isGateConfigured() {
  if (_isClaimsMode()) return true;
  return Boolean(RECOVERY_PASSWORD_HASH) || _readAccounts().length > 0;
}
