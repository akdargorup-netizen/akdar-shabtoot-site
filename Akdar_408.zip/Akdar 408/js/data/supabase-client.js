// js/data/supabase-client.js — شبتوت بحري
// ══════════════════════════════════════════════════════════════
//  عميل Supabase الوحيد للتطبيق (المصادقة + قاعدة البيانات + الدوال).
//  يُحمَّل عند أول طلب فقط (import ديناميكي) كي لا يعطّل الرسم الأول،
//  ونسخته مثبّتة بالرقم (مش latest) وتتخزّن في كاش الـService Worker.
//
//  ⚠️ المفتاح هنا publishable (عام بطبيعته) — الحماية الحقيقية في سياسات RLS
//  داخل schema.sql. لا تضع هنا أبدًا مفتاح service_role / secret.
//
//  الدخول بجوجل يتم بـsignInWithIdToken (راجع auth.js) فلا نقرأ الرابط.
// ══════════════════════════════════════════════════════════════

export const SUPABASE_URL = 'https://rtgrkugcokqxseedzunr.supabase.co';
export const SUPABASE_KEY = 'sb_publishable_GweumDJkfZ42oVSQar-uHg_ZUZ7az2K';

export const SUPABASE_SDK_URL = 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.49.4/+esm';

// نسخة محلية من نفس المكتبة (تُبنى بـ: bash build/vendor-supabase.sh). لو موجودة تُستخدم بدل الـCDN:
// أسرع بكثير بإنترنت القرية الضعيف (لا اتصال إضافي بجهة ثالثة) وتتخزّن مع التطبيق للعمل أوفلاين.
export const SUPABASE_LOCAL_SDK = '/vendor/supabase-js.js';

const _NO_LOCAL_KEY = 'sbb:no-local-sdk-until';

async function _loadSdk() {
  let skipLocal = false;
  try { skipLocal = Date.now() < Number(localStorage.getItem(_NO_LOCAL_KEY) || 0); } catch { /* تجاهل */ }
  if (!skipLocal) {
    try {
      return await import(/* @vite-ignore */ SUPABASE_LOCAL_SDK);
    } catch {
      // الملف المحلي غير موجود: لا نكرر المحاولة (طلب ضايع بالشبكة الضعيفة) لمدة يوم
      try { localStorage.setItem(_NO_LOCAL_KEY, String(Date.now() + 24 * 3600 * 1000)); } catch { /* تجاهل */ }
    }
  }
  return import(SUPABASE_SDK_URL); // الـCDN
}

/** @type {Promise<import('@supabase/supabase-js').SupabaseClient>|null} */
let _clientPromise = null;

/** @returns {Promise<import('@supabase/supabase-js').SupabaseClient>} */
export function getSupabase() {
  if (!_clientPromise) {
    _clientPromise = _loadSdk().then(({ createClient }) =>
      createClient(SUPABASE_URL, SUPABASE_KEY, {
        auth: {
          persistSession: true,
          autoRefreshToken: true,
          detectSessionInUrl: false,
          storageKey: 'sb-akdar-auth',
        },
      })
    ).catch((err) => {
      _clientPromise = null; // اسمح بإعادة المحاولة (شبكة ضعيفة)
      throw err;
    });
  }
  return _clientPromise;
}
