// js/data/read-cache.js — شبتوت بحري
// ══════════════════════════════════════════════════════════════
//  كاش قراءة صغير (IndexedDB + ذاكرة) لمحوّل Supabase.
//  الفكرة: نعرض آخر نسخة محفوظة فورًا (حتى بلا إنترنت أو بإنترنت ضعيف جدًا)
//  ونحدّث من السيرفر بالخلفية — نمط stale-while-revalidate.
//
//  • القيمة المخزَّنة = صفوف خام من قاعدة البيانات (التواريخ النسبية "منذ ساعة"
//    تُحسب وقت العرض، فلا تتجمّد).
//  • لو IndexedDB غير متاح (وضع خاص/تخزين ممتلئ) نكمل بالذاكرة فقط.
//  • مفتاح الإصدار v1: غيّره لو تغيّر شكل الصفوف المخزَّنة لتبدأ الأجهزة نظيفة.
// ══════════════════════════════════════════════════════════════

const DB_NAME = 'akdar-sb-cache-v1';
const STORE = 'kv';

/** @type {Map<string, {value: any, savedAt: number}>} */
const _mem = new Map();
let _dbPromise = null;

function _openDb() {
  if (_dbPromise) return _dbPromise;
  _dbPromise = new Promise((resolve) => {
    try {
      if (typeof indexedDB === 'undefined') return resolve(null);
      const req = indexedDB.open(DB_NAME, 1);
      req.onupgradeneeded = () => req.result.createObjectStore(STORE);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => resolve(null);
      req.onblocked = () => resolve(null);
    } catch {
      resolve(null);
    }
  });
  return _dbPromise;
}

function _tx(db, mode, fn) {
  return new Promise((resolve) => {
    try {
      const tx = db.transaction(STORE, mode);
      const store = tx.objectStore(STORE);
      const out = fn(store);
      tx.oncomplete = () => resolve(out?.result);
      tx.onerror = () => resolve(undefined);
      tx.onabort = () => resolve(undefined);
    } catch {
      resolve(undefined);
    }
  });
}

/** @returns {Promise<{value:any, savedAt:number}|null>} */
export async function cacheGet(key) {
  const m = _mem.get(key);
  if (m) return m;
  const db = await _openDb();
  if (!db) return null;
  const entry = await _tx(db, 'readonly', (s) => s.get(key));
  if (entry && typeof entry.savedAt === 'number') {
    _mem.set(key, entry);
    return entry;
  }
  return null;
}

/** يحفظ قيمة (ويحدّث وقت الحفظ). savedAt يمكن تمريره لتعليم المحفوظ "قديم" (0). */
export async function cachePut(key, value, savedAt = Date.now()) {
  const entry = { value, savedAt };
  _mem.set(key, entry);
  const db = await _openDb();
  if (db) await _tx(db, 'readwrite', (s) => s.put(entry, key));
}

/** يعلّم كل مفاتيح البادئة "قديمة" بدل حذفها: تُعرض فورًا ثم تتحدّث بالخلفية. */
export async function cacheMarkStale(prefix) {
  const keys = new Set([..._mem.keys()].filter(k => k.startsWith(prefix)));
  const db = await _openDb();
  if (db) {
    const all = await _tx(db, 'readonly', (s) => s.getAllKeys());
    (all || []).forEach(k => { if (String(k).startsWith(prefix)) keys.add(String(k)); });
  }
  for (const k of keys) {
    const e = await cacheGet(k);
    if (e) await cachePut(k, e.value, 0);
  }
}

/** يحذف كل مفاتيح البادئة (عند تسجيل الخروج مثلاً). */
export async function cacheDelPrefix(prefix) {
  for (const k of [..._mem.keys()]) if (k.startsWith(prefix)) _mem.delete(k);
  const db = await _openDb();
  if (!db) return;
  const all = await _tx(db, 'readonly', (s) => s.getAllKeys());
  for (const k of (all || [])) {
    if (String(k).startsWith(prefix)) await _tx(db, 'readwrite', (s) => s.delete(k));
  }
}

/** كل المفاتيح (الذاكرة + IndexedDB) التي تبدأ بالبادئة. */
export async function cacheKeys(prefix) {
  const keys = new Set([..._mem.keys()].filter(k => k.startsWith(prefix)));
  const db = await _openDb();
  if (db) {
    const all = await _tx(db, 'readonly', (s) => s.getAllKeys());
    (all || []).forEach(k => { if (String(k).startsWith(prefix)) keys.add(String(k)); });
  }
  return [...keys];
}
