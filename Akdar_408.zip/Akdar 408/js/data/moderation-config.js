// js/data/moderation-config.js — شبتوت بحري
// ═══════════════════════════════════════════════════════════════════
//  إعدادات تعديل/حذف/إبلاغ المحتوى (مناسبات + أفكار + تعليقاتهما).
//  مصدر واحد للأرقام والأسباب — الواجهة والمحوّلان يقرؤون منه.
//
//  ⚠️ نفس الأرقام مكتوبة في سياسات RLS في Supabase (EDIT_WINDOW = 15 دقيقة،
//  عتبة الإخفاء = 3) — غيّر الاتنين مع بعض. القواعد هي الحقيقة؛ هذا
//  الملف للواجهة (إخفاء خيار "تعديل" بعد انتهاء المهلة، إلخ).
// ═══════════════════════════════════════════════════════════════════

/** مهلة التعديل بعد النشر. */
export const EDIT_WINDOW_MS = 15 * 60 * 1000;

/** عدد البلاغات (من مستخدمين مختلفين) اللي يخفي المحتوى لحد مراجعة المشرف. */
export const REPORT_HIDE_THRESHOLD = 3;

/** أسباب البلاغ (المفتاح هو المخزَّن). */
export const REPORT_REASONS = [
  { key: 'abusive',   label: 'مسيء أو جارح' },
  { key: 'spam',      label: 'مزعج أو دعاية' },
  { key: 'false',     label: 'معلومة خاطئة' },
  { key: 'other',     label: 'سبب آخر' },
];

export const REPORT_REASON_KEYS = REPORT_REASONS.map(r => r.key);

/** هل لسع في مهلة التعديل؟ createdAt = ISO string أو Date أو رقم. */
export function isWithinEditWindow(createdAt, now = Date.now()) {
  const t = new Date(createdAt).getTime();
  return Number.isFinite(t) && now - t < EDIT_WINDOW_MS;
}

/** الدقائق المتبقية من مهلة التعديل (للتلميح)، أو 0. */
export function editMinutesLeft(createdAt, now = Date.now()) {
  const t = new Date(createdAt).getTime();
  if (!Number.isFinite(t)) return 0;
  return Math.max(0, Math.ceil((EDIT_WINDOW_MS - (now - t)) / 60000));
}
