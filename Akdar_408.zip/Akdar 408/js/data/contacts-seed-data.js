// js/data/contacts-seed-data.js — شبتوت بحري
// ══════════════════════════════════════════════════════════════
//  بذرة بيانات دليل الاتصال — نفس دور history-data.js لمقالات
//  التاريخ: تعريف الأقسام الثابتة (CONTACT_CATEGORY_DEFS) + جهات
//  الاتصال الأولية مقسّمة حسب القسم (CONTACT_SEED_DATA).
//
//  ⚠️ هذا الملف بذرة فقط — local-adapter.js يقرأه مرة واحدة عند
//  بدء التشغيل ويحوّله لحالة قابلة للتعديل في الذاكرة (زي بقية
//  الأقسام). أي إضافة/تعديل/حذف لاحق من لوحة الإدارة يمر عبر
//  db.js/local-adapter.js، مش هذا الملف.
//
//  ⚠️ 2026-09-01: كل أرقام الهواتف اتصفّرت (phone: null) بقرار صريح —
//  الأرقام المؤقتة (placeholder) القديمة اتشالت خالص عشان محدش يتصل
//  برقم وهمي بالغلط. الواجهة (contact-directory.js / contact-category.js)
//  بتتعامل مع phone: null بعرض الجهة عادي بس بتعطيل زرار الاتصال/واتساب
//  وتوريه رسالة "لم يتم إضافة الرقم بعد" بدل ما تحاول تتصل. حدّث كل
//  جهة برقمها الحقيقي من لوحة الإدارة (دليل الاتصال ← تعديل الجهة)
//  أول ما يتوفر عندك.
//
//  القسم الجديد بيحتاج تعديل كود (زيادة سطر هنا + إضافته لإحدى
//  مجموعات العرض الأربع في contact-directory-data.js) — نفس وضع
//  HISTORY_SECTIONS بالظبط: قائمة أقسام ثابتة، لوحة الإدارة تدير
//  المحتوى داخلها لا الأقسام نفسها.
// ══════════════════════════════════════════════════════════════

/** تعريف كل قسم — يُستخدم في صفحة الدليل العامة وفي نموذج لوحة الإدارة */
export const CONTACT_CATEGORY_DEFS = [
  { key: 'emergency',          emoji: '🚑',  label: 'الطوارئ والصحة',                 icon: 'siren',              pinned: true  },
  { key: 'committees',         emoji: '🏛️', label: 'اللجان والخدمات المجتمعية',       icon: 'users',               pinned: false },
  { key: 'mosque-committees',  emoji: '🕌',  label: 'لجان المساجد',                   icon: 'landmark',            pinned: false },
  { key: 'event-associations', emoji: '🤝',  label: 'جمعيات المناسبات',               icon: 'heart-handshake',     pinned: false },
  { key: 'education',          emoji: '🎓',  label: 'التعليم والثقافة',               icon: 'graduation-cap',      pinned: false },
  { key: 'sports-media',       emoji: '⚽',  label: 'الرياضة والإعلام',               icon: 'tv',                  pinned: false },
  { key: 'shops',              emoji: '🛒',  label: 'المتاجر والخدمات التجارية',       icon: 'shopping-cart',       pinned: false },
  { key: 'building',           emoji: '🏗️', label: 'البناء ومواد البناء',            icon: 'hammer',              pinned: false },
  { key: 'electrical-energy',  emoji: '⚡',  label: 'الكهرباء والطاقة الشمسية',       icon: 'zap',                 pinned: false },
  { key: 'transport',          emoji: '🚗',  label: 'نقل المواد وصيانة السيارات',      icon: 'car',                 pinned: false },
  { key: 'crafts',             emoji: '🔧',  label: 'الحرف والخدمات الفنية',          icon: 'wrench',              pinned: false },
  { key: 'food',               emoji: '🥛',  label: 'الأغذية والمنتجات المحلية',       icon: 'milk',                pinned: false },
  { key: 'travel',             emoji: '🚌',  label: 'مواصلات ووكالات السفر بين المدن', icon: 'bus',                 pinned: false },
];

/** جهات الاتصال الأولية — مقسّمة حسب مفتاح القسم (categoryKey يُضاف تلقائياً في المحوّل) */
export const CONTACT_SEED_DATA = {
  emergency: [
    { id: 1, name: 'إسعاف شبتوت بحري', role: null, phone: null },
    { id: 2, name: 'إسعاف الخندق',     role: null, phone: null },
  ],
  committees: [
    { id: 4, name: 'لجنة الصهريج',                      role: null, phone: null },
    { id: 5, name: 'لجنة القرية',                        role: null, phone: null },
    { id: 6, name: 'شباب الرابطة لطلب المساعدة',         role: null, phone: null },
    { id: 7, name: 'منظمة الإسراء الخيرية',              role: null, phone: null },
  ],
  'mosque-committees': [
    { id: 8,  name: 'لجنة المسجد الكبير',    role: null, phone: null },
    { id: 9,  name: 'لجنة مسجد التقوى',      role: null, phone: null },
    { id: 10, name: 'لجنة مسجد الفحلاب',     role: null, phone: null },
    { id: 11, name: 'لجنة مسجد أم الرشيد',   role: null, phone: null },
    { id: 12, name: 'لجنة مسجد بدر الكبرى',  role: null, phone: null },
    { id: 13, name: 'لجنة مسجد صالح نوري',   role: null, phone: null },
    { id: 17, name: 'لجنة الفحلاب',          role: null, phone: null },
  ],
  'event-associations': [
    { id: 14, name: 'جمعية الفحلاب للمناسبات',       role: null, phone: null },
    { id: 15, name: 'جمعية التنجلاب للمناسبات',      role: null, phone: null },
    { id: 16, name: 'جمعية التنجلاب للمناسبات (2)',  role: null, phone: null },
  ],
  education: [
    { id: 18, name: 'إدارة المدرسة الأساسية',                     role: null,                           phone: null },
    { id: 19, name: 'إدارة المدرسة المتوسطة',                     role: null,                           phone: null },
    { id: 20, name: 'إدارة المدرسة الصناعية',                     role: null,                           phone: null },
    { id: 21, name: 'روضة الوالدين',                               role: null,                           phone: null },
    { id: 22, name: 'كورسات دراسية',                               role: 'الأمانة الأكاديمية بالرابطة', phone: null },
    { id: 23, name: 'التواصل مع أساتذة للاستشارة التعليمية',       role: null,                           phone: null },
    { id: 24, name: 'دكتور محمود محمد حسن',                        role: 'كاتب وعالم ديني وتاريخي',      phone: null },
    { id: 25, name: 'بروفيسور سر الختم عثمان الأمين',              role: 'كاتب وعالم ديني وتاريخي',      phone: null },
  ],
  'sports-media': [
    { id: 26, name: 'إدارة نادي شبتوت بحري',    role: null,                    phone: null },
    { id: 27, name: 'تغطيات فعاليات القرية',    role: 'إعلام الرابطة',        phone: null },
    { id: 28, name: 'هنادي عبدالله الأمين',     role: 'إعلامية ومقدمة برامج', phone: null },
  ],
  shops: [
    { id: 29, name: 'عبدالله تكي للمواد الغذائية',            role: null, phone: null },
    { id: 30, name: 'بكري كمبو للمواد الغذائية',              role: null, phone: null },
    { id: 31, name: 'أبناء عبدالعزيز حاج للأواني المنزلية',   role: null, phone: null },
    { id: 32, name: 'كمبي لطوب البلك ومواد البناء',           role: null, phone: null },
  ],
  building: [
    { id: 33, name: 'خالد كمبو لمواد السباكة والبناء والكهرباء', role: null,        phone: null },
    { id: 37, name: 'عبدالسميع عوض خليل',                        role: 'أسطى بناء', phone: null },
    { id: 38, name: 'عبدالعظيم عوض خليل',                        role: 'أسطى بناء', phone: null },
    { id: 39, name: 'رشدي طنون',                                 role: 'أسطى بناء', phone: null },
  ],
  'electrical-energy': [
    { id: 34, name: 'عبدالعظيم الخندقاوي لخدمات الطاقة الشمسية', role: null,                             phone: null },
    { id: 35, name: 'وائل الخندقاوي لخدمات الطاقة الشمسية',      role: null,                             phone: null },
    { id: 36, name: 'أحمد عبدالله الأمين',                        role: 'فني طاقة شمسية',                phone: null },
    { id: 40, name: 'خضر حسن',                                    role: 'فني الأجهزة الكهربائية والبناء', phone: null },
    { id: 41, name: 'عوض أحمد جبرة',                              role: 'فني أدوات كهربائية',             phone: null },
    { id: 42, name: 'عمر دمباوي',                                 role: 'الأعطال الكهربائية والحدادة',    phone: null },
    { id: 43, name: 'الصادق فلاح',                                role: 'الحدادة والصيانة الكهربائية',    phone: null },
    { id: 44, name: 'محي الدين قردوق',                            role: 'صيانة الأدوات الكهربائية',       phone: null },
    { id: 45, name: 'عوض الأمين',                                 role: 'ملء أنابيب الغاز',               phone: null },
  ],
  transport: [
    { id: 46, name: 'التوم قردوق للنقل والمواصلات', role: null,                          phone: null },
    { id: 47, name: 'صديق عبد الحليم',              role: 'نقل الطوب والتراب والخرسانة', phone: null },
    { id: 48, name: 'عماد حسن أسطى',                role: 'نقل المواد المختلفة',        phone: null },
    { id: 49, name: 'صالح هارون',                   role: 'ورشة متحركة',                phone: null },
    { id: 50, name: 'سيد أحمد هارون',               role: 'ورشة متحركة',                phone: null },
    { id: 51, name: 'عوض قردوق',                    role: 'صيانة السيارات',             phone: null },
    { id: 52, name: 'بنشر عاصم',                    role: 'صيانة الإطارات والعجلات',    phone: null },
  ],
  crafts: [
    { id: 53, name: 'عثمان الشين',                role: 'نجارة الخشب',                          phone: null },
    { id: 54, name: 'علي ضوي',                    role: 'الإسبيرات وأكثر',                      phone: null },
    { id: 55, name: 'عبدالوهاب نانس',             role: 'صيانة الطبق الهوائي وبرمجة التلفاز',    phone: null },
    { id: 56, name: 'عبدو سعيد',                  role: 'نسج السراير',                          phone: null },
    { id: 57, name: 'صابر عوض',                   role: 'خياط',                                  phone: null },
    { id: 58, name: 'عبد الحي عثمان الأمين',      role: 'كتابة الإعلانات واللافتات',            phone: null },
    { id: 59, name: 'فاطمة عوض خليل',             role: 'الرسم والبوهية',                       phone: null },
    { id: 60, name: 'إستديو أخضر',                role: 'تصميم دعوات الزفاف والإعلانات والفيديوهات', phone: null },
    { id: 61, name: 'ورشة حدادة زكريا أحمد نوري', role: null,                                    phone: null },
  ],
  food: [
    { id: 62, name: 'الصادق الشفيع للألبان', role: null, phone: null },
  ],
  travel: [
    { id: 63, name: 'باصات السفر القريبة منك',       role: null,               phone: null },
    { id: 64, name: 'صلاح بشير',                      role: 'مواصلات دنقلا',   phone: null },
    { id: 65, name: 'أحمد نصر',                       role: 'مواصلات دنقلا',   phone: null },
    { id: 66, name: 'النور عثمان',                    role: 'مواصلات القولد',  phone: null },
    { id: 67, name: 'فتاح تكي',                       role: 'مواصلات القولد',  phone: null },
    { id: 68, name: 'وكالة الأخوان للسفر والسياحة',   role: null,               phone: null },
  ],
};
