// js/data/cache-stamps.js — شبتوت بحري
// ══════════════════════════════════════════════════════════════
//  أختام النسخة: بدل أن يسأل كل جهاز السيرفر كل بضع دقائق "هل تغيّر المحتوى؟"،
//  يقرأ صفًا صغيرًا واحدًا (settings / cache_stamps) فيه آخر وقت تغيّر لكل قسم.
//  تغيّر الختم ← القسم يُعلَّم "قديمًا" ويتجدد بالخلفية. لم يتغيّر ← لا يُجلب شيء.
//  الصف يحرّكه محفّز قاعدة البيانات (20261101_cache_stamps.sql) عند كل تغيير عام.
//
//  • لا يشمل: قوائم الإدارة والمشرف (تحتاج الجديد المعلّق فورًا)، التعليقات، الإعجابات،
//    الإشعارات، العاجل — هذه تبقى بمددها الزمنية.
//  • سقف أمان: حتى مع الختم، أي نسخة عمرها فوق ٦ ساعات تُجدَّد (لو تعطلت الإشارة).
//  • قبل تشغيل SQL (لا صف ختم) أو لو لم يُقرأ الختم قط: السلوك القديم كما هو (مدد زمنية).
// ══════════════════════════════════════════════════════════════

import { getSupabase } from './supabase-client.js';
import { cacheGet, cachePut, cacheMarkStale } from './read-cache.js';
import { assertReadAllowed, noteOutcome } from './adapters/rate-guard.js';

export const STAMP_ROW_KEY = 'cache_stamps';
export const STAMP_CAP_MS = 6 * 3600 * 1000;
const STORE_KEY = 'stamps:last';
const FIRST_DELAY_MS = 1200;
const MIN_GAP_MS = 120000;       // لا أكثر من قراءة ختم كل دقيقتين مهما تكرر الدخول والخروج
const INTERVAL_MS = 600000;      // والتطبيق مفتوح: كل ١٠ دقائق
const TIMEOUT_MS = 8000;

const LIBRARY = [
  'memory_videos', 'study_videos', 'study_tips', 'worship_lectures', 'history_articles',
  'association_journey_articles', 'projects', 'gallery', 'contacts',
  'nubian_words', 'nubian_phrase_categories', 'nubian_phrases',
];
const PUBLIC = ['news', 'events', 'ideas', 'occasions'];
export const STAMPED = new Set([...PUBLIC, ...LIBRARY]);
const RECENT = new Set(PUBLIC);

/** مفتاح كاش ← اسم قسمه في الأختام (أو null لو لا يخضع للختم) */
export function stampKeyFor(cacheKey) {
  const parts = String(cacheKey).split(':');
  const head = parts[0];
  if (head === 'recent') return RECENT.has(parts[1]) ? parts[1] : null;
  if (!STAMPED.has(head)) return null;
  const kind = parts[1] || '';
  if (!(kind.startsWith('rows') || kind === 'one' || kind === 'latest')) return null; // item = نص مقال: له فحصه الخاص
  if (kind === 'rowsAll' || parts.includes('all') || parts[parts.length - 1] === 'admin') return null; // قوائم المشرف
  return head;
}

const _prefixesOf = (k) => [`${k}:rows`, `${k}:one:`, `${k}:latest`, `recent:${k}`];

let _live = false;      // هل عندنا ختم موثوق (قُرئ من قبل)؟
let _prev = null;       // آخر ختم عالجناه
const _adopted = new Map(); // جهاز جديد: قسم ← ختم المرآة التي عُرضت منه (يُعامَل كأساس حتى أول قراءة حيّة)
let _ready = null;
let _last = 0;
let _running = false;
const _handlers = new Set();

export const stampsLive = () => _live;

/** المدة الفعلية للكاش: مفتاح مختوم وعندنا ختم ← السقف؛ غير ذلك ← المدة العادية */
export function ttlFor(cacheKey, normalMs) {
  return _live && stampKeyFor(cacheKey) ? STAMP_CAP_MS : normalMs;
}

/** يسجّل دالة تُستدعى (مجموعة أقسام تغيّرت) لتعيد جلب ما حُمّل فعلًا بهذه الجلسة */
export function onStampsChanged(fn) { _handlers.add(fn); }

async function _fetchStamps() {
  assertReadAllowed(); // القاطع مفتوح ← لا نقرأ
  const sb = await getSupabase();
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), TIMEOUT_MS);
  try {
    const res = await sb.from('settings').select('data').eq('key', STAMP_ROW_KEY).maybeSingle().abortSignal(ctrl.signal);
    if (res) noteOutcome({ status: res.status, error: res.error });
    if (!res || res.error) return null;
    const d = res.data?.data;
    return d && typeof d === 'object' && !Array.isArray(d) ? d : null; // لا صف = لم يُشغَّل SQL بعد
  } catch (err) {
    noteOutcome({ error: err });
    return null;
  } finally {
    clearTimeout(t);
  }
}

/** يقارن الأختام ويعلّم الأقسام المتغيرة. force=true يتجاوز مهلة الدقيقتين (البداية) */
export async function checkStamps({ force = false } = {}) {
  if (_running) return;
  if (typeof navigator !== 'undefined' && navigator.onLine === false) return;
  if (!force && Date.now() - _last < MIN_GAP_MS) return;
  _running = true;
  try {
    let s;
    try { s = await _fetchStamps(); } catch { return; }
    _last = Date.now();
    if (!s) return;
    // أول مرة نرى الأختام على هذا الجهاز: نعتبر كل شيء متغيرًا (الكاش القديم حُفظ بنظام المدد)
    // أول مرة نرى الأختام: كل شيء متغيّر، إلا قسمًا تبنّى ختم المرآة وعُرض منها (جهاز جديد بلا كاش) فيُقارَن بختمها
    const changed = new Set([...STAMPED].filter((k) => {
      if (_prev) return String(s[k]) !== String(_prev[k]);
      return !_adopted.has(k) || String(s[k]) !== String(_adopted.get(k));
    }));
    _live = true;
    if (changed.size) {
      for (const k of changed) for (const p of _prefixesOf(k)) { try { await cacheMarkStale(p); } catch { /* اختياري */ } }
      await Promise.all([..._handlers].map(async (h) => { try { await h(changed); } catch { /* اختياري */ } }));
    }
    _prev = s;
    _adopted.clear();
    try { await cachePut(STORE_KEY, s); } catch { /* اختياري */ }
  } finally {
    _running = false;
  }
}

/**
 * جهاز جديد بلا كاش لقسم، وعُرضت له مرآة الاستضافة: هل المرآة "حديثة" فلا حاجة لقراءة الجدول من السيرفر؟
 *  • جهاز يعرف أختامه ← حديثة فقط لو طابق ختمها ما يعرفه.
 *  • جهاز لم يقرأ الأختام بعد ← يتبنّى ختمها أساسًا، وأول قراءة حيّة (بعد ثوانٍ) تعلّم القسم قديمًا لو تغيّر.
 * ختم المرآة 0 يعني "لم يتغيّر قسمه منذ تركيب المحفّز" = ما يظهر في الصف الحي كقيمة غائبة.
 */
export function adoptMirrorStamp(section, stamp) {
  if (!STAMPED.has(section) || stamp === undefined || stamp === null) return false;
  const norm = Number(stamp) > 0 ? stamp : undefined;
  if (_prev) return String(_prev[section]) === String(norm);
  _adopted.set(section, norm);
  return true;
}

/** يشغّل المراقبة مرة واحدة ويحمّل آخر ختم محفوظ (محلي وسريع). تُستدعى قبل أول قراءة مختومة. */
export function stampsReady() {
  if (_ready) return _ready;
  _ready = (async () => {
    try {
      const e = await cacheGet(STORE_KEY);
      if (e?.value && typeof e.value === 'object') { _prev = e.value; _live = true; }
    } catch { /* نبدأ بلا ختم محفوظ */ }
    if (typeof window === 'undefined' || typeof document === 'undefined') return;
    setTimeout(() => { checkStamps({ force: true }); }, FIRST_DELAY_MS + Math.random() * 3000); // بعد أول رسم لا قبله
    const _soon = () => setTimeout(() => { checkStamps(); }, Math.random() * 4000); // تفريق الرجوع الجماعي (بعد انقطاع أو إشعار)
    document.addEventListener('visibilitychange', () => { if (!document.hidden) _soon(); });
    window.addEventListener('online', _soon);
    setInterval(() => { if (!document.hidden) checkStamps(); }, INTERVAL_MS);
  })();
  return _ready;
}

/** للاختبار فقط */
export function _resetForTests() { _live = false; _prev = null; _ready = null; _last = 0; _running = false; _handlers.clear(); _adopted.clear(); }
