// js/data/adapters/rate-guard.js — شبتوت بحري
// ══════════════════════════════════════════════════════════════
//  قاطع حماية (circuit breaker) لقراءات Supabase.
//  لو رجع الخادم 429 أو حد استهلاك (402/نص quota)، نوقف *القراءات* عدة دقائق فتخدمها الواجهة من الكاش
//  المحلي بدل أن يضاعف التطبيق الطلبات (إعادة محاولة × عدد المستخدمين) فيتعمّق الحد.
//  - الكتابات (فعل مستخدم نادر) لا تُحجب أبدًا.
//  - الإيقاف يتضاعف (٢ → ٤ → ٨ → أقصاه ١٠ دقائق) ويُصفَّر عند أول نجاح، مع إضافة عشوائية صغيرة لمدة الإيقاف
//    حتى لا تعيد آلاف الأجهزة المحاولة في اللحظة نفسها (jitter).
//  - أعطال الخادم (٥xx أو انتهاء مهلة) تفتح قاطعًا أخف (٣٠ث ← ٥ دقائق) بعد ٣ أعطال متتالية (٤ للمهلة/انقطاع الاتصال).
//  - يبقى بعد إعادة تحميل الصفحة (sessionStorage) كي لا يعيد التحميل الطلبات فورًا.
//  يستعمله _run في sb-helpers.js وsupabase-data-adapter.js.
// ══════════════════════════════════════════════════════════════

const KEY = 'akdar:rate-guard';
const BASE_MS = 2 * 60 * 1000;
const MAX_MS  = 10 * 60 * 1000;

let _until = 0;
let _level = 0;
let _softLevel = 0;   // مستوى إيقاف أعطال الخادم (٥xx/مهلة)
let _serverFails = 0; // أعطال ٥xx المتتالية
let _slowFails = 0;   // مهل/انقطاعات اتصال متتالية (قد تكون من شبكة المستخدم نفسه فنصبر أكثر)
const SOFT_BASE_MS = 30 * 1000;
const SOFT_MAX_MS  = 5 * 60 * 1000;
const SERVER_FAILS_TO_TRIP = 3;
const SLOW_FAILS_TO_TRIP = 4;
/** زيادة عشوائية حتى ٢٥٪ من المدة (بحد أقصى ٣٠ث): تفرّق الأجهزة بدل أن تعود كلها معًا */
const _jitter = (ms) => Math.random() * Math.min(30000, ms * 0.25);
try {
  const saved = JSON.parse(sessionStorage.getItem(KEY) || 'null');
  if (saved && Number(saved.until) > Date.now()) { _until = Number(saved.until); _level = Number(saved.level) || 0; _softLevel = Number(saved.soft) || 0; if (!_level && !_softLevel) _level = 1; }
} catch { /* بلا sessionStorage */ }

function _persist() {
  try { sessionStorage.setItem(KEY, JSON.stringify({ until: _until, level: _level, soft: _softLevel })); } catch { /* اختياري */ }
}

/** هل الطلب قراءة؟ (postgrest-js يضع method على الـbuilder؛ غيابه = نعتبره قراءة) */
export function isRead(builder) {
  const m = String(builder?.method || 'GET').toUpperCase();
  return m === 'GET' || m === 'HEAD';
}

/** القراءات موقوفة الآن؟ */
export function isTripped() {
  return Date.now() < _until;
}

/** كم ملّي ثانية تبقّى حتى تُستأنف القراءات (0 = غير موقوفة). تُستعمل لإعادة المحاولة التلقائية الصامتة. */
export function retryInMs() {
  return Math.max(0, _until - Date.now());
}

/** يرمي لو القاطع مفتوح — يُستدعى قبل كل قراءة. الاستدعاء يتعامل معه كما يتعامل مع offline: يعرض الكاش. */
export function assertReadAllowed() {
  if (Date.now() < _until) throw Object.assign(new Error('rate-limited'), { code: 'rate-limited' });
}

function _limitHit(status, error) {
  const st = Number(status || error?.status || 0);
  if (st === 429 || st === 402) return true;
  const code = String(error?.code || '');
  if (code === '429') return true;
  return /too many requests|rate.?limit|exceed.*(quota|limit)|quota.*exceed/i.test(String(error?.message || ''));
}

function _announceTrip() {
  try { window.dispatchEvent(new CustomEvent('akdar:rate-limited', { detail: { until: _until } })); } catch { /* بلا window */ }
}

function _isServerFail(status, error) {
  const st = Number(status || error?.status || 0);
  return st >= 500 && st <= 599;
}

// مهلة أو انقطاع اتصال أثناء الطلب (وليس "بلا إنترنت" أصلًا — هذا يُعالج في مكان آخر)
function _isSlowFail(error) {
  if (!error) return false;
  if (typeof navigator !== 'undefined' && navigator.onLine === false) return false;
  const code = String(error.code || '');
  const msg = String(error.message || '');
  return error.name === 'AbortError' || code === 'timeout' || msg === 'timeout' || /failed to fetch|network ?error|load failed/i.test(msg);
}

function _softTrip() {
  _softLevel = Math.min(_softLevel + 1, 6);
  const base = Math.min(SOFT_BASE_MS * 2 ** (_softLevel - 1), SOFT_MAX_MS);
  _until = Math.max(_until, Date.now() + base + _jitter(base));
  _serverFails = 0; _slowFails = 0;
  _persist();
  _announceTrip();
}

/** يفتح القاطع لو النتيجة/الخطأ يدل على حد استهلاك أو أعطال متتالية في الخادم؛ وإلا يصفّر المستوى عند النجاح. */
export function noteOutcome({ status, error } = {}) {
  if (_limitHit(status, error)) {
    _level = Math.min(_level + 1, 6);
    const base = Math.min(BASE_MS * 2 ** (_level - 1), MAX_MS);
    _until = Date.now() + base + _jitter(base);
    _serverFails = 0; _slowFails = 0;
    _persist();
    _announceTrip();
    return true;
  }
  if (_isServerFail(status, error)) {
    _slowFails = 0;
    if (++_serverFails >= SERVER_FAILS_TO_TRIP) { _softTrip(); return true; }
    return false;
  }
  if (_isSlowFail(error)) {
    if (++_slowFails >= SLOW_FAILS_TO_TRIP) { _softTrip(); return true; }
    return false;
  }
  if (!error) {
    _serverFails = 0; _slowFails = 0;
    if (_level || _softLevel) { _level = 0; _softLevel = 0; _until = 0; _persist(); }
  }
  return false;
}
