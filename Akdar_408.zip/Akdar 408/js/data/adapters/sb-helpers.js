// js/data/adapters/sb-helpers.js — شبتوت بحري
// ══════════════════════════════════════════════════════════════
//  أدوات مشتركة لمحوّلات Supabase الخاصة بالمحتوى العام (الدفعة ٢ب):
//  عميل القراءة/الكتابة، الطلب بمهلة، ترجمة الأخطاء، وكاش "اعرض المحفوظ ثم حدّث بالخلفية".
//  يستعملها supabase-content-adapter.js وsupabase-library-adapter.js.
//  (ليس محوّلًا: لا يُدمج في db.js.)
// ══════════════════════════════════════════════════════════════

import { getSupabase }       from '../supabase-client.js';
import { fetchStaticJson }   from '../hosts.js';
import { ensureSession }  from '../auth.js';
import { cacheGet, cachePut, cacheMarkStale } from '../read-cache.js';
import { isRead as _isReadReq, assertReadAllowed, noteOutcome } from './rate-guard.js';
import { stampKeyFor, ttlFor, stampsReady, stampsLive, onStampsChanged, adoptMirrorStamp } from '../cache-stamps.js';

export const _READ_TIMEOUT_MS  = 15000;
export const _WRITE_TIMEOUT_MS = 25000; // الكتابة بشبكة ضعيفة تحتاج صبرًا أطول


// ══════════════════════════════════════════════════════════════
//  أدوات داخلية (نفس روح supabase-data-adapter.js)
// ══════════════════════════════════════════════════════════════

export const _offline = () => typeof navigator !== 'undefined' && navigator.onLine === false;
// (v386) الشبكة "ضعيفة" لا تعني 2G فقط: اتصال القرية غالبًا يُعلن 3g/4g لكن بسرعة فعلية متدنية.
// نعدّها ضعيفة لو: توفير بيانات، أو 2g/3g، أو downlink أقل من ١.٥ ميجابت، أو rtt فوق ٧٠٠ms.
export const _isSlowNet = () => {
  try {
    const c = navigator.connection;
    if (!c) return false;
    if (c.saveData === true) return true;
    if (/(^|-)[23]g$/.test(c.effectiveType || '')) return true;
    if (typeof c.downlink === 'number' && c.downlink > 0 && c.downlink < 1.5) return true;
    if (typeof c.rtt === 'number' && c.rtt > 700) return true;
    return false;
  } catch { return false; }
};
// شبكة ضعيفة: نمدّ صلاحية الكاش ٥ أضعاف (التحديث الخلفي أقل مرات) — العرض نفسه دائمًا من الكاش فورًا
const _ttl = (ms) => ms * (_isSlowNet() ? 5 : 1);

export async function _sbWrite() {
  const sb = await getSupabase();
  await Promise.race([ensureSession(), new Promise(r => setTimeout(r, 8000))]);
  return sb;
}
export const _sbRead = () => getSupabase();

export async function _run(builder, ms = _READ_TIMEOUT_MS) {
  if (_offline()) throw Object.assign(new Error('offline'), { code: 'offline' });
  const isRead = _isReadReq(builder);
  if (isRead) assertReadAllowed(); // قاطع الحماية: عند 429/حد استهلاك نخدم من الكاش بدل مضاعفة الطلبات
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), ms);
  try {
    const res = await builder.abortSignal(ctrl.signal);
    if (isRead && res) noteOutcome({ status: res.status, error: res.error });
    return res;
  } catch (err) {
    if (ctrl.signal.aborted) {
      const te = Object.assign(new Error('timeout'), { code: 'timeout' });
      if (isRead) noteOutcome({ error: te }); // مهل متتالية = إشارة ضغط/عطل بالخادم
      throw te;
    }
    if (isRead) noteOutcome({ error: err });
    throw err;
  } finally {
    clearTimeout(timer);
  }
}

/** يترجم أخطاء الكتابة لرسائل عربية واضحة (الكود يظهر بين قوسين في الواجهة) */
export function _fail(error) {
  const code = String(error?.code || '');
  if (code === '42501' || /row-level security|permission denied/i.test(String(error?.message || ''))) {
    throw Object.assign(new Error('ما عندك صلاحية لهذا الإجراء — تأكد إنك مسجّل دخول بحساب الإدارة'), { code: code || '42501' });
  }
  if (code === '23503') throw Object.assign(new Error('المحتوى دا ما عاد موجود'), { code });
  throw error instanceof Error ? error : Object.assign(new Error(String(error?.message || 'حصل خطأ غير متوقع')), { code });
}

// ── مرآة المحتوى العام: content/mirror/<جدول>.json ───────────────────────────
// تُولَّد عند النشر بـ scripts/admin/export-public-mirror.mjs وتُخدَّم من الاستضافة نفسها (لا من Supabase).
// تُستعمل في موضعين فقط، وكلاهما حين لا نسخة بالجهاز:
//   ١) مصدرًا أول (seed) لأول فتح على جهاز جديد: تُعرض فورًا من الاستضافة، وتُعدّ حديثة (فلا يُقرأ الجدول من
//      Supabase إطلاقًا) لو طابق ختمها الختم الحي — راجع mirrorIsCurrent وadoptMirrorStamp في cache-stamps.js.
//   ٢) احتياطًا (fallback) حين تفشل قراءة الجدول (حصة نفدت، عطل، قاطع الحماية).
// ليست في CORE_ASSETS: لا تزيد وزن أول تثبيت. والـservice worker يجلبها شبكة-أولًا (تتجدد دون رفع CACHE_VERSION).
const _MIRROR_TIMEOUT_MS = 8000;
const _mirrors = new Map();   // جدول ← Promise<{rows, exportedAt}|null>
let _mirrorStamp = null;      // Promise<{stamps, checkedAt}|null>

// يمر عبر hosts.js: المضيف الحالي أولًا، ولو سقط/حُجب تُجلب الملفات نفسها من مضيف آخر (راجع MULTI-HOST.md).
// validate يرفض ردًّا سليم الشكل لكنه فارغ فيُجرَّب مضيف آخر.
const _tableOk = (d) => d?.version === 1 && Array.isArray(d.rows) && d.rows.length > 0;
const _stampOk = (d) => d?.v === 1 && d.stamps && typeof d.stamps === 'object';
function _mirrorJson(file, validate) {
  return fetchStaticJson(`content/mirror/${file}`, { timeoutMs: _MIRROR_TIMEOUT_MS, validate });
}

function _mirrorFile(table) {
  if (!_mirrors.has(table)) {
    _mirrors.set(table, _mirrorJson(`${encodeURIComponent(table)}.json`, _tableOk).then((data) => {
      if (!(data?.version === 1 && Array.isArray(data.rows) && data.rows.length)) { _mirrors.delete(table); return null; }
      return { rows: data.rows, exportedAt: Date.parse(data.exportedAt) || 0 };
    }));
  }
  return _mirrors.get(table);
}

function _mirrorStampFile() {
  if (!_mirrorStamp) {
    _mirrorStamp = _mirrorJson('_stamp.json', _stampOk).then((data) => {
      const checkedAt = Date.parse(data?.checkedAt);
      if (!(data?.v === 1 && data.stamps && typeof data.stamps === 'object' && checkedAt > 0)) { _mirrorStamp = null; return null; }
      return { stamps: data.stamps, checkedAt };
    });
  }
  return _mirrorStamp;
}

/** صفوف الجدول من المرآة (مرتّبة كما يرتّبها الـstore) أو null لو غابت/فرغت. */
export async function mirrorRows(table, { asc = false } = {}) {
  const m = await _mirrorFile(table);
  if (!m) return null;
  const dir = asc ? 1 : -1;
  const cmp = (a, b) => (String(a.created_at || '') < String(b.created_at || '') ? -1 : String(a.created_at || '') > String(b.created_at || '') ? 1 : 0);
  return m.rows.slice().sort((a, b) => dir * (cmp(a, b) || (String(a.id) < String(b.id) ? -1 : String(a.id) > String(b.id) ? 1 : 0)));
}

/** مرآة تُستعمل مصدرًا أول: مهلتها أقصر (٦ث) كي لا تؤخّر الشبكة لو كانت الاستضافة نفسها بطيئة */
export const mirrorSeed = (table, opts) => Promise.race([mirrorRows(table, opts), new Promise((r) => setTimeout(() => r(null), 6000))]);

/**
 * هل مرآة هذا الجدول حديثة بلا سؤال السيرفر؟ تحتاج ملف الأختام المرافق (_stamp.json).
 * الملف يُصدَّر دائمًا بعد قراءة الختم؛ فلو كان أقدم منه فالزوج غير متسق (كاش جزئي) ولا نثق به.
 */
export async function mirrorIsCurrent(table) {
  const [file, st] = await Promise.all([_mirrorFile(table), _mirrorStampFile()]);
  if (!file || !st || !(file.exportedAt >= st.checkedAt)) return false;
  return adoptMirrorStamp(table, st.stamps[table]);
}

// ── كاش القراءة: stale-while-revalidate ───────────────────────
const _inflight = new Map();
const _revalidating = new Set();
let _writeEpoch = 0; // يزيد مع كل كتابة: جلب بدأ قبلها لا يكتب فوق التعديل
const _loaders = new Map(); // مفاتيح مختومة حُمّلت بهذه الجلسة ← جالبها (لإعادة جلبها عند تغيّر ختمها)

function _announce(collection, id) {
  try { window.dispatchEvent(new CustomEvent('akdar:data-refreshed', { detail: { collection, id } })); }
  catch { /* بيئة بلا window */ }
}

function _dedupe(key, fetcher) {
  if (_inflight.has(key)) return _inflight.get(key);
  const p = Promise.resolve().then(fetcher).finally(() => _inflight.delete(key));
  _inflight.set(key, p);
  return p;
}

function _revalidate(key, fetcher, prev, collection) {
  if (_revalidating.has(key) || _offline()) return;
  _revalidating.add(key);
  const epoch = _writeEpoch;
  _dedupe(key, fetcher)
    .then((next) => {
      if (epoch !== _writeEpoch) return;
      cachePut(key, next);
      if (JSON.stringify(next) !== JSON.stringify(prev)) _announce(collection);
    })
    .catch(() => { /* النسخة المحفوظة تكفي */ })
    .finally(() => _revalidating.delete(key));
}

/**
 * @param {string} key
 * @param {() => Promise<any>} fetcher
 * @param {object} [opts]
 * @param {() => Promise<any[]|null>} [opts.seed] لقطة مشحونة مع التطبيق (content/feed-snapshot.json): تُعرض فورًا
 *        لو ما في كاش (أول فتح بعد التثبيت) بدل انتظار الشبكة حتى مهلة القراءة (١٥ث)، ثم يُحدَّث من السيرفر بالخلفية
 *        وتُعاد رسم الصفحة (akdar:data-refreshed). فشل/غياب اللقطة = السلوك القديم (انتظار الشبكة).
 * @param {() => Promise<boolean>} [opts.seedCurrent] للمفاتيح المختومة فقط: هل اللقطة حديثة (ختمها = الختم الحي)؟ نعم ← تُحفظ
 *        كنسخة طازجة ولا يُسأل السيرفر الآن (قراءة الأختام بعد ثوانٍ تعلّم القسم قديمًا لو تغيّر). لا/خطأ ← السلوك العادي.
 * @param {() => Promise<any[]|null>} [opts.fallback] احتياط عند فشل الجلب ولا كاش (مرآة content/mirror): تُعرض بدل الخطأ.
 */
export async function _rows(key, fetcher, { collection, ttlMs = 60000, fresh = false, seed, seedCurrent, fallback } = {}) {
  const stamped = Boolean(stampKeyFor(key));
  if (stamped) { await stampsReady(); _loaders.set(key, { fetcher, collection }); }
  if (!fresh) {
    const hit = await cacheGet(key);
    if (hit) {
      // (v389) قائمة فارغة محفوظة لا نثق بها: غالبًا حُفظت قبل وصول المحتوى للسيرفر، فتبقى الصفحة فارغة
      // حتى تنتهي مدة الكاش (قد تصل لـ٥٠ دقيقة بشبكة ضعيفة). نجلب الجديد فورًا بعد ٣٠ث،
      // ولو فشل الجلب (بلا نت) نعرض المحفوظ كما كان.
      if (!(stamped && stampsLive()) && Array.isArray(hit.value) && hit.value.length === 0 && Date.now() - hit.savedAt >= 30000 && !_offline()) {
        // لا ننتظر أكثر من ٤ ثوانٍ بشبكة ضعيفة: بعدها نعرض المحفوظ ويكمل الجلب بالخلفية ويُحفظ للزيارة التالية
        const epoch = _writeEpoch;
        const fetchP = _dedupe(key, fetcher).then((value) => {
          cachePut(key, value, epoch === _writeEpoch ? Date.now() : 0);
          return value;
        });
        return Promise.race([
          fetchP.catch(() => hit.value),
          new Promise((resolve) => setTimeout(() => resolve(hit.value), 4000)),
        ]);
      }
      if (Date.now() - hit.savedAt >= ttlFor(key, _ttl(ttlMs))) _revalidate(key, fetcher, hit.value, collection);
      return hit.value;
    }
    if (seed) {
      let snap = null;
      try { snap = await seed(); } catch { /* نكمل للشبكة */ }
      if (Array.isArray(snap) && snap.length) {
        let current = false;
        if (stamped && seedCurrent) { try { current = await seedCurrent(); } catch { /* نعدّها غير حديثة */ } }
        // حديثة ← طازجة الآن ولا جلب فوري. غير ذلك: savedAt=0 → "قديمة": أول تحديث ناجح يستبدلها، وبلا نت تبقى معروضة
        cachePut(key, snap, current ? Date.now() : 0);
        if (!current) _revalidate(key, fetcher, snap, collection);
        return snap;
      }
    }
  }
  const epoch = _writeEpoch;
  let value;
  try {
    value = await _dedupe(key, fetcher);
  } catch (err) {
    // فشلت القراءة ولا كاش بالجهاز: المرآة المشحونة مع الاستضافة أفضل من صفحة خطأ.
    // نحفظها بختم "قديمة" (savedAt=0) فيحاول التطبيق تجديدها من السيرفر عند أول فرصة.
    // لا تُستعمل مع القراءات الطازجة (قوائم الإدارة تحتاج المعلّق فورًا).
    if (fallback && !fresh) {
      let snap = null;
      try { snap = await fallback(); } catch { /* نرمي الخطأ الأصلي */ }
      if (Array.isArray(snap) && snap.length) { cachePut(key, snap, 0); return snap; }
    }
    throw err;
  }
  cachePut(key, value, epoch === _writeEpoch ? Date.now() : 0);
  return value;
}

/** بعد أي كتابة: نعلّم القوائم "قديمة" فتتصالح مع السيرفر بالخلفية */
export function _reconcile(...prefixes) {
  _writeEpoch++;
  prefixes.forEach((p) => cacheMarkStale(p).catch(() => {}));
}

export async function _patch(key, mutator) {
  _writeEpoch++;
  const e = await cacheGet(key);
  if (!e) return;
  try { await cachePut(key, mutator(Array.isArray(e.value) ? e.value.slice() : e.value), e.savedAt); }
  catch { /* الكاش اختياري */ }
}


// تغيّر ختم قسم: نعيد جلب ما حُمّل فعلًا بهذه الجلسة (فتُرسم الصفحة المفتوحة)، والباقي عُلِّم قديمًا ويتجدد عند فتحه
onStampsChanged(async (changed) => {
  for (const [key, { fetcher, collection }] of _loaders) {
    if (!changed.has(stampKeyFor(key))) continue;
    const hit = await cacheGet(key);
    _revalidate(key, fetcher, hit?.value, collection);
  }
});
