// js/data/runtime-config.js
// ⚠️ مولَّد تلقائيًا بواسطة build/gen-runtime-config.js — لا تعدّله يدويًا.
//    البيئة تتحدد بالمتغيّر AKDAR_ENV (development | production)؛ الافتراضي development.
//    لا تُستخدم الأسرار هنا؛ أي سر حقيقي يجب أن يبقى في متغيرات البيئة.
export const RUNTIME_CONFIG = Object.freeze({
  environment: 'production',
  useLocalDemoUser: false,
  enableRealPush: true,
  enableRemoteNotifications: true,
});

export const IS_DEVELOPMENT = RUNTIME_CONFIG.environment === 'development';
