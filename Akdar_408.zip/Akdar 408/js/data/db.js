// js/data/db.js — شبتوت بحري
// ══════════════════════════════════════════════════════════════
//  طبقة البيانات المركزية
//  كل الدوال تمر عبر محوّلات Supabase (js/data/adapters/supabase-*.js).
// ══════════════════════════════════════════════════════════════

// ─── ADAPTER ───────────────────────────────────────────────────────────────
import { formatRelativeTime as _formatRelativeTime } from '../shared/relative-time.js';
// الانتقال إلى Supabase تم على دفعات. (الدفعة ١: الأفكار/المناسبات/التعليقات...؛ ٢أ: الإشعارات/
// الوارد/الأعضاء؛ ٢ب: المحتوى العام على مراحل — ١: الأخبار والفعاليات، ٢: الذاكرة/التاريخ/الرابطة/
// المشاريع/المعرض/الدليل/القاموس، ٣: البحث/المستلمون/الأرشيف.)
import * as supabaseDataAdapter from './adapters/supabase-data-adapter.js';
import * as supabaseContentAdapter from './adapters/supabase-content-adapter.js';
import * as supabaseLibraryAdapter from './adapters/supabase-library-adapter.js';
import * as supabaseMiscAdapter from './adapters/supabase-misc-adapter.js';

// كل دوال البيانات صارت على Supabase (الدفعة ٢ب — المرحلة ٣: البحث/المستلمون/الأرشيف). Firebase لم يعد
// يُحمَّل من هنا أبدًا؛ يبقى فقط لنافذة تسجيل الدخول بجوجل (auth.js — تحميل كسول عند الدخول).
const adapter = { ...supabaseContentAdapter, ...supabaseLibraryAdapter, ...supabaseMiscAdapter, ...supabaseDataAdapter };
// ─────────────────────────────────────────────────────────────────────────────

// رفع الصور مستقل عن الـadapter بتاع البيانات فوق — بيروح لـSupabase Storage
// دايمًا بغض النظر النصوص/القوائم (Cloudinary غير
// متاح في بلدنا، وFirebase Storage يتطلب فوترة). راجع التعليق أعلى
// supabase-adapter.js لإعداد الحساب أول مرة. للرجوع: بدّل هذا السطر فقط.
import * as imageAdapter from './adapters/supabase-adapter.js';

import { enforceMaxLength, enforceCooldown, enforceReadable } from '../shared/submission-guard.js';
import { OCCASION_COMMENT_MAX_LENGTH } from './occasion-categories.js';


// ══════════════════════════════════════════════════════════════
//  رفع الصور
//  مصدر واحد لأي رفع صورة في التطبيق — معرض الصور، الأخبار،
//  مقالات تاريخ بلدنا... إلخ. يُستخدم عبر image-upload-field.js
//  (js/shared) بدل ما كل صفحة إدارة تتعامل مع التخزين مباشرة.
// ══════════════════════════════════════════════════════════════

/**
 * رفع صورة (من المعرض) إلى التخزين السحابي (Supabase حاليًا)
 * @param {Blob} blob الصورة بعد الضغط/التصغير
 * @param {{ pathPrefix?: string, onProgress?: (pct:number)=>void }} [options]
 * @returns {Promise<{ url: string, path: string }>}
 */
export async function uploadImage(blob, options = {}) {
  return imageAdapter.uploadImage(blob, options);
}

/**
 * المساحة المستهلكة من تخزين الصور (للوحة الإدارة)
 * @returns {Promise<{ bytes: number, files: number }>}
 */
export async function getImageStorageUsage() {
  return imageAdapter.getImageStorageUsage();
}

/** إحصاءات الاستهلاك للوحة الإدارة: المساعد اليوم + حجم القاعدة وأكبر الجداول */
export async function getUsageStats() {
  return imageAdapter.fetchUsageStats();
}


// ══════════════════════════════════════════════════════════════
//  الأخبار
// ══════════════════════════════════════════════════════════════

// ── تنظيف صور Storage بعد حذف المحتوى ─────────────────────────────────────
// نقرأ السجل قبل حذفه (لنعرف صورته)، نحذفه، ثم نطلب حذف الصورة — والمحوّل يتأكد أنها غير مستخدمة
// في سجل آخر (زر "اختر من صور البلد" يشاركها) ولا يفشل حذف المحتوى بسبب التنظيف.
async function _deleteWithImageCleanup(getItem, doDelete, id) {
  let image = '';
  try { image = (await getItem(id))?.image || ''; } catch { /* نكمل الحذف بدون تنظيف */ }
  const result = await doDelete(id);
  if (image) imageAdapter.deleteStoredImages([image]).catch(() => {});
  return result;
}

/**
 * جلب قائمة الأخبار
 * @param {{ category?: string, limit?: number }} options
 * @returns {Promise<Array>}
 */
export async function getNews(options = {}) {
  return adapter.getNews(options);
}

/**
 * أرخص من getNews() الكاملة — بس معرّف أحدث خبر (لنقطة "جديد" في
 * الرئيسية).
 * @returns {Promise<string|number|null>}
 */
export async function getLatestNewsId() {
  return adapter.getLatestNewsId();
}

/**
 * معرّفات أحدث عناصر قسم (نافذة صغيرة) — لعدّادات "جديد" على بطاقات
 * الرئيسية/الخدمات (js/shared/section-badges.js).
 * @param {'news'|'occasions'|'ideas'|'events'} section
 * @returns {Promise<Array<string|number>>}
 */
export async function getRecentContentIds(section) {
  return adapter.getRecentContentIds(section);
}

/**
 * جلب خبر واحد بمعرّفه
 * @param {string|number} id
 * @returns {Promise<Object|null>}
 */
export async function getNewsItem(id) {
  return adapter.getNewsItem(id);
}

/**
 * جلب الخبر العاجل (آخر خبر مميّز بـ breaking: true)
 * @returns {Promise<Object|null>}
 */
export async function getBreakingNews() {
  return adapter.getBreakingNews();
}

/**
 * إضافة خبر جديد (تُستخدم من لوحة الإدارة)
 * @param {Object} newsItem
 * @returns {Promise<Object>} العنصر المحفوظ مع id
 */
export async function addNews(newsItem) {
  return adapter.addNews(newsItem);
}

/**
 * تحديث خبر موجود
 * @param {string|number} id
 * @param {Object} updates
 * @returns {Promise<Object>}
 */
export async function updateNews(id, updates) {
  return adapter.updateNews(id, updates);
}

/**
 * حذف خبر
 * @param {string|number} id
 * @returns {Promise<void>}
 */
export async function deleteNews(id) {
  return _deleteWithImageCleanup(getNewsItem, (x) => adapter.deleteNews(x), id);
}

/**
 * أرشفة/استعادة خبر يدوياً (لوحة الإدارة)
 * @param {string|number} id
 * @param {'archived'|'restored'} state
 */
export async function setNewsArchiveState(id, state) {
  return adapter.setNewsArchiveState(id, state);
}


// ══════════════════════════════════════════════════════════════
//  مناسبات القرية (فيديوهات يوتيوب)
// ══════════════════════════════════════════════════════════════

/**
 * جلب قائمة فيديوهات المناسبات
 * @returns {Promise<Array>}
 */
export async function getEvents() {
  return adapter.getEvents();
}

/**
 * إضافة مناسبة جديدة (تُستخدم من لوحة الإدارة)
 * @param {Object} eventItem
 * @returns {Promise<Object>} العنصر المحفوظ مع id
 */
export async function addEvent(eventItem) {
  return adapter.addEvent(eventItem);
}

/**
 * تحديث مناسبة موجودة
 * @param {string|number} id
 * @param {Object} updates
 * @returns {Promise<Object>}
 */
export async function updateEvent(id, updates) {
  return adapter.updateEvent(id, updates);
}

/**
 * حذف مناسبة
 * @param {string|number} id
 * @returns {Promise<void>}
 */
export async function deleteEvent(id) {
  return adapter.deleteEvent(id);
}


// ══════════════════════════════════════════════════════════════
//  خدمات الطلاب — فيديوهات الحصص (روابط يوتيوب) + النصائح الأكاديمية
//  stage: 'basic' | 'intermediate' | 'secondary' (والنصائح تقبل 'general' كذلك)
// ══════════════════════════════════════════════════════════════

/** @returns {Promise<Array>} فيديوهات الحصص (الأحدث أولاً) */
export async function getStudyVideos() {
  return adapter.getStudyVideos();
}
/** @param {{youtubeId:string, stage:string, title:string, subject?:string, teacher?:string, excerpt?:string}} item */
export async function addStudyVideo(item) {
  return adapter.addStudyVideo(item);
}
export async function updateStudyVideo(id, updates) {
  return adapter.updateStudyVideo(id, updates);
}
export async function deleteStudyVideo(id) {
  return adapter.deleteStudyVideo(id);
}

/** @returns {Promise<Array>} النصائح الأكاديمية (الأحدث أولاً) */
export async function getStudyTips() {
  return adapter.getStudyTips();
}
/** @param {{stage:string, title:string, body:string}} item */
export async function addStudyTip(item) {
  return adapter.addStudyTip(item);
}
export async function updateStudyTip(id, updates) {
  return adapter.updateStudyTip(id, updates);
}
export async function deleteStudyTip(id) {
  return adapter.deleteStudyTip(id);
}


// ══════════════════════════════════════════════════════════════
//  المحاضرات الدينية (قسم العبادة) — روابط يوتيوب
// ══════════════════════════════════════════════════════════════

export async function getWorshipLectures() {
  return adapter.getWorshipLectures();
}
/** @param {{youtubeId:string, title:string, speaker?:string, excerpt?:string}} item */
export async function addWorshipLecture(item) {
  return adapter.addWorshipLecture(item);
}
export async function updateWorshipLecture(id, updates) {
  return adapter.updateWorshipLecture(id, updates);
}
export async function deleteWorshipLecture(id) {
  return adapter.deleteWorshipLecture(id);
}


// ══════════════════════════════════════════════════════════════
//  مقالات تاريخ بلدنا
// ══════════════════════════════════════════════════════════════

/**
 * جلب مقالات قسم تاريخي معيّن (أو كل المقالات إن لم يُحدَّد قسم)
 * @param {string} [section] — أحد مفاتيح HISTORY_SECTIONS
 * @returns {Promise<Array>}
 */
export async function getHistoryArticles(section, options) {
  return adapter.getHistoryArticles(section, options);
}

/**
 * جلب مقال واحد بمعرّفه
 * @param {string|number} id
 * @returns {Promise<Object|null>}
 */
export async function getHistoryArticle(id) {
  return adapter.getHistoryArticle(id);
}

/**
 * إضافة مقال تاريخي جديد (تُستخدم من لوحة الإدارة)
 * @param {Object} articleItem
 * @returns {Promise<Object>} العنصر المحفوظ مع id
 */
export async function addHistoryArticle(articleItem) {
  return adapter.addHistoryArticle(articleItem);
}

/**
 * تحديث مقال موجود
 * @param {string|number} id
 * @param {Object} updates
 * @returns {Promise<Object>}
 */
export async function updateHistoryArticle(id, updates) {
  return adapter.updateHistoryArticle(id, updates);
}

/**
 * حذف مقال
 * @param {string|number} id
 * @returns {Promise<void>}
 */
export async function deleteHistoryArticle(id) {
  return _deleteWithImageCleanup(getHistoryArticle, (x) => adapter.deleteHistoryArticle(x), id);
}

/**
 * جلب مقالات قسم من مسيرة الرابطة معيّن (أو كل المقالات إن لم يُحدَّد قسم)
 * نفس نمط getHistoryArticles بالظبط.
 * @param {string} [section] — أحد مفاتيح ASSOCIATION_JOURNEY_SECTIONS
 * @returns {Promise<Array>}
 */
export async function getAssociationJourneyArticles(section, options) {
  return adapter.getAssociationJourneyArticles(section, options);
}

/**
 * جلب مقال واحد من مسيرة الرابطة بمعرّفه
 * @param {string|number} id
 * @returns {Promise<Object|null>}
 */
export async function getAssociationJourneyArticle(id) {
  return adapter.getAssociationJourneyArticle(id);
}

/**
 * إضافة مقال جديد لمسيرة الرابطة (تُستخدم من لوحة الإدارة)
 * @param {Object} articleItem
 * @returns {Promise<Object>} العنصر المحفوظ مع id
 */
export async function addAssociationJourneyArticle(articleItem) {
  return adapter.addAssociationJourneyArticle(articleItem);
}

/**
 * تحديث مقال موجود في مسيرة الرابطة
 * @param {string|number} id
 * @param {Object} updates
 * @returns {Promise<Object>}
 */
export async function updateAssociationJourneyArticle(id, updates) {
  return adapter.updateAssociationJourneyArticle(id, updates);
}

/**
 * حذف مقال من مسيرة الرابطة
 * @param {string|number} id
 * @returns {Promise<void>}
 */
export async function deleteAssociationJourneyArticle(id) {
  return _deleteWithImageCleanup(getAssociationJourneyArticle, (x) => adapter.deleteAssociationJourneyArticle(x), id);
}


// ══════════════════════════════════════════════════════════════
//  مشاريعنا (متابعة المشاريع)
// ══════════════════════════════════════════════════════════════

/**
 * جلب كل مشاريع التنمية
 * @returns {Promise<Array>}
 */
export async function getProjects() {
  return adapter.getProjects();
}

/**
 * جلب مشروع واحد بمعرّفه
 * @param {string|number} id
 * @returns {Promise<Object|null>}
 */
export async function getProject(id) {
  return adapter.getProject(id);
}

/**
 * إضافة مشروع جديد (تُستخدم من لوحة الإدارة)
 * @param {Object} projectItem
 * @returns {Promise<Object>} العنصر المحفوظ مع id
 */
export async function addProject(projectItem) {
  return adapter.addProject(projectItem);
}

/**
 * تحديث مشروع موجود
 * @param {string|number} id
 * @param {Object} updates
 * @returns {Promise<Object>}
 */
export async function updateProject(id, updates) {
  return adapter.updateProject(id, updates);
}

/**
 * حذف مشروع
 * @param {string|number} id
 * @returns {Promise<void>}
 */
export async function deleteProject(id) {
  return _deleteWithImageCleanup(getProject, (x) => adapter.deleteProject(x), id);
}


/**
 * جلب كلمات قاموس الرُطانة (اللغة النوبية) — لتصنيف معيّن أو كل الكلمات
 * @param {string} [category] — أحد مفاتيح NUBIAN_LANGUAGE_CATEGORIES
 * @returns {Promise<Array>}
 */
export async function getNubianWords(category) {
  return adapter.getNubianWords(category);
}

/**
 * إضافة كلمة جديدة لقاموس الرُطانة (تُستخدم من لوحة الإدارة)
 * @param {Object} wordItem — { ar, nub, translit, group?, category }
 * @returns {Promise<Object>} العنصر المحفوظ مع id
 */
export async function addNubianWord(wordItem) {
  return adapter.addNubianWord(wordItem);
}

/**
 * تحديث كلمة موجودة في قاموس الرُطانة
 * @param {string|number} id
 * @param {Object} updates
 * @returns {Promise<Object>}
 */
export async function updateNubianWord(id, updates) {
  return adapter.updateNubianWord(id, updates);
}

/**
 * حذف كلمة من قاموس الرُطانة
 * @param {string|number} id
 * @returns {Promise<void>}
 */
export async function deleteNubianWord(id) {
  return adapter.deleteNubianWord(id);
}


/**
 * تصنيفات قاموس الكلمات: الـ17 الأساسية (بتعديلاتها) + ما أضافه المشرف
 * @returns {Promise<Array>} [{ key, title, subtitle, icon, words, custom? }]
 */
export async function getNubianWordCategories() {
  return adapter.getNubianWordCategories();
}

/**
 * إضافة تصنيف كلمات (بلا key) أو تعديل اسم/أيقونة تصنيف (مع key)
 * @param {{ key?: string, title: string, icon?: string }} category
 */
export async function saveNubianWordCategory(category) {
  return adapter.saveNubianWordCategory(category);
}

/**
 * حذف تصنيف كلمات أضافه المشرف (مع كلماته) — الأساسية لا تُحذف
 * @param {string} key
 * @returns {Promise<{removedWordsCount: number}>}
 */
export async function deleteNubianWordCategory(key) {
  return adapter.deleteNubianWordCategory(key);
}

/**
 * جلب تصنيفات "تعلم الكلام" (جمل آنداندي) — قابلة للتعديل من لوحة
 * الإدارة، بعكس تصنيفات الكلمات الثابتة
 * @returns {Promise<Array>} [{ key, title, icon }]
 */
export async function getNubianPhraseCategories() {
  return adapter.getNubianPhraseCategories();
}

/**
 * إضافة تصنيف جديد لـ"تعلم الكلام"
 * @param {Object} category — { title, icon? }
 * @returns {Promise<Object>}
 */
export async function addNubianPhraseCategory(category) {
  return adapter.addNubianPhraseCategory(category);
}

/**
 * تعديل عنوان/أيقونة تصنيف موجود في "تعلم الكلام"
 * @param {string} key
 * @param {Object} updates
 * @returns {Promise<Object>}
 */
export async function updateNubianPhraseCategory(key, updates) {
  return adapter.updateNubianPhraseCategory(key, updates);
}

/**
 * حذف تصنيف من "تعلم الكلام" — يحذف جمله المرتبطة به تلقائياً
 * @param {string} key
 * @returns {Promise<{removedPhrasesCount: number}>}
 */
export async function deleteNubianPhraseCategory(key) {
  return adapter.deleteNubianPhraseCategory(key);
}

/**
 * جلب جمل "تعلم الكلام" — لتصنيف معيّن أو كل الجمل
 * @param {string} [category]
 * @returns {Promise<Array>}
 */
export async function getNubianPhrases(category) {
  return adapter.getNubianPhrases(category);
}

/**
 * إضافة جملة جديدة لـ"تعلم الكلام"
 * @param {Object} phraseItem — { ar, nub, translit, note?, category }
 * @returns {Promise<Object>}
 */
export async function addNubianPhrase(phraseItem) {
  return adapter.addNubianPhrase(phraseItem);
}

/**
 * تحديث جملة موجودة في "تعلم الكلام"
 * @param {string|number} id
 * @param {Object} updates
 * @returns {Promise<Object>}
 */
export async function updateNubianPhrase(id, updates) {
  return adapter.updateNubianPhrase(id, updates);
}

/**
 * حذف جملة من "تعلم الكلام"
 * @param {string|number} id
 * @returns {Promise<void>}
 */
export async function deleteNubianPhrase(id) {
  return adapter.deleteNubianPhrase(id);
}

/**
 * عدّادات تصنيفات كلمات/جمل آنداندي للإدارة — طلب صغير بدل تنزيل كل العناصر.
 * @returns {Promise<Array<{category:string,total:number,noAudio:number,noTranslation:number}>>}
 *   يرمي { code:'rpc_missing' } لو لم يُشغَّل 20261107_nubian_scale.sql (الواجهة ترجع للجلب الكامل).
 */
export async function getNubianWordStats() { return adapter.getNubianWordStats(); }
export async function getNubianPhraseStats() { return adapter.getNubianPhraseStats(); }

/**
 * صفحة واحدة من الكلمات/الجمل (تصفح الإدارة).
 * @param {{category?:string, filter?:'all'|'no-audio'|'no-translation', query?:string, offset?:number, limit?:number}} params
 * @returns {Promise<{items:Array,total:number}>} total = كل المطابق للاستعلام
 */
export async function queryNubianWords(params) { return adapter.queryNubianWords(params); }
export async function queryNubianPhrases(params) { return adapter.queryNubianPhrases(params); }


// ══════════════════════════════════════════════════════════════
//  معرض الصور (صور البلد)
// ══════════════════════════════════════════════════════════════

/**
 * جلب صور المعرض (أو صور تصنيف معيّن إن حُدِّد)
 * @param {string} [category] — أحد مفاتيح GALLERY_CATEGORIES
 * @returns {Promise<Array>}
 */
export async function getGalleryItems(category) {
  return adapter.getGalleryItems(category);
}

/**
 * جلب صورة واحدة بمعرّفها
 * @param {string|number} id
 * @returns {Promise<Object|null>}
 */
export async function getGalleryItem(id) {
  return adapter.getGalleryItem(id);
}

/**
 * إضافة صورة جديدة للمعرض (تُستخدم من لوحة الإدارة)
 * @param {Object} galleryItem
 * @returns {Promise<Object>} العنصر المحفوظ مع id
 */
export async function addGalleryItem(galleryItem) {
  return adapter.addGalleryItem(galleryItem);
}

/**
 * تحديث صورة موجودة
 * @param {string|number} id
 * @param {Object} updates
 * @returns {Promise<Object>}
 */
export async function updateGalleryItem(id, updates) {
  return adapter.updateGalleryItem(id, updates);
}

/**
 * حذف صورة من المعرض
 * @param {string|number} id
 * @returns {Promise<void>}
 */
export async function deleteGalleryItem(id) {
  return _deleteWithImageCleanup(getGalleryItem, (x) => adapter.deleteGalleryItem(x), id);
}


// ══════════════════════════════════════════════════════════════
//  دليل الاتصال
// ══════════════════════════════════════════════════════════════

/**
 * جلب جهات اتصال قسم معيّن (أو كل الجهات إن لم يُحدَّد قسم)
 * @param {string} [categoryKey] — أحد مفاتيح CONTACT_CATEGORY_DEFS
 * @returns {Promise<Array>}
 */
export async function getContacts(categoryKey) {
  return adapter.getContacts(categoryKey);
}

/**
 * جلب جهة اتصال واحدة بمعرّفها
 * @param {string|number} id
 * @returns {Promise<Object|null>}
 */
export async function getContact(id) {
  return adapter.getContact(id);
}

/**
 * إضافة جهة اتصال جديدة (تُستخدم من لوحة الإدارة)
 * @param {Object} contactItem
 * @returns {Promise<Object>} العنصر المحفوظ مع id
 */
export async function addContact(contactItem) {
  return adapter.addContact(contactItem);
}

/**
 * تحديث جهة اتصال موجودة
 * @param {string|number} id
 * @param {Object} updates
 * @returns {Promise<Object>}
 */
export async function updateContact(id, updates) {
  return adapter.updateContact(id, updates);
}

/**
 * حذف جهة اتصال
 * @param {string|number} id
 * @returns {Promise<void>}
 */
export async function deleteContact(id) {
  return adapter.deleteContact(id);
}


// ══════════════════════════════════════════════════════════════
//  البحث
// ══════════════════════════════════════════════════════════════

/**
 * بحث نصي عبر كل المحتوى
 * @param {string} query
 * @returns {Promise<Array>}
 */
export async function search(query) {
  return adapter.search(query);
}


// ══════════════════════════════════════════════════════════════
//  الإشعارات (سجل محلي)
// ══════════════════════════════════════════════════════════════

/**
 * جلب قائمة الإشعارات المحفوظة محلياً
 * @returns {Promise<Array>}
 */
export async function getNotifications(options) {
  return adapter.getNotifications(options);
}

/**
 * أرشفة/استعادة رسالة يدوياً (لوحة الإدارة)
 * @param {string|number} id
 * @param {'archived'|'restored'} state
 */
export async function setNotificationArchiveState(id, state) {
  return adapter.setNotificationArchiveState(id, state);
}

/**
 * تعليم إشعار كمقروء
 * @param {string|number} id
 * @returns {Promise<void>}
 */
export async function markNotificationRead(id) {
  return adapter.markNotificationRead(id);
}

/**
 * حفظ إشعار وارد (يُستدعى من push.js)
 * @param {Object} notification
 * @returns {Promise<void>}
 */
export async function saveNotification(notification) {
  return adapter.saveNotification(notification);
}

/**
 * عدد الإشعارات غير المقروءة — لشارة العداد في الناف السفلي
 * @returns {Promise<number>}
 */
export async function getUnreadNotificationsCount(options) {
  return adapter.getUnreadNotificationsCount(options);
}

/**
 * إضافة إشعار جديد (تُستخدم من لوحة الإدارة — "الإرسال")
 * @param {Object} notification
 * @returns {Promise<Object>}
 */
export async function addNotification(notification) {
  return adapter.addNotification(notification);
}

/**
 * تحديث إشعار موجود (تعديل من لوحة الإدارة)
 * @param {string|number} id
 * @param {Object} updates
 * @returns {Promise<Object>}
 */
export async function updateNotification(id, updates) {
  return adapter.updateNotification(id, updates);
}

/**
 * حذف إشعار (من لوحة الإدارة)
 * @param {string|number} id
 * @returns {Promise<void>}
 */
export async function deleteNotification(id) {
  return adapter.deleteNotification(id);
}


// ══════════════════════════════════════════════════════════════
//  صندوق الأفكار
// ══════════════════════════════════════════════════════════════

/**
 * جلب قائمة الأفكار (مع حالة محسوبة ونسبة تأييد جاهزة للعرض)
 * @param {{ category?: string, sort?: 'top'|'new' }} options
 * @returns {Promise<Array>}
 */
export async function getIdeas(options = {}) {
  return adapter.getIdeas(options);
}

/**
 * أرخص من getIdeas() الكاملة — بس معرّف أحدث فكرة (لنقطة "جديد" في
 * بطاقة "مصنع الأفكار" بصفحة الخدمات).
 * @returns {Promise<string|number|null>}
 */
export async function getLatestIdeaId() {
  return adapter.getLatestIdeaId();
}

/**
 * جلب فكرة واحدة بمعرّفها
 * @param {string} id
 * @returns {Promise<Object|null>}
 */
export async function getIdea(id) {
  return adapter.getIdea(id);
}

/**
 * نشر فكرة جديدة
 * @param {Object} ideaData
 * @returns {Promise<Object>} الفكرة المحفوظة مع id
 */
export async function addIdea(ideaData) {
  enforceMaxLength({
    title:       { value: ideaData.title,       max: 80,  label: 'عنوان الفكرة' },
    description: { value: ideaData.description, max: 400, label: 'وصف الفكرة' },
    benefit:     { value: ideaData.benefit || '', max: 300, label: 'الفائدة' },
    proposedEntity: { value: ideaData.proposedEntity || '', max: 120, label: 'الجهة المقترحة' },
  });
  // فلتر الطلاسم (الحقول الإجبارية بحد أدنى؛ الاختيارية تُفحص لو مملوءة)
  enforceReadable({
    title:       { value: ideaData.title,       label: 'عنوان الفكرة', minLetters: 4 },
    description: { value: ideaData.description, label: 'وصف الفكرة',   minLetters: 15 },
    benefit:     { value: ideaData.benefit || '', label: 'الفائدة',     minLetters: 3 },
  });
  // مراجعة قبل الظهور: أي مستخدم عادي تُنشر فكرته "قيد المراجعة"؛ المشرفون
  // (staffRole) تُنشر لهم مباشرة. القواعد تفرض ده في Firebase.
  // التهدئة بعد الفحص عشان محاولة مرفوضة (طلاسم/طويل) ما تستهلك وقت الانتظار
  enforceCooldown('add-idea');
  const payload = ideaData.staffRole ? ideaData : { ...ideaData, moderation: 'pending' };
  return adapter.addIdea(payload);
}

/**
 * تصويت مستخدم على فكرة (صوت واحد لكل مستخدم، قابل للتغيير)
 * @param {string} ideaId
 * @param {string} uid
 * @param {'up'|'down'} value
 * @returns {Promise<{ votesUp: number, votesDown: number }>}
 */
export async function voteIdea(ideaId, uid, value) {
  if (value !== 'up' && value !== 'down') {
    throw new Error('قيمة التصويت ما صالحة');
  }
  return adapter.voteIdea(ideaId, uid, value);
}

/**
 * جلب صوت مستخدم معيّن على فكرة (لمعرفة إن كان صوّت من قبل)
 * @param {string} ideaId
 * @param {string} uid
 * @returns {Promise<'up'|'down'|null>}
 */
export async function getUserVote(ideaId, uid) {
  const { getPendingReaction } = await import('../shared/reaction-outbox.js'); // تحميل كسول: لا يدخل مسار الإقلاع
  const pending = getPendingReaction('idea-vote', ideaId, uid); // تصويته المعلّق أحدث من أي شيء على الخادم
  if (pending) return pending;
  return adapter.getUserVote(ideaId, uid);
}

/**
 * جلب تعليقات فكرة
 * @param {string} ideaId
 * @returns {Promise<Array>}
 */
export async function getIdeaComments(ideaId) {
  return adapter.getIdeaComments(ideaId);
}

/**
 * إضافة تعليق على فكرة (بدون ردود)
 * @param {string} ideaId
 * @param {{ uid: string, authorName: string, text: string }} comment
 * @returns {Promise<Object>}
 */
export async function addIdeaComment(ideaId, comment) {
  enforceCooldown('add-idea-comment', 2500);
  enforceMaxLength({
    text: { value: comment.text, max: 500, label: 'التعليق' },
  });
  return adapter.addIdeaComment(ideaId, comment);
}

/**
 * إعجاب/إلغاء إعجاب بتعليق على فكرة (تبديل) — بدون cooldown، نفس مبدأ
 * voteIdea (تفاعل فوري قابل للتراجع، مش نشر محتوى).
 * @param {string} ideaId
 * @param {string} commentId
 * @param {string} uid
 * @returns {Promise<{liked: boolean, likesCount: number}>}
 */
export async function toggleIdeaCommentLike(ideaId, commentId, uid) {
  return adapter.toggleIdeaCommentLike(ideaId, commentId, uid);
}

/**
 * حذف فكرة (لوحة الإدارة)
 * @param {string} id
 * @returns {Promise<void>}
 */
export async function deleteIdea(id) {
  return adapter.deleteIdea(id);
}

/**
 * تعديل فكرة (لوحة الإدارة — تصحيح بدل حذف)
 * @param {string} id
 * @param {{title?, description?, benefit?, category?, proposedEntity?}} patch
 * @returns {Promise<Object>}
 */
export async function updateIdea(id, patch) {
  return adapter.updateIdea(id, patch);
}

/**
 * أرشفة/استعادة فكرة يدوياً (لوحة الإدارة)
 * @param {string} id
 * @param {'archived'|'restored'} state
 */
export async function setIdeaArchiveState(id, state) {
  return adapter.setIdeaArchiveState(id, state);
}

// ══════════════════════════════════════════════════════════════
//  بيت مناسباتنا
// ══════════════════════════════════════════════════════════════

/**
 * جلب قائمة المناسبات
 * @param {{ category?: string }} options
 * @returns {Promise<Array>}
 */
export async function getOccasions(options = {}) {
  return adapter.getOccasions(options);
}

/**
 * أرخص من getOccasions() الكاملة — بس معرّف أحدث مناسبة (لنقطة
 * "جديد" في الرئيسية).
 * @returns {Promise<string|number|null>}
 */
export async function getLatestOccasionId() {
  return adapter.getLatestOccasionId();
}

/**
 * جلب مناسبة واحدة بمعرّفها
 * @param {string} id
 * @returns {Promise<Object|null>}
 */
export async function getOccasion(id) {
  return adapter.getOccasion(id);
}

/**
 * نشر مناسبة جديدة
 * @param {Object} occasionData
 * @returns {Promise<Object>} المناسبة المحفوظة مع id
 */
export async function addOccasion(occasionData) {
  enforceMaxLength({
    title:     { value: occasionData.title,       max: 100, label: 'عنوان المناسبة' },
    ownerName: { value: occasionData.ownerName,    max: 60,  label: 'اسم صاحب المناسبة' },
    text:      { value: occasionData.text || '',   max: 300, label: 'النص' },
  });
  enforceReadable({
    title:     { value: occasionData.title,     label: 'عنوان المناسبة',  minLetters: 4 },
    ownerName: { value: occasionData.ownerName, label: 'اسم صاحب المناسبة', minLetters: 3 },
    text:      { value: occasionData.text || '', label: 'النص',           minLetters: 5 },
  });
  enforceCooldown('add-occasion');
  const payload = occasionData.staffRole ? occasionData : { ...occasionData, moderation: 'pending' };
  return adapter.addOccasion(payload);
}

/**
 * جلب تعليقات مناسبة
 * @param {string} occasionId
 * @returns {Promise<Array>}
 */
export async function getOccasionComments(occasionId) {
  return adapter.getOccasionComments(occasionId);
}

/**
 * هل عند هذا المستخدم تعليق سابق على هذه المناسبة؟ (منع التكرار)
 * @param {string} occasionId
 * @param {string} uid
 * @returns {Promise<Object|null>}
 */
export async function getUserOccasionComment(occasionId, uid) {
  return adapter.getUserOccasionComment(occasionId, uid);
}

/**
 * ضبط حالة إعجاب المستخدم بمناسبة (liked=true/false، وليس قلبًا) — الصفحات لا تنادي هذه مباشرة بل
 * عبر sendOccasionLike (shared/reaction-outbox.js) كي ينتظر الإعجاب في الطابور لو الشبكة/الخادم تعثّر.
 * @param {string} occasionId
 * @param {string} uid
 * @param {boolean} liked
 * @returns {Promise<{liked: boolean, likesCount: number}>}
 */
export async function setOccasionLike(occasionId, uid, liked) {
  return adapter.setOccasionLike(occasionId, uid, liked);
}

/**
 * هل أعجب هذا المستخدم بهذه المناسبة؟ (لتلوين الزر عند التحميل)
 * @param {string} occasionId
 * @param {string} uid
 * @returns {Promise<boolean>}
 */
export async function getUserOccasionLike(occasionId, uid) {
  const { getPendingReaction } = await import('../shared/reaction-outbox.js');
  const pending = getPendingReaction('occasion-like', occasionId, uid);
  if (pending !== undefined) return pending;
  return adapter.getUserOccasionLike(occasionId, uid);
}

/**
 * إعجاب/إلغاء إعجاب بتعليق على مناسبة (تبديل). commentId هو uid صاحب
 * التعليق (تعليق واحد لكل مستخدم لكل مناسبة).
 * @param {string} occasionId
 * @param {string} commentId
 * @param {string} uid
 * @returns {Promise<{liked: boolean, likesCount: number}>}
 */
export async function toggleOccasionCommentLike(occasionId, commentId, uid) {
  return adapter.toggleOccasionCommentLike(occasionId, commentId, uid);
}

/**
 * إضافة تعليق على مناسبة (يرمي خطأ لو المستخدم علّق من قبل)
 * @param {string} occasionId
 * @param {{ uid: string, authorName: string, text: string }} comment
 * @returns {Promise<Object>}
 */
export async function addOccasionComment(occasionId, comment) {
  enforceCooldown('add-occasion-comment', 2500);
  enforceMaxLength({
    text: { value: comment.text, max: OCCASION_COMMENT_MAX_LENGTH, label: 'التعليق' },
  });
  return adapter.addOccasionComment(occasionId, comment);
}

/**
 * حذف مناسبة (لوحة الإدارة)
 * @param {string} id
 * @returns {Promise<void>}
 */
export async function deleteOccasion(id) {
  return adapter.deleteOccasion(id);
}

/**
 * تعديل مناسبة (لوحة الإدارة — تصحيح بدل حذف)
 * @param {string} id
 * @param {{title?, ownerName?, category?, text?}} patch
 * @returns {Promise<Object>}
 */
export async function updateOccasion(id, patch) {
  return adapter.updateOccasion(id, patch);
}

/**
 * أرشفة/استعادة مناسبة يدوياً (لوحة الإدارة)
 * @param {string} id
 * @param {'archived'|'restored'} state
 */
export async function setOccasionArchiveState(id, state) {
  return adapter.setOccasionArchiveState(id, state);
}

// ══════════════════════════════════════════════════════════════
//  تعديل / حذف / إبلاغ المحتوى (مناسبات + أفكار + تعليقاتهما)
//  kind = 'idea' | 'occasion'. التعديل خلال ١٥ دقيقة من النشر؛
//  الحذف في أي وقت؛ ٣ بلاغات من مستخدمين مختلفين = يختفي المحتوى
//  لحد مراجعة المشرف (moderation: 'reported'). الأرقام والأسباب في
//  moderation-config.js، والقواعد الفعلية في سياسات RLS (supabase/migrations).
//  لتعليقات المناسبات: commentId = uid صاحب التعليق.
// ══════════════════════════════════════════════════════════════

const _POST_LIMITS = {
  idea: {
    title:          { max: 80,  label: 'عنوان الفكرة', minLetters: 4 },
    description:    { max: 400, label: 'وصف الفكرة',   minLetters: 15 },
    benefit:        { max: 300, label: 'الفائدة',      minLetters: 3 },
    proposedEntity: { max: 120, label: 'الجهة المقترحة' },
  },
  occasion: {
    title:     { max: 100, label: 'عنوان المناسبة',     minLetters: 4 },
    ownerName: { max: 60,  label: 'اسم صاحب المناسبة',  minLetters: 3 },
    text:      { max: 300, label: 'النص',               minLetters: 5 },
  },
};

function _commentMax(kind) {
  return kind === 'idea' ? 500 : OCCASION_COMMENT_MAX_LENGTH;
}

/**
 * تعديل صاحب المنشور لمنشوره (خلال ١٥ دقيقة من النشر).
 * @param {'idea'|'occasion'} kind
 * @param {string} id
 * @param {string} uid صاحب المنشور
 * @param {Object} patch الحقول المعدّلة (title/description/... حسب النوع)
 */
export async function editOwnPost(kind, id, uid, patch) {
  const limits = _POST_LIMITS[kind];
  if (!limits) throw new Error('نوع المحتوى ما معروف');
  const maxSpec = {}, readSpec = {};
  for (const [field, spec] of Object.entries(limits)) {
    if (patch[field] === undefined) continue;
    maxSpec[field] = { value: patch[field], max: spec.max, label: spec.label };
    if (spec.minLetters) readSpec[field] = { value: patch[field], label: spec.label, minLetters: spec.minLetters };
  }
  enforceMaxLength(maxSpec);
  enforceReadable(readSpec);
  return adapter.editOwnPost(kind, id, uid, patch);
}

/** حذف صاحب المنشور لمنشوره (في أي وقت — حذف ناعم، المشرف يقدر يراجعه). */
export async function deleteOwnPost(kind, id, uid) {
  return adapter.deleteOwnPost(kind, id, uid);
}

/**
 * إبلاغ عن منشور. بلاغ واحد لكل مستخدم، وعند الوصول لعتبة البلاغات يختفي
 * المنشور لحد مراجعة المشرف.
 * @returns {Promise<{ reportsCount: number, hidden: boolean }>}
 */
export async function reportPost(kind, id, uid, reason) {
  return adapter.reportPost(kind, id, uid, reason);
}

/** تعديل صاحب التعليق لتعليقه (خلال ١٥ دقيقة من النشر). */
export async function editOwnComment(kind, parentId, commentId, uid, text) {
  enforceMaxLength({ text: { value: text, max: _commentMax(kind), label: 'التعليق' } });
  return adapter.editOwnComment(kind, parentId, commentId, uid, text);
}

/** حذف صاحب التعليق لتعليقه (في أي وقت). */
export async function deleteOwnComment(kind, parentId, commentId, uid) {
  return adapter.deleteOwnComment(kind, parentId, commentId, uid);
}

/** إبلاغ عن تعليق (نفس منطق reportPost). */
export async function reportComment(kind, parentId, commentId, uid, reason) {
  return adapter.reportComment(kind, parentId, commentId, uid, reason);
}

/** استعادة المشرف لتعليق اتخفى بالبلاغات. */
export async function restoreComment(kind, parentId, commentId) {
  return adapter.restoreComment(kind, parentId, commentId);
}

/** موافقة المشرف على فكرة/مناسبة قيد المراجعة (لوحة الإدارة). */
export async function approveIdea(id) {
  return adapter.approveIdea(id);
}
export async function approveOccasion(id) {
  return adapter.approveOccasion(id);
}

// ══════════════════════════════════════════════════════════════
//  الرسائل الواردة (مساهمات وبلاغات أخطاء)
// ══════════════════════════════════════════════════════════════

/**
 * جلب الرسائل الواردة (لوحة الإدارة)
 * @param {{ type?: 'contribution'|'error_report', status?: 'new'|'reviewed' }} options
 * @returns {Promise<Array>}
 */
export async function getInboxMessages(options = {}) {
  return adapter.getInboxMessages(options);
}

/**
 * تسجيل رسالة واردة جديدة — تُستدعى من settings-contact.js بالتوازي
 * مع فتح واتساب/إيميل (best-effort، ما توقفش تلك القناة لو فشلت).
 * @param {{ type: 'contribution'|'error_report', body: string, authorName?: string }} data
 * @returns {Promise<Object>}
 */
export async function addInboxMessage(data) {
  enforceCooldown('add-inbox-message', 5000);
  enforceMaxLength({
    body: { value: data.body, max: 1000, label: 'الرسالة' },
  });
  return adapter.addInboxMessage(data);
}

/**
 * تعليم رسالة واردة كمُراجَعة (لوحة الإدارة)
 * @param {string} id
 * @returns {Promise<void>}
 */
export async function markInboxMessageReviewed(id) {
  return adapter.markInboxMessageReviewed(id);
}

/**
 * حذف رسالة واردة نهائياً (لوحة الإدارة)
 * @param {string} id
 * @returns {Promise<void>}
 */
export async function deleteInboxMessage(id) {
  return adapter.deleteInboxMessage(id);
}

/**
 * عدد الرسائل الواردة الجديدة — لشارة التنبيه على بطاقة "الرسائل
 * الواردة" في لوحة الإدارة.
 * @returns {Promise<number>}
 */
export async function getUnreadInboxCount() {
  return adapter.getUnreadInboxCount();
}

/** عدّادات أفكار/مناسبات بانتظار المراجعة (لوحة الإدارة) — استعلام خفيف بدل جلب القوائم كاملة. */
export async function getReviewQueueCounts() {
  return adapter.getReviewQueueCounts();
}

// ══════════════════════════════════════════════════════════════
//  نداء إنساني عاجل (متبرع بالدم / حالة مرضية مستعجلة)
// ══════════════════════════════════════════════════════════════

/**
 * النداء العاجل الحالي — للعرض العام (الرئيسية/الأخبار/بيت المناسبات).
 * @returns {Promise<Object|null>}
 */
export async function getActiveUrgentAnnouncement() {
  return adapter.getActiveUrgentAnnouncement();
}

/**
 * حالة آخر نداء اتنشر (حتى لو منتهي/متوقف) — لوحة الإدارة فقط.
 * @returns {Promise<Object|null>}
 */
export async function getUrgentAnnouncementStatus() {
  return adapter.getUrgentAnnouncementStatus();
}

/**
 * نشر نداء إنساني عاجل جديد — لوحة الإدارة فقط.
 * @param {{ type: 'blood_donor'|'medical_donation', title: string, body: string, contactPhone?: string, durationHours: number, sourceMessageId?: string }} data
 * @returns {Promise<Object>}
 */
export async function publishUrgentAnnouncement(data) {
  return adapter.publishUrgentAnnouncement(data);
}

/**
 * إيقاف النداء الحالي قبل انتهاء وقته — لوحة الإدارة فقط.
 * @returns {Promise<void>}
 */
export async function unpublishUrgentAnnouncement() {
  return adapter.unpublishUrgentAnnouncement();
}


// ══════════════════════════════════════════════════════════════
//  جهات استلام "ساهم في التوثيق" و"الإبلاغ عن خطأ"
// ══════════════════════════════════════════════════════════════

/**
 * رقم واتساب المساهمات + بريد البلاغات الحاليين (القيم الافتراضية لو ما اتغيّرت).
 * @returns {Promise<{ contributionWhatsapp: string, reportEmail: string }>}
 */
export async function getContactRecipients() {
  return adapter.getContactRecipients();
}

/**
 * تغيير المستلمين (لوحة الإدارة).
 * @param {{ contributionWhatsapp: string, reportEmail: string }} data
 * @returns {Promise<{ contributionWhatsapp: string, reportEmail: string }>}
 */
export async function setContactRecipients(data) {
  return adapter.setContactRecipients(data);
}

/**
 * إحصائيات الأرشيف لكل نوع محتوى (المجموع + المؤرشف تلقائياً) — لوحة الإدارة
 * @returns {Promise<Array<{key:string,label:string,retentionDays:number,total:number,archived:number}>>}
 */
export async function getArchiveStats() {
  return adapter.getArchiveStats();
}

/**
 * حذف نهائي لكل المحتوى المؤرشف عبر الأنواع الأربعة (لوحة الإدارة)
 * @returns {Promise<{news:number,notifications:number,ideas:number,comments:number}>}
 */
/**
 * تنظيف الأرشيف نهائياً — كل الأنواع مرة واحدة، أو نوع واحد بس لو اتحدد.
 * @param {'news'|'notifications'|'ideas'|'comments'|'occasions'|'inbox'} [type]
 */
export async function purgeArchivedContent(type) {
  return adapter.purgeArchivedContent(type);
}


// ══════════════════════════════════════════════════════════════
//  رقابة الأعضاء
// ══════════════════════════════════════════════════════════════

/**
 * جلب قائمة الأعضاء المكتشَفين من المحتوى (أفكار/مناسبات/تعليقاتهم)،
 * مع حالة الرقابة الحالية — لوحة الإدارة فقط.
 * @returns {Promise<Array<{uid, displayName, status, reason, lastActiveAt, contributionsCount}>>}
 */
export async function getMembers() {
  return adapter.getMembers();
}

/**
 * حالة رقابة عضو واحد — تُستخدم في حارس الحظر الكامل عند كل تنقّل.
 * @param {string} uid
 * @returns {Promise<{status:'active'|'banned-full'|'banned-partial', reason:string}>}
 */
export async function getMemberModeration(uid) {
  return adapter.getMemberModeration(uid);
}

/**
 * ضبط حالة رقابة عضو (حظر كامل/جزئي، أو رفع الحظر) — لوحة الإدارة فقط.
 * @param {string} uid
 * @param {{ status: 'active'|'banned-full'|'banned-partial', reason?: string, displayName?: string }} data
 */
export async function setMemberModeration(uid, data) {
  return adapter.setMemberModeration(uid, data);
}


// ══════════════════════════════════════════════════════════════
//  أدوات عرض مشتركة
//  (بتُستخدم من صفحات متعددة — بتمر من هنا عشان الصفحات ما
//  تستوردش من الـadapter مباشرة، وتحافظ على تسلسل
//  UI → Pages → db.js → adapter)
// ══════════════════════════════════════════════════════════════

/**
 * يحوّل تاريخ ISO لنص نسبي ("قبل ٥ دقايق"، "أمس"...)
 * @param {string} iso
 * @returns {string}
 */
/**
 * تسجيل إجراء إداري (سجل النشاط — admin-activity-log.js). فشل التسجيل
 * لا يوقف الإجراء نفسه أبداً — الاستدعاء الفعلي من js/shared/admin-activity.js
 * اللي بيغلّفه بـtry/catch، مش من هنا.
 * @param {{ actorName: string, actorRole: string, action: string, summary?: string }} entry
 */
export async function logAdminAction(entry) {
  return adapter.logAdminAction(entry);
}

/**
 * سجل النشاط الإداري — الأحدث أولاً.
 * @param {{ limit?: number }} [options]
 */
export async function getActivityLog(options = {}) {
  return adapter.getActivityLog(options);
}

// ══════════════════════════════════════════════════════════════
//  نسخ احتياطي واستيراد — لوحة الإدارة (النظام). التفاصيل في
//  local-adapter.js. على Supabase مش مدعومة (النسخ الاحتياطي من لوحة Supabase).
// ══════════════════════════════════════════════════════════════

/** لقطة كاملة من بيانات التطبيق (جاهزة لـ JSON.stringify). */
export async function exportAllData() {
  return adapter.exportAllData();
}

/** عدد العناصر في كل قسم، من لقطة معيّنة أو من الحالة الحالية. */
export async function getBackupSummary(snapshot) {
  return adapter.getBackupSummary(snapshot);
}

/** معاينة ما سيفعله استيراد ملف نسخة: لكل جدول كم صفًا في الملف وكم جديد وكم موجود أصلًا (لا يكتب شيئًا). */
export async function previewBackupImport(snapshot) {
  return adapter.previewBackupImport(snapshot);
}

/** يستورد ملف نسخة احتياطية: يضيف الجديد (أو يدمج الموجود بحسب opts.mode) ولا يحذف شيئًا. يرجع تقريرًا لكل جدول. */
export async function importAllData(snapshot, opts) {
  return adapter.importAllData(snapshot, opts);
}

export function formatRelativeTime(iso) {
  // دالة نقية مشتركة — محوّل Firebase ما بيصدّرها، فنستدعيها من مصدرها مباشرة
  return _formatRelativeTime(iso);
}
