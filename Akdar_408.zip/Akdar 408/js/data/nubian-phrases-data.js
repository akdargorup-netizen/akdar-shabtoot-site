// js/data/nubian-phrases-data.js — شبتوت بحري
// ═══════════════════════════════════════════════════════════════════
// بذرة بيانات قسم "تعلم الكلام" (جمل وعبارات آنداندي) — فرع من
// آنداندي، شقيق لقاموس الكلمات لكن مختلف عنه في نقطة أساسية:
//
// ⚠️ الفرق عن NUBIAN_LANGUAGE_CATEGORIES (نبذة الكلمات): هناك
// التصنيفات السبعة عشر ثابتة ولا تتغيّر من لوحة الإدارة، وهنا العكس —
// التصنيفات نفسها (مش بس الجمل جواها) قابلة للإضافة/التعديل/الحذف من
// لوحة الإدارة. فـ NUBIAN_PHRASE_CATEGORIES_SEED هنا مجرد نقطة بداية
// (seed) تتحوّل لنسخة حيّة قابلة للتعديل في local-adapter.js، بالظبط
// زي ما بيصير مع الكلمات نفسها.
//
// كل تصنيف: { key, title, icon }
// كل جملة: { ar, nub, translit, note } — نفس شكل الكلمة بالظبط، بس
// بتتخزّن في مصفوفة منفصلة (_nubianPhrases) مرتبطة بالتصنيف عبر
// حقل category.
// ═══════════════════════════════════════════════════════════════════

export const NUBIAN_PHRASE_CATEGORIES_SEED = [
  { key: 'greetings-phrases',    title: 'تحية ومجاملات',   icon: 'hand-helping' },
  { key: 'home-phrases',         title: 'في البيت',        icon: 'home' },
  { key: 'market-phrases',       title: 'في السوق',        icon: 'shopping-basket' },
  { key: 'hospitality-phrases',  title: 'زيارة وضيافة',    icon: 'users' },
  { key: 'questions-phrases',    title: 'سؤال وطلب',       icon: 'message-circle-question' },
  { key: 'general-phrases',      title: 'عبارات عامة',     icon: 'message-square' },
];

// لسع ما فيه محتوى — هيتضاف لاحقًا من لوحة الإدارة أو عبر تحديث
// هذا الملف زي ما بيصير مع باقي الأقسام
export const NUBIAN_PHRASES_SEED = [];
