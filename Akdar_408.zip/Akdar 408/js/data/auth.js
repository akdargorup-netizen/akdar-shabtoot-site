// js/data/auth.js — شبتوت بحري
// ══════════════════════════════════════════════════════════════
//  طبقة المصادقة — Supabase Auth.
//
//  الزائر القارئ بلا جلسة (لا يُحسب في MAU). تُنشأ جلسة anonymous عند أول كتابة
//  فعلية (ensureSession)، وممكن يرقّيها لحساب Google وقت ما يحتاج (تصويت، فكرة، مناسبة، تعليق...)
//  عبر requireRealAuth() → signInWithGoogle().
//
//  طريقة دخول جوجل: نافذة Google المنبثقة تفتحها Firebase (شغّالة ومجرَّبة
//  عندكم) وتعطينا Google ID token فقط، ثم نسلّمه لـSupabase بـsignInWithIdToken
//  فتُنشأ جلسة Supabase حقيقية. Firebase هنا وسيط للهوية ولا يحتفظ بجلسة
//  (نسجّل خروجه فورًا). لا حاجة لـClient Secret ولا Google Cloud Console.
//  الفرق: الجلسة المجهولة تُستبدل بجلسة الحساب الحقيقي (uid جديد) —
//  المجهول لا يملك أي محتوى أصلاً (النشر والتصويت يتطلبان حسابًا حقيقيًا).
//
//  الواجهة المُصدَّرة (uid, isAnonymous, displayName, photoURL, claims
//  + الدوال) هي نفسها القديمة تمامًا — باقي الملفات ما احتاجت تعديل.
//
//  الصلاحيات (claims) صارت من جدول user_roles في قاعدة البيانات بدل
//  توكن Firebase: { owner, admin, nubian } وتتحدّث فورًا بلا خروج/دخول.
// ══════════════════════════════════════════════════════════════

import { RUNTIME_CONFIG } from './runtime-config.js';
import { getSupabase } from './supabase-client.js';

const REAL_AUTH_KEY = 'auth_local_real_profile'; // اسم العرض المخصص (منفصل عن اسم حساب جوجل)
const SNAPSHOT_KEY = 'sbb:last-user';           // آخر هوية معروفة — تظهر فورًا بلا انتظار الشبكة
const CLAIMS_KEY = 'sbb:claims:';               // آخر صلاحيات معروفة لكل مستخدم (للعرض فقط؛ الحماية الفعلية في RLS)
const DISPLAY_NAME_MAX_LENGTH = 40;              // يظهر بلا حدود في كل مكان (تعليقات، مناسبات، أفكار)

/** @typedef {{ uid: string, isAnonymous: boolean, displayName: string|null, photoURL: string|null, claims: Object }} AppUser */

/** @type {AppUser|null} */
let _currentUser = null;

/** @type {import('@supabase/supabase-js').SupabaseClient|null} */
let _sb = null;

/** @type {import('@supabase/supabase-js').Session|null} */
let _session = null;

/** @type {Set<(user: AppUser|null) => void>} */
const _listeners = new Set();

function _notify() {
  _listeners.forEach(cb => cb(_currentUser));
}

// ── ينتظر أول حالة مصادقة فعلية تتحدد (يُستخدم من push.js وadmin-auth.js) ──
let _resolveAuthReady;
const _authReadyPromise = new Promise((resolve) => { _resolveAuthReady = resolve; });

function _getSavedRealProfile() {
  try {
    const raw = localStorage.getItem(REAL_AUTH_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

function _saveDisplayName(uid, name) {
  try {
    localStorage.setItem(REAL_AUTH_KEY, JSON.stringify({ uid, displayName: name }));
  } catch { /* تجاهل لو التخزين ممتلئ/معطّل */ }
}

function _loadSavedDisplayName(uid) {
  const saved = _getSavedRealProfile();
  return (saved && saved.uid === uid) ? saved.displayName : null;
}

/** وضع التشخيص: يتفعّل لو الرابط فيه debug=1 (في الـquery أو بعد الـhash). */
function _isDebugMode() {
  try {
    const inSearch = new URLSearchParams(location.search).get('debug') === '1';
    const inHash = /[?&]debug=1(?:&|$)/.test(location.hash || '');
    return inSearch || inHash;
  } catch {
    return false;
  }
}

function _saveSnapshot(user) {
  try {
    if (user) localStorage.setItem(SNAPSHOT_KEY, JSON.stringify(user));
    else localStorage.removeItem(SNAPSHOT_KEY);
  } catch { /* تجاهل */ }
}

function _loadSnapshot() {
  try {
    const s = JSON.parse(localStorage.getItem(SNAPSHOT_KEY) || 'null');
    return s && typeof s.uid === 'string' ? s : null;
  } catch {
    return null;
  }
}

function _cachedClaims(uid) {
  try { return JSON.parse(localStorage.getItem(CLAIMS_KEY + uid) || '{}') || {}; } catch { return {}; }
}

function _saveClaims(uid, claims) {
  try { localStorage.setItem(CLAIMS_KEY + uid, JSON.stringify(claims || {})); } catch { /* تجاهل */ }
}

async function _toast(msg, kind, ms) {
  const { showToast } = await import('../shared/toast.js').catch(() => ({}));
  showToast?.(msg, kind, ms);
}


// ══════════════════════════════════════════════════════════════
//  الصلاحيات من جدول user_roles (بديل custom claims)
// ══════════════════════════════════════════════════════════════

async function _loadClaims(user) {
  if (!user || user.is_anonymous || !_sb) return {};
  try {
    const { data, error } = await _sb
      .from('user_roles')
      .select('is_owner, is_admin, is_nubian')
      .eq('user_id', user.id)
      .maybeSingle();
    if (error) return null;               // فشل الاتصال/الاستعلام: لا نعرف — نُبقي آخر صلاحيات معروفة
    if (!data) return {};                 // لا صف = لا صلاحيات
    return {
      owner: data.is_owner === true,
      admin: data.is_admin === true || data.is_owner === true, // المالك يملك كل صلاحيات المشرف
      nubian: data.is_nubian === true,
    };
  } catch {
    return null;
  }
}


// ══════════════════════════════════════════════════════════════
//  تطبيق الجلسة على حالة التطبيق
// ══════════════════════════════════════════════════════════════

let _applySeq = 0;
let _namePromise = null; // نافذة الاسم المفتوحة حاليًا (تمنع فتحها مرتين)

async function _applySession(session, { awaitClaims = false, event = '' } = {}) {
  const seq = ++_applySeq;
  _session = session || null;
  const u = session?.user;

  if (!u) {
    // أوفلاين وفشل تجديد الجلسة ليس "خروجًا" — نُبقي آخر هوية معروفة بدل ما نمسحها
    if (event !== 'SIGNED_OUT' && typeof navigator !== 'undefined' && navigator.onLine === false) return;
    _currentUser = null;
    _saveSnapshot(null);
    _notify();
    return;
  }

  const meta = u.user_metadata || {};
  const anon = !!u.is_anonymous;

  // الصلاحيات: من آخر نسخة محفوظة فورًا، والتحقق الفعلي بالخلفية (إلا عند الدخول الجديد نستناها)
  let claims = anon ? {} : _cachedClaims(u.id);
  if (!anon && awaitClaims) {
    const fresh = await _loadClaims(u);
    if (seq !== _applySeq) return; // وصلت جلسة أحدث أثناء الانتظار
    if (fresh) { claims = fresh; _saveClaims(u.id, fresh); }
  }

  const savedName = _loadSavedDisplayName(u.id);
  _currentUser = {
    uid: u.id,
    isAnonymous: anon,
    displayName: savedName || meta.full_name || meta.name || null,
    photoURL: meta.avatar_url || meta.picture || null,
    claims,
  };
  _saveSnapshot(_currentUser);

  _notify();
  _resolveAuthReady();

  if (!anon && !awaitClaims) {
    _loadClaims(u).then((fresh) => {
      if (!fresh || seq !== _applySeq || !_currentUser || _currentUser.uid !== u.id) return;
      _saveClaims(u.id, fresh);
      if (JSON.stringify(fresh) !== JSON.stringify(_currentUser.claims)) {
        _currentUser = { ..._currentUser, claims: fresh };
        _saveSnapshot(_currentUser);
        _notify();
      }
    });
  }

  // راجع من جوجل ولسه ما اختار اسم ظاهر → نافذة الاسم الإجبارية
  if (!anon && !savedName) _ensureDisplayName(meta);
}

/** نافذة الاسم الإجبارية (بدون تجاوز) — مرة واحدة بعد أول دخول بجوجل. */
function _ensureDisplayName(meta) {
  if (_namePromise) return _namePromise;
  _namePromise = (async () => {
    try {
      const { promptRequiredName } = await import('../shared/name-required-modal.js');
      const name = await promptRequiredName(meta.full_name || meta.name || '', DISPLAY_NAME_MAX_LENGTH);
      if (!_currentUser || _currentUser.isAnonymous) return;

      _saveDisplayName(_currentUser.uid, name);
      _currentUser = { ..._currentUser, displayName: name };
      _notify();
      _toast(`تم تسجيل الدخول باسم ${name}`, 'success', 3000);
    } catch (err) {
      console.error('[Auth] فشل طلب الاسم الظاهر:', err);
    }
  })().finally(() => { _namePromise = null; });
  return _namePromise;
}


// ══════════════════════════════════════════════════════════════
//  التهيئة — تُستدعى مرة واحدة من app.js عند الإقلاع
// ══════════════════════════════════════════════════════════════

/**
 * يبدأ جلسة Supabase Auth حقيقية (anonymous أول مرة، أو الجلسة المحفوظة
 * — anonymous أو Google).
 * @returns {Promise<AppUser|null>}
 */
export async function initAuth() {
  if (RUNTIME_CONFIG.useLocalDemoUser) {
    _currentUser = {
      uid: 'local-dev-user',
      isAnonymous: false,
      displayName: 'مستخدم تجريبي',
      photoURL: null,
      claims: {},
    };
    _notify();
    _resolveAuthReady();
    return _currentUser;
  }

  // هوية فورية من آخر مرة (بلا انتظار تحميل المكتبة أو الشبكة) — تتصحّح لاحقًا بالجلسة الحقيقية
  const snapshot = _loadSnapshot();
  if (snapshot && !_currentUser) {
    _currentUser = snapshot;
    _notify();
  }

  try {
    _sb = await getSupabase();
  } catch (err) {
    console.error('[Auth] تعذّر تحميل مكتبة Supabase (الشبكة؟):', err);
    _resolveAuthReady(); // ما نعلّقش أي حد مستني الجلسة للأبد
    return null;
  }

  // ⚠️ لا نستدعي أي دالة Supabase مباشرة داخل هذا الـcallback (قفل داخلي
  // يسبب تعليقًا) — نؤجّلها بـsetTimeout.
  _sb.auth.onAuthStateChange((event, session) => {
    setTimeout(() => { _applySession(session, { event }); }, 0);
  });

  // getSession ينتظر اكتمال التهيئة (قراءة الجلسة المحفوظة)
  let session = null;
  try {
    ({ data: { session } } = await _sb.auth.getSession());
  } catch { /* نكمل بالجلسة المجهولة */ }

  // الجلسة المحفوظة جاهزة محليًا — نطبّقها فورًا بدل انتظار حدث INITIAL_SESSION (التكرار آمن)
  if (session) await _applySession(session);

  // (v524) لا ننشئ جلسة مجهولة عند الإقلاع: الزائر القارئ فقط ما يحتاج جلسة (القراءة العامة بالمفتاح العام)،
  // وكل مستخدم مجهول يُحسب في حصة MAU. الجلسة المجهولة تُنشأ عند أول كتابة فعلية (ensureSession).
  if (!session && !_session) {
    // لا جلسة فعلية: لا نُبقي هوية قديمة من اللقطة المحفوظة (إلا لو أوفلاين — الفشل هناك ليس خروجًا)
    if (_currentUser && !(typeof navigator !== 'undefined' && navigator.onLine === false)) {
      _currentUser = null;
      _saveSnapshot(null);
      _notify();
    }
    _resolveAuthReady();
  }

  return _currentUser;
}

// (v524) جلسة مجهولة عند الحاجة فقط — تُستدعى قبل أي كتابة (رسالة، اشتراك إشعارات...).
// مَن يقرأ فقط لا تُنشأ له جلسة أصلاً فلا يُحسب في MAU. محاولة واحدة مشتركة + إعادة محاولة
// قصيرة متباعدة (حدّ الطلبات لكل IP قد يضرب شبكات الاتصالات التي تشارك IP واحدًا).
let _ensurePromise = null;
const _ENSURE_RETRY_MS = [1500, 4000];

/**
 * يضمن وجود جلسة (حقيقية أو مجهولة) قبل الكتابة.
 * @returns {Promise<boolean>} true لو توجد جلسة
 */
export function ensureSession() {
  if (_session || RUNTIME_CONFIG.useLocalDemoUser) return Promise.resolve(true);
  if (_ensurePromise) return _ensurePromise;
  _ensurePromise = (async () => {
    try {
      if (!_sb) _sb = await getSupabase();
      for (let i = 0; i <= _ENSURE_RETRY_MS.length; i++) {
        if (_session) return true;
        if (typeof navigator !== 'undefined' && navigator.onLine === false) return false;
        try {
          const { data: { session: existing } } = await _sb.auth.getSession();
          if (existing) { await _applySession(existing); return true; }
          const { data, error } = await _sb.auth.signInAnonymously();
          if (error) throw error;
          if (data?.session) await _applySession(data.session);
          return true;
        } catch (err) {
          if (i === _ENSURE_RETRY_MS.length) {
            console.error('[Auth] فشل إنشاء الجلسة المجهولة (راجع تفعيل Allow anonymous sign-ins):', err);
            return false;
          }
          await new Promise((r) => setTimeout(r, _ENSURE_RETRY_MS[i] * (0.7 + Math.random() * 0.6)));
        }
      }
      return false;
    } catch (err) {
      console.error('[Auth] تعذّر تهيئة الجلسة:', err);
      return false;
    } finally {
      _ensurePromise = null;
    }
  })();
  return _ensurePromise;
}

/**
 * ينتظر لحد ما أول حالة مصادقة حقيقية تتحدد (نجحت أو فشلت). يُستخدم
 * من أي كود محتاج يتأكد إن فيه محاولة تسجيل دخول حصلت قبل ما يكتب.
 * @returns {Promise<void>}
 */
export function waitForAuthReady() {
  return _authReadyPromise;
}


// ══════════════════════════════════════════════════════════════
//  تسجيل الدخول / الخروج
// ══════════════════════════════════════════════════════════════

// تحميل مسبق لمكتبات نافذة جوجل (Firebase) — يُستدعى عند ظهور أي زر/نافذة دخول،
// ليكون signInWithPopup أول ما يحدث عند الضغطة (شرط iOS Safari لعدم حجب النافذة).
let _fbReady = null;
let _fbPromise = null;
export function preloadGoogleSignIn() {
  if (_fbReady) return Promise.resolve(_fbReady);
  if (_fbPromise) return _fbPromise;
  _fbPromise = Promise.all([
    import('./firebase-init.js'),
    import('https://www.gstatic.com/firebasejs/10.13.0/firebase-auth.js'),
  ]).then(([{ app }, fb]) => (_fbReady = { app, fb }))
    .catch((err) => { _fbPromise = null; throw err; });
  _fbPromise.catch(() => {}); // فشل التحميل المسبق لا يهم هنا؛ المحاولة الفعلية ستعيد التحميل
  return _fbPromise;
}

/**
 * ترقية الجلسة لحساب Google حقيقي: نافذة جوجل المنبثقة (عبر Firebase) ←
 * Google ID token ← signInWithIdToken في Supabase. المستخدم بعدها يختار اسمه
 * الظاهر (نافذة إجبارية) قبل ما الدالة ترجع.
 * @returns {Promise<AppUser|null>} null لو ألغى المستخدم أو فشل الدخول
 */
export async function signInWithGoogle() {
  let fbAuth = null;
  try {
    // ⚠️ iOS Safari: النافذة المنبثقة لازم تُفتح مباشرة من ضغطة المستخدم. فلا نضع أي await
    // قبل signInWithPopup حين تكون المكتبات محمّلة مسبقًا (preloadGoogleSignIn) وSupabase جاهزًا.
    if (!_sb) _sb = await getSupabase();
    const { app, fb } = _fbReady || await preloadGoogleSignIn();
    const { getAuth, GoogleAuthProvider, signInWithPopup, signOut: fbSignOut } = fb;
    fbAuth = getAuth(app);

    const provider = new GoogleAuthProvider();
    provider.setCustomParameters({ prompt: 'select_account' }); // دايمًا يعرض اختيار الحساب
    const result = await signInWithPopup(fbAuth, provider);
    const idToken = GoogleAuthProvider.credentialFromResult(result)?.idToken;

    // Firebase وسيط فقط — نفصله فورًا حتى لا تبقى جلسة ثانية في الجهاز
    try { await fbSignOut(fbAuth); } catch { /* تجاهل */ }

    if (!idToken) throw new Error('no_google_id_token');

    const { data, error } = await _sb.auth.signInWithIdToken({ provider: 'google', token: idToken });
    if (error) throw error;

    await _applySession(data.session, { awaitClaims: true }); // يحدّث _currentUser (بصلاحياته الحقيقية) ويفتح نافذة الاسم عند الحاجة
    if (_namePromise) await _namePromise;       // ننتظر اختيار الاسم قبل الرجوع للمستدعي
    return _currentUser;
  } catch (err) {
    // المستخدم قفل نافذة جوجل مش خطأ حقيقي — ما نعرض رسالة
    if (err?.code === 'auth/popup-closed-by-user' || err?.code === 'auth/cancelled-popup-request') {
      return null;
    }
    console.error('[Auth] فشل تسجيل الدخول بجوجل:', err);
    const debugSuffix = _isDebugMode() ? ` [${err?.code || err?.message || 'بدون-كود'}]` : '';
    _toast(`الدخول بحساب جوجل ما اكتمل — جرّب تاني.${debugSuffix}`, 'error', 6000);
    return null;
  }
}

/**
 * تعديل الاسم الظاهر لمستخدم مسجّل دخول بالفعل — من غير إعادة ربط
 * حساب جوجل. يُستخدم من صفحة الإعدادات (زر "تعديل الاسم").
 * @param {string} newName
 * @returns {Promise<boolean>} نجح التعديل أو لا
 */
export async function updateDisplayName(newName) {
  const trimmed = (newName || '').trim().slice(0, DISPLAY_NAME_MAX_LENGTH);
  if (!trimmed || !_currentUser || _currentUser.isAnonymous) return false;

  _currentUser = { ..._currentUser, displayName: trimmed };
  _saveDisplayName(_currentUser.uid, trimmed);
  _notify();
  return true;
}

/**
 * تسجيل الخروج — يرجّع الجلسة لـanonymous جديدة تلقائيًا (uid مختلف
 * عن الحساب اللي خرج منه، زي أي تسجيل خروج حقيقي).
 */
export async function signOut() {
  if (RUNTIME_CONFIG.useLocalDemoUser) {
    _currentUser = {
      uid: 'local-dev-user',
      isAnonymous: false,
      displayName: 'مستخدم تجريبي',
      photoURL: null,
      claims: {},
    };
    _notify();
    return _currentUser;
  }

  try { localStorage.removeItem(REAL_AUTH_KEY); } catch { /* تجاهل */ }

  try {
    if (!_sb) _sb = await getSupabase();
    await _sb.auth.signOut({ scope: 'local' }); // جهاز واحد فقط؛ onAuthStateChange يحدّث _currentUser تلقائيًا
    // (v524) لا نفتح جلسة مجهولة بعد الخروج — تُنشأ عند أول كتابة (ensureSession)
  } catch (err) {
    console.error('[Auth] فشل تسجيل الخروج:', err);
  }
}


// ══════════════════════════════════════════════════════════════
//  قراءة الحالة
// ══════════════════════════════════════════════════════════════

/**
 * يتحقق أن المستخدم مسجّل بحساب حقيقي (Google) لا anonymous —
 * شرط ضروري لأي فعل يعتمد على "شخص واحد = صوت واحد" (مثل التصويت).
 * إن لم يكن مسجّلاً: يفتح نافذة "هل تريد تسجيل الدخول؟" وينتظر قرار
 * المستخدم فعليًا.
 * @returns {Promise<boolean>}
 */
export async function requireRealAuth() {
  if (!(_currentUser && !_currentUser.isAnonymous)) {
    const { openLoginPrompt } = await import('../shared/login-prompt-modal.js').catch(() => ({}));
    if (!openLoginPrompt) return false; // fallback دفاعي لو الاستيراد فشل لأي سبب
    const signedIn = await openLoginPrompt();
    if (!signedIn) return false;
  }

  // حظر جزئي/كامل: يعرف قبل ما يوصل لأي حقل (يفشل بأمان: لو تعذّر الفحص نكمل والسيرفر يرفض)
  try {
    const { requireNotBanned } = await import('../shared/member-ban-gate.js');
    return await requireNotBanned();
  } catch {
    return true;
  }
}

/**
 * Access token (JWT) للمستخدم الحقيقي الحالي (غير المجهول) — يُستخدم كإثبات
 * هوية عند استدعاء دالة الإرسال. null لو مفيش حساب حقيقي مسجّل دخول.
 * getSession يجدّد التوكن تلقائيًا لو قرب ينتهي.
 * @returns {Promise<string|null>}
 */
export async function getIdToken() {
  try {
    if (!_sb) return null;
    const { data: { session } } = await _sb.auth.getSession();
    if (!session || session.user?.is_anonymous) return null;
    return session.access_token || null;
  } catch {
    return null;
  }
}

/**
 * هل المستخدم الحالي إداري؟ (جدول user_roles: is_admin أو is_owner —
 * يُمنح فقط من SQL Editor، راجع آخر schema.sql)
 * @returns {boolean}
 */
export function isAdmin() {
  return _currentUser?.claims?.admin === true;
}

/** المطوّر/المالك (is_owner) — هو الوحيد اللي دالة send-notification بتقبل توكنه */
export function isOwner() {
  return _currentUser?.claims?.owner === true;
}

/**
 * يعيد قراءة الصلاحيات من قاعدة البيانات — عشان صلاحية اتمنحت لتوّها
 * توصل بدون خروج/دخول. لو فشل (نت مقطوع) بيرجّع الحالة زي ما هي.
 * @returns {Promise<AppUser|null>}
 */
export async function refreshClaims() {
  const u = _session?.user;
  if (!u || !_currentUser) return _currentUser;
  try {
    const claims = await _loadClaims(u);
    if (claims) {
      _saveClaims(u.id, claims);
      _currentUser = { ..._currentUser, claims };
      _saveSnapshot(_currentUser);
      _notify();
    }
  } catch (err) {
    console.warn('[Auth] تعذّر تحديث الصلاحيات:', err);
  }
  return _currentUser;
}

/** @returns {AppUser|null} الحالة الحالية فوراً (بدون انتظار) */
export function getCurrentUser() {
  return _currentUser;
}

/**
 * اشتراك تفاعلي بحالة تسجيل الدخول.
 * يستدعي callback فوراً بالحالة الحالية، ثم عند أي تغيير.
 * @param {(user: AppUser|null) => void} callback
 * @returns {() => void} دالة لإلغاء الاشتراك
 */
export function onAuthChange(callback) {
  _listeners.add(callback);
  callback(_currentUser);
  return () => _listeners.delete(callback);
}
