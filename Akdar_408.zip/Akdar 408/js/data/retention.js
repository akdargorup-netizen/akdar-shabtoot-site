// js/data/retention.js — شبتوت بحري
// ══════════════════════════════════════════════════════════════
//  إعدادات الاحتفاظ بالمحتوى — مصدر الحقيقة الوحيد لعمر كل نوع
//  محتوى قبل ما يتأرشف تلقائياً من الخلاصة، وكام عنصر أقصى ترجعه
//  كل قائمة بشكل افتراضي. تُستخدم في local-adapter.js الآن،
//  ولاحقاً بنفس الأرقام بالظبط كـ limit()/where() في استعلامات
//  Firestore — عشان سلوك التطبيق ما يتغيّرش وقت الانتقال.
//
//  "أرشفة" هنا معناها: العنصر بيختفي من الخلاصة الافتراضية تلقائياً
//  (زي منطق تعتيم المقروء بعد ٩٠ يوم أصلاً)، بس يفضل موجود لحد ما
//  حد يشغّل "تنظيف الأرشيف" من لوحة الإدارة فيتحذف نهائياً.
// ══════════════════════════════════════════════════════════════

export const RETENTION_DAYS = {
  news:          45,
  notifications: 45,
  ideas:         45,
  comments:      45,
  occasions:     60, // مناسباتنا — أطول شوية من الأفكار، لأن التعازي والتبريكات بيرجع لها الناس بعد وقت
  inbox:         90, // رسائل واردة (مساهمات وبلاغات) — تفضل متاحة للمراجعة لفترة أطول
};

export const FEED_LIMIT = {
  news:          50,
  notifications: 50,
  ideas:         50,
  comments:      200, // لكل فكرة على حدة — نادراً توصل، بس حماية
  occasions:     50,
  inbox:         200,
};

export const RETENTION_LABELS = {
  news:          'الأخبار',
  notifications: 'الرسائل',
  ideas:         'الأفكار',
  comments:      'التعليقات',
  occasions:     'المناسبات',
  inbox:         'الرسائل الواردة',
};

/** هل التاريخ (ISO) تجاوز مدة الاحتفاظ لنوعه؟ */
export function isArchived(isoDate, type) {
  if (!isoDate) return false;
  // يقبل كمان Timestamp من Firestore (toDate) كشبكة أمان — المحوّل بيحوّله
  // لنص ISO أصلاً عند القراءة
  const date = typeof isoDate.toDate === 'function' ? isoDate.toDate() : new Date(isoDate);
  const days = (Date.now() - date.getTime()) / 86400000;
  return days > (RETENTION_DAYS[type] ?? Infinity);
}
