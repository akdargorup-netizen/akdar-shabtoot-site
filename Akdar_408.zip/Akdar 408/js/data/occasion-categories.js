// js/data/occasion-categories.js — شبتوت بحري
// ══════════════════════════════════════════════════════════════
//  تصنيفات "بيت مناسباتنا" — مصدر الحقيقة الوحيد لكل ما يتعلّق
//  بتصنيف مناسبة: التسمية، نص زر الفعل الذكي، عنوان قسم التعليقات
//  (commentsTitle: عنوان اسمي لا جملة أمر)، وسطر تعريف صاحب المناسبة
//  الاختياري (ownerCaption)، وعائلة لون الشارة. أي مكان في الواجهة يحتاج أي واحدة
//  من هذه القيم يقرأها من هنا فقط — بدون تكرار (نفس مبدأ
//  IDEA_CATEGORIES في idea-box-data.js).
//
//  chipFamily تشير لعائلة توكنز موجودة أصلاً في tokens.css
//  (--notif-congrats-*, --notif-solidarity-*, --notif-condolence-*,
//  --notif-system-*) — بدون أي لون جديد، فقط إعادة استخدام.
//
//  حقول الفورم الديناميكي (ownerLabel/ownerPlaceholder/dateLabel/
//  datePlaceholder/showLocation/locationLabel/locationPlaceholder):
//  الـ schema في db.js ثابت وما بيتغيّرش (title/ownerName/eventDate/
//  eventLocation/text) — اللي بيتغيّر حسب التصنيف هو بس صياغة
//  الحقل (تسميته ومثاله) وظهور حقل المكان من عدمه. occasion-form-
//  modal.js يقرأ هذه القيم ويحدّث الفورم لحظيًا لما التصنيف يتغيّر.
// ══════════════════════════════════════════════════════════════

export const OCCASION_CATEGORIES = [
  {
    key:          'wedding',
    label:        'عقد قران',
    actionVerb:   'بارك على المناسبة',
    shortVerb:    'بارك',
    commentsTitle: 'تبريكات الناس',
    chipFamily:   'congrats',
    icon:         'gem',
    ownerLabel:       'اسم صاحب العرس',
    ownerPlaceholder: 'مثلاً: محمد وفاطمة',
    dateLabel:        'زمان العرس',
    datePlaceholder:  'مثلاً: الجمعة القادمة بعد صلاة العصر',
    showLocation:     true,
    locationLabel:       'مكان العرس',
    locationPlaceholder: 'مثلاً: منزل الأسرة، حي كذا',
  },
  {
    key:          'condolence',
    label:        'تعزية',
    actionVerb:   'رسل تعزية',
    shortVerb:    'عزّي',
    commentsTitle: 'تعازي الناس',
    chipFamily:   'condolence',
    ownerCaption: 'الفقيد',
    icon:         'flower-2',
    ownerLabel:       'اسم الفقيد',
    ownerPlaceholder: 'مثلاً: الحاج آدم محمد',
    dateLabel:        'زمان العزا',
    datePlaceholder:  'مثلاً: بعد صلاة العصر الجمعة الجاية',
    showLocation:     true,
    locationLabel:       'مكان العزا',
    locationPlaceholder: 'مثلاً: بيت الفقيد، حي كذا',
  },
  {
    key:          'success',
    label:        'مباركة نجاح',
    actionVerb:   'بارك النجاح',
    shortVerb:    'بارك',
    commentsTitle: 'تبريكات الناس',
    chipFamily:   'solidarity',
    icon:         'graduation-cap',
    ownerLabel:       'اسم الناجح',
    ownerPlaceholder: 'مثلاً: أحمد آدم',
    dateLabel:        'زمان الاحتفال',
    datePlaceholder:  'مثلاً: بعد صلاة المغرب الخميس',
    showLocation:     false,
  },
  {
    key:          'karama',
    label:        'كرامة',
    actionVerb:   'بارك على الكرامة',
    shortVerb:    'بارك',
    commentsTitle: 'تبريكات الناس',
    chipFamily:   'condolence',
    ownerCaption: 'صاحب الكرامة',
    icon:         'flame',
    ownerLabel:       'اسم صاحب الكرامة',
    ownerPlaceholder: 'مثلاً: أسرة آدم',
    dateLabel:        'زمان الكرامة',
    datePlaceholder:  'مثلاً: بعد صلاة الجمعة',
    showLocation:     false,
  },
  {
    key:          'newborn',
    label:        'سماية',
    actionVerb:   'بارك بالمولود',
    shortVerb:    'بارك',
    commentsTitle: 'تبريكات الناس',
    chipFamily:   'solidarity',
    icon:         'baby',
    ownerLabel:       'اسم المولود وأهله',
    ownerPlaceholder: 'مثلاً: مولود أسرة آدم',
    dateLabel:        'زمان السماية',
    datePlaceholder:  'مثلاً: يوم السبت الجاي',
    showLocation:     true,
    locationLabel:       'مكان السماية',
    locationPlaceholder: 'مثلاً: منزل الأسرة، حي كذا',
  },
  {
    key:          'engagement',
    label:        'خطوبة',
    actionVerb:   'بارك الخطوبة',
    shortVerb:    'بارك',
    commentsTitle: 'تبريكات الناس',
    chipFamily:   'congrats',
    icon:         'heart',
    ownerLabel:       'اسم صاحب الخطوبة',
    ownerPlaceholder: 'مثلاً: محمد وفاطمة',
    dateLabel:        'زمان الخطوبة',
    datePlaceholder:  'مثلاً: بعد صلاة العصر الجمعة الجاية',
    showLocation:     true,
    locationLabel:       'مكان الخطوبة',
    locationPlaceholder: 'مثلاً: منزل الأسرة، حي كذا',
  },
  {
    key:          'other',
    label:        'أخرى',
    actionVerb:   'بارك على المناسبة',
    shortVerb:    'بارك',
    commentsTitle: 'تعليقات الناس',
    chipFamily:   'system',
    icon:         'sparkles',
    ownerLabel:       'اسم صاحب المناسبة',
    ownerPlaceholder: 'مثلاً: أسرة آدم',
    dateLabel:        'الزمان',
    datePlaceholder:  'مثلاً: الجمعة القادمة بعد صلاة العصر',
    showLocation:     true,
    locationLabel:       'المكان',
    locationPlaceholder: 'مثلاً: منزل الأسرة، حي كذا',
  },
];

/** يرجّع تعريف تصنيف كامل بمفتاحه، أو تصنيف "أخرى" كاحتياط */
export function getOccasionCategory(key) {
  return OCCASION_CATEGORIES.find(c => c.key === key) || OCCASION_CATEGORIES[OCCASION_CATEGORIES.length - 1];
}

/** لون الهوية البصرية لكارت المناسبة في الواجهة العامة (خلاصة
 *  المناسبات وصفحة تفاصيلها) — مختلف عمدًا عن chipFamily الأصلي
 *  (المستخدم في شارة تصنيف لوحة التحكم فقط): كل التصنيفات بقت بلون
 *  هوية القسم نفسه (reed) إلا "التعزية" وحدها، فضلت بظلها الغامق
 *  المميّز المناسب لطبيعتها. */
export function getOccasionVisualChip(key) {
  return key === 'condolence' ? 'condolence' : 'reed';
}


/** الحد الأقصى لعدد أحرف تعليق واحد على مناسبة (ثابت من مصدر واحد) */
export const OCCASION_COMMENT_MAX_LENGTH = 150;
