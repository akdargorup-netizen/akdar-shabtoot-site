// js/data/videos-events-data.js — شبتوت بحري
// ══════════════════════════════════════════════════════════════
//  بيانات مناسبات القرية — فيديوهات يوتيوب
//  كل عنصر يحمل youtubeId فقط (لا رابط كامل)
//  الرابط يُبنى في الصفحة: https://youtu.be/{youtubeId}
//  الثامبنيل يُبنى: https://img.youtube.com/vi/{youtubeId}/hqdefault.jpg
// ══════════════════════════════════════════════════════════════

export const EVENT_CATEGORIES = [
  { key: 'all',         label: 'الكل'      },
  { key: 'social',      label: 'اجتماعي'   },
  { key: 'documentary', label: 'وثائقي'    },
  { key: 'other',       label: 'أخرى'      },
];
