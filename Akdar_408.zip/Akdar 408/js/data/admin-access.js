// js/data/admin-access.js — شبتوت بحري
// ═══════════════════════════════════════════════════════════════════
//  من يدخل أي صفحة إدارية؟ (مصدر واحد للراوتر ولوحة الإدارة)
//
//  أثناء الخطة المجانية (Spark) ومرحلة التطوير: كل صفحات الإدارة للمطوّر
//  فقط. ولما نترقّى لخطة أوسع ونكون جاهزين للإطلاق:
//    ١) غيّر ADMIN_CONTENT_OPEN_TO_ADMINS إلى true  → يفتح لمشرفي المحتوى
//       (أخبار، فعاليات، ذاكرة، معرض، تاريخ، مسيرة، مشاريع، دليل، آنداندي)
//       — هذه رخيصة القراءة (كاش بختم إصدار) وكتاباتها قليلة.
//    ٢) صفحات ALWAYS_DEVELOPER تبقى للمطوّر دائمًا (تقرأ كوليكشنات كاملة
//       أو تدير صلاحيات/بثّ): الرسائل، رقابة الأعضاء، الرسائل الواردة،
//       صندوق الأفكار، المناسبات، الصلاحيات، سجل النشاط، النسخ الاحتياطي.
//       افتحها لأحد فقط بعد تحسين قراءاتها (نافذة زمنية/limit).
//
//  ⚠️ هذا حارس واجهة وراوتر. الحماية الحقيقية على الخادم هي claims الحساب
//  (admin/owner) وسياسات RLS في Supabase — فأقوى طريقة: لا تمنح claim admin لأحد
//  غيرك خلال هذه المرحلة.
// ═══════════════════════════════════════════════════════════════════

export const ADMIN_CONTENT_OPEN_TO_ADMINS = false;

const ALWAYS_DEVELOPER = new Set([
  'admin-notifications', 'admin-members', 'admin-inbox', 'admin-idea-box',
  'admin-occasions', 'admin-permissions', 'admin-activity-log', 'admin-backup', 'admin-ai',
]);

const CONTENT_PAGES = new Set([
  'admin-news', 'admin-events', 'admin-study', 'admin-lectures', 'admin-gallery', 'admin-history',
  'admin-association-journey', 'admin-projects', 'admin-contacts', 'admin-nubian',
]);

/** الأدوار المسموحة لصفحة إدارية. defRoles = roles المعرّفة في الراوتر (إن وُجدت). */
export function allowedRolesFor(page, defRoles) {
  if (ALWAYS_DEVELOPER.has(page)) return ['developer'];
  // مشرف الرُطانة: قسم آنداندي وحده (قاموس الكلمات + تعلم الكلام + النطق الصوتي)، مفتوح له دون فتح بقية صفحات المحتوى
  if (page === 'admin-nubian' || page.startsWith('admin-nubian-')) return ['developer', 'nubian'];
  if (CONTENT_PAGES.has(page) && !ADMIN_CONTENT_OPEN_TO_ADMINS) return ['developer'];
  return defRoles || ['developer', 'admin'];
}

export function canAccessAdminPage(role, page, defRoles) {
  return allowedRolesFor(page, defRoles).includes(role);
}
