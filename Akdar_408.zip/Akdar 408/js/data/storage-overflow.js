// js/data/storage-overflow.js — شبتوت بحري
// ══════════════════════════════════════════════════════════════
//  مشروع التخزين الاحتياطي (Supabase الثاني): يستقبل الرفع الجديد فقط حين يمتلئ المشروع الأول،
//  فتصبح السعة ٢ جيجا بدل ١. الملفات القديمة تبقى في مكانها وروابطها لا تتغيّر.
//
//  التفعيل: ضع عنوان المشروع الثاني في STORAGE2_URL (مثال: 'https://abcdxyz.supabase.co').
//  وهو فارغ الآن = الميزة مُعطّلة تمامًا والتطبيق يعمل كما كان.
//  الرفع إلى الثاني يمرّ عبر دالة storage-overflow في المشروع الأول (فهي من تتحقق من صلاحية صاحب الطلب).
//  الإعداد الكامل: STORAGE2-SETUP.md
//
//  الكتابة المزدوجة (DUAL_WRITE): كل صورة/مقطع جديد يُرفع للأول ثم يُنسخ للثاني بنفس المسار (best-effort بلا تعطيل المستخدم)،
//  والقراءة تجرّب المشروع الآخر بالمسار نفسه لو فشل الأول أو تأخّر (alternateObjectUrl/fetchObject، وللصور في service-worker.js).
//  الثمن: السعة الفعلية جيجا واحد بدل اثنين لأن النسخة مكرّرة. اجعلها false لو اقتربنا من السعة (فيعود نمط الفيض وحده).
//  ما فاته النسخ (فشل شبكة) يرمّمه scripts/admin/sync-storage.mjs (مهمة يومية .github/workflows/storage-sync.yml).
//
//  متى نحوّل؟ (١) استباقيًا: لو استهلاك الأول ≥ SWITCH_AT_BYTES (يُفحص كل ١٠ دقائق كحد أقصى)
//                (٢) احتياطيًا: لو ردّ الأول بخطأ خادم/حصّة أثناء الرفع (ليس انقطاع شبكة ولا رفض صلاحية).
// ══════════════════════════════════════════════════════════════

import { SUPABASE_URL, SUPABASE_KEY } from './supabase-client.js';

export const STORAGE2_URL = 'https://qomxcmgtvyfdrzkkniwt.supabase.co';                       // ← عنوان المشروع الثاني (فارغ = معطّل)
const SWITCH_AT_BYTES = 940 * 1024 * 1024;            // نحوّل قبل امتلاء الجيجا بقليل (الحد المجاني ١ جيجا)
const CHECK_KEY = 'akdar_s2_check_v1';
const CHECK_TTL = 10 * 60 * 1000;

/** نسخة احتياطية لكل رفع جديد في المشروع الآخر (لا تعمل إلا إن كان الفيض مفعّلًا أي STORAGE2_URL مضبوطًا). false = كل ملف في مكان واحد فتبقى السعة ٢ جيجا. */
export const DUAL_WRITE = false;   // معطّل عمدًا: الازدواج ينصّف السعة. الحماية من الضياع = تصدير دوري لملفات خارجية (MULTI-HOST.md)
const ALT_STAGGER_MS = 6000;                          // بعدها يبدأ المشروع الآخر بالتوازي (شبكات القرية بطيئة؛ لا نتعجّل)

export const AUDIO_PREFIX = 's2/';                    // علامة مسار الصوت المخزَّن في المشروع الثاني

const _base2 = () => STORAGE2_URL.replace(/\/+$/, '');
export const dualWriteEnabled = () => DUAL_WRITE && overflowEnabled();
export const overflowEnabled = () => /^https:\/\/[a-z0-9-]+\.supabase\.co\/?$/i.test(STORAGE2_URL);
export const isSecondaryUrl = (url) => overflowEnabled() && typeof url === 'string' && url.startsWith(`${_base2()}/storage/v1/object/public/`);

async function _token() {
  try { return await (await import('./auth.js')).getIdToken(); } catch { return null; }
}

/** هل امتلأ المشروع الأول؟ (كاش ١٠ دقائق؛ أي فشل في الفحص = لا نحوّل) */
export async function primaryIsFull() {
  if (!overflowEnabled()) return false;
  try {
    const c = JSON.parse(sessionStorage.getItem(CHECK_KEY) || 'null');
    if (c && Date.now() - c.t < CHECK_TTL) return c.full === true;
  } catch { /* */ }
  const token = await _token();
  if (!token) return false;
  let full = false;
  try {
    const res = await fetch(`${SUPABASE_URL}/rest/v1/rpc/akdar_storage_used`, {
      method: 'POST',
      headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: '{}',
    });
    if (!res.ok) return false;
    full = Number(await res.json()) >= SWITCH_AT_BYTES;
  } catch { return false; }
  try { sessionStorage.setItem(CHECK_KEY, JSON.stringify({ t: Date.now(), full })); } catch { /* */ }
  return full;
}

/** يجبر الفحص التالي على الاستعلام من جديد (بعد رفض الأول) ويثبّت التحويل لباقي الجلسة */
export function markPrimaryFull() {
  try { sessionStorage.setItem(CHECK_KEY, JSON.stringify({ t: Date.now(), full: true })); } catch { /* */ }
}

async function _call(body) {
  const token = await _token();
  if (!token) throw new Error('no-session');
  const res = await fetch(`${SUPABASE_URL}/functions/v1/storage-overflow`, {
    method: 'POST',
    headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw Object.assign(new Error('overflow-call-failed'), { status: res.status });
  return res.json();
}

/**
 * يرفع Blob/File إلى المشروع الثاني عبر رابط موقّع.
 * @returns {Promise<string>} الرابط العام للملف
 */
export function uploadToSecondary({ bucket, path, blob, contentType, onProgress }) {
  return _call({ action: 'sign-upload', bucket, path }).then(({ uploadUrl, publicUrl }) => new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('PUT', uploadUrl, true);
    xhr.setRequestHeader('Content-Type', contentType || blob.type || 'application/octet-stream');
    xhr.setRequestHeader('cache-control', 'max-age=31536000');
    xhr.upload.onprogress = (e) => { if (onProgress && e.lengthComputable) onProgress(Math.round((e.loaded / e.total) * 100)); };
    xhr.onload = () => (xhr.status >= 200 && xhr.status < 300 ? resolve(publicUrl) : reject(new Error('secondary-upload-failed')));
    xhr.onerror = () => reject(new Error('network'));
    xhr.send(blob);
  }));
}

/** حذف ملفات من المشروع الثاني (صامت: الفشل لا يكسر شيئًا) */
export async function deleteFromSecondary(bucket, paths) {
  if (!overflowEnabled() || !paths?.length) return 0;
  try { return (await _call({ action: 'delete', bucket, paths })).removed || 0; } catch { return 0; }
}

/** مسار ملف داخل bucket المشروع الثاني من رابطه العام (أو '') */
export function secondaryPathOf(url, bucket) {
  if (!isSecondaryUrl(url)) return '';
  const prefix = `${_base2()}/storage/v1/object/public/${bucket}/`;
  return url.startsWith(prefix) ? decodeURIComponent(url.slice(prefix.length).split('?')[0]) : '';
}

/** الرابط العام لمقطع صوتي مخزَّن في الثاني (المسار يبدأ بـ s2/) */
export const secondaryClipUrl = (path) => `${_base2()}/storage/v1/object/public/akdar-audio/${path.slice(AUDIO_PREFIX.length)}`;

// ══════════════════════════════════════════════════════════════
//  النسخة الاحتياطية (الكتابة المزدوجة) والقراءة بالتبديل
// ══════════════════════════════════════════════════════════════

/**
 * ينسخ ملفًا رُفع للمشروع الأول إلى الثاني بالمسار نفسه. لا يرمي أبدًا ولا يُنتظَر في واجهة المستخدم:
 * فشله لا يضيّع شيئًا (الأصل محفوظ) وترمّمه مهمة المزامنة اليومية. محاولتان بفاصل قصير.
 * @returns {Promise<boolean>}
 */
export async function mirrorToSecondary({ bucket, path, blob, contentType }) {
  if (!dualWriteEnabled()) return false;
  for (let i = 0; i < 2; i++) {
    try {
      await uploadToSecondary({ bucket, path, blob, contentType });
      return true;
    } catch {
      if (i === 0) await new Promise((r) => setTimeout(r, 2500));
    }
  }
  return false;
}

/**
 * الرابط المقابل للملف نفسه في المشروع الآخر (أول↔ثاني، المسار نفسه)، أو '' لو ليس رابط تخزين لأحدهما.
 * الصور المرفوعة قبل الازدواج أو التي فاتها النسخ قد لا توجد في الآخر: الفشل هناك عادي ولا يضرّ.
 */
export function alternateObjectUrl(url) {
  if (!overflowEnabled() || typeof url !== 'string') return '';
  const P = '/storage/v1/object/public/';
  const a = `${SUPABASE_URL.replace(/\/+$/, '')}${P}`, b = `${_base2()}${P}`;
  if (url.startsWith(a)) return b + url.slice(a.length);
  if (url.startsWith(b)) return a + url.slice(b.length);
  return '';
}

/**
 * fetch لملف تخزين مع بديل: الأصلي أولًا؛ لو فشل (شبكة/٤xx/٥xx) يبدأ البديل فورًا، ولو تأخّر ٦ ثوانٍ يبدأ البديل
 * بالتوازي ويفوز الأسرع نجاحًا. لو فشل الاثنان تُعاد استجابة الأصلي كما كانت (فلا يتغيّر سلوك الأخطاء).
 * بلا بديل (الفيض معطّل أو رابط غريب) = fetch عادي.
 */
export async function fetchObject(url, init = { mode: 'cors', credentials: 'omit' }) {
  const alt = alternateObjectUrl(url);
  if (!alt) return fetch(url, init);
  const go = (u) => fetch(u, init).then((r) => (r.ok ? r : Promise.reject(r)));
  const p1 = go(url);
  const p2 = new Promise((resolve, reject) => {
    let started = false;
    const start = () => { if (!started) { started = true; go(alt).then(resolve, reject); } };
    const t = setTimeout(start, ALT_STAGGER_MS);
    p1.then(() => clearTimeout(t), () => { clearTimeout(t); start(); });
  });
  try {
    return await Promise.any([p1, p2]);
  } catch (agg) {
    const first = agg?.errors?.[0];
    if (first instanceof Response) return first;
    throw first || agg;
  }
}
