// js/data/hosts.js — شبتوت بحري
// ══════════════════════════════════════════════════════════════
//  تبديل المضيفات للملفات الثابتة (المرآة واللقطات): لو سقط المضيف الذي حُمّل منه التطبيق
//  أو حُجب عند مستخدم، تُجلب الملفات نفسها من مضيف آخر دون أن يلاحظ شيئًا.
//
//  • لا يمسّ الصفحة نفسها ولا الـservice worker: فقط ملفات JSON الثابتة تحت content/.
//  • المضيف الحالي أولًا. لو تأخّر (staggerMs) يبدأ التالي بالتوازي ويفوز الأسرع (كشبكات القرية البطيئة).
//  • من يفشل مرتين متتاليتين (خطأ شبكة/مهلة/5xx) يُؤخَّر لآخر الترتيب ٥ دقائق ثم يُجرَّب ثانية.
//    لا يُستبعد أبدًا: التأخير للترتيب فقط، فلا يضيع مضيف سليم بسبب انقطاع نت مؤقت.
//  • 404 لا يُعدّ فشل مضيف (الملف غير موجود هناك فقط).
//  • الحالة تُحفظ في localStorage (اختياري؛ لو غاب نكمل بالذاكرة).
//  • المضيفات الأخرى تحتاج ترويسة CORS على /content/** (موجودة في firebase.json) — GitHub Pages يرسلها تلقائيًا.
//  • على localhost لا نكلّم المضيفات الحقيقية أبدًا (كي لا يلوّث التطوير الإنتاج).
// ══════════════════════════════════════════════════════════════

/**
 * مضيفات تقدّم نفس ملفات content/ (تنتهي بـ / ). القائمة مولَّدة من hosts.config.json
 * (node build/gen-hosts.js) — لا تعدّلها يدويًا، عدّل الإعداد وأعد التوليد.
 */
// HOSTS:START
export const MIRROR_HOSTS = [
  'https://akdar-nine.vercel.app/',
  'https://akdar-shabtoot.web.app/',
  'https://akdar-shabtoot.firebaseapp.com/',
  'https://akdargorup-netizen.github.io/akdar-shabtoot-site/',
];
// HOSTS:END

const STATE_KEY = 'akdar:hosts:v1';
const FAILS_TO_COOL = 2;
const COOL_MS = 5 * 60 * 1000;

const _norm = (u) => (u.endsWith('/') ? u : u + '/');

/** جذر المضيف الذي حُمّل منه التطبيق (js/data/hosts.js ← ../../) */
const CURRENT = _norm(new URL('../../', import.meta.url).href);
// داخل غلاف أندرويد (Capacitor) يكون العنوان https://localhost لكنه ليس تطويرًا: الملفات مضمَّنة في الـAPK.
// هناك نجلب المرآة من المضيفات الحقيقية أولًا، والنسخة المضمَّنة (وقت البناء) احتياط أخير بلا نت.
const IS_NATIVE = typeof window !== 'undefined' && !!(window.Capacitor &&
  typeof window.Capacitor.isNativePlatform === 'function' && window.Capacitor.isNativePlatform());
const IS_LOCAL = !IS_NATIVE && /^(localhost|127\.|\[::1\]|0\.0\.0\.0)/.test(new URL(CURRENT).hostname);

let _state = null;
function _load() {
  if (_state) return _state;
  try { _state = JSON.parse(localStorage.getItem(STATE_KEY) || '{}') || {}; } catch { _state = {}; }
  return _state;
}
function _save() {
  try { localStorage.setItem(STATE_KEY, JSON.stringify(_state)); } catch { /* اختياري */ }
}
function _slot(base) {
  const s = _load();
  return (s[base] = s[base] || { f: 0, u: 0, ok: 0 });
}

function _markFail(base) {
  if (typeof navigator !== 'undefined' && navigator.onLine === false) return; // لا نعاقب مضيفًا بسبب انقطاع نت جهازنا
  const s = _slot(base);
  s.f += 1;
  if (s.f >= FAILS_TO_COOL) s.u = Date.now() + COOL_MS;
  _save();
}
function _markOk(base) {
  const s = _slot(base);
  s.f = 0; s.u = 0; s.ok = Date.now();
  _save();
}

/** المضيفات بالترتيب: الحالي أولًا، ثم الباقي، والمتعثّر حديثًا في الآخر. */
export function hostBases() {
  if (IS_LOCAL) return [CURRENT];
  if (IS_NATIVE) {
    const remote = [...new Set(MIRROR_HOSTS.map(_norm))];
    const t = Date.now();
    const ok = remote.filter((b) => _slot(b).u <= t);
    const cool = remote.filter((b) => _slot(b).u > t).sort((x, y) => _slot(x).u - _slot(y).u);
    return [...ok, ...cool, CURRENT];
  }
  const all = [...new Set([CURRENT, ...MIRROR_HOSTS.map(_norm)])];
  const now = Date.now();
  const healthy = all.filter((b) => _slot(b).u <= now);
  const cooling = all.filter((b) => _slot(b).u > now).sort((a, b) => _slot(a).u - _slot(b).u);
  return [...healthy, ...cooling];
}

/** حالة المضيفات للتشخيص (لوحة الإدارة أو الكونسول): [{base, fails, coolingMs, lastOk}] */
export function hostStatus() {
  const now = Date.now();
  return hostBases().map((b) => {
    const s = _slot(b);
    return { base: b, current: b === CURRENT, fails: s.f, coolingMs: Math.max(0, s.u - now), lastOk: s.ok || null };
  });
}

/**
 * يجلب ملف JSON ثابتًا (مسار نسبي لجذر التطبيق، مثل 'content/mirror/news.json') من أول مضيف ينجح.
 * @param {string} rel
 * @param {object} [o]
 * @param {number} [o.timeoutMs=8000]  مهلة كل محاولة
 * @param {number} [o.staggerMs=2500]  بعدها يبدأ المضيف التالي بالتوازي
 * @param {(data:any)=>boolean} [o.validate]  رفض ردّ سليم الشكل لكنه فارغ/قديم ← يجرَّب المضيف التالي
 * @param {RequestInit} [o.init]
 * @returns {Promise<any|null>} البيانات أو null لو فشلت كل المضيفات
 */
export function fetchStaticJson(rel, { timeoutMs = 8000, staggerMs = 2500, validate = null, init = {} } = {}) {
  const bases = hostBases();
  return new Promise((resolve) => {
    let done = false, started = 0, failed = 0, timer = null;
    const ctrls = [];

    const finish = (val) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      ctrls.forEach((c) => { try { c.abort(); } catch { /* تجاهل */ } });
      resolve(val);
    };
    const launch = () => {
      clearTimeout(timer);
      if (done || started >= bases.length) return;
      attempt(bases[started++]);
      if (started < bases.length) timer = setTimeout(launch, staggerMs);
    };
    const failOne = () => {
      failed += 1;
      if (failed >= bases.length) finish(null);
      else if (started < bases.length) launch(); // لا ننتظر المهلة لو فشل مضيف فشلًا صريحًا
    };

    function attempt(base) {
      const ctrl = new AbortController();
      ctrls.push(ctrl);
      const to = setTimeout(() => ctrl.abort(), timeoutMs);
      fetch(new URL(rel, base), { cache: 'no-cache', ...init, signal: ctrl.signal })
        .then(async (res) => {
          if (done) return;
          if (!res.ok) {
            if (res.status >= 500 || res.status === 429) _markFail(base);
            return failOne();
          }
          let data;
          try { data = await res.json(); } catch { _markFail(base); return failOne(); } // صفحة HTML بدل JSON ونحوه
          if (done) return;
          if (validate && !validate(data)) return failOne();
          _markOk(base);
          finish(data);
        })
        .catch(() => { if (!done) { _markFail(base); failOne(); } })
        .finally(() => clearTimeout(to));
    }

    if (!bases.length) return finish(null);
    launch();
  });
}

// ══════════════════════════════════════════════════════════════
//  تبديل المضيف عند فشل «أول تثبيت» (نفاد حصة / 402 / 429 / 5xx على المضيف الحالي)
//  • يعمل فقط قبل أن يتحكّم service worker بالصفحة (أول زيارة/أول تثبيت). المثبَّت سابقًا يعمل من كاشه.
//  • إشارة الفشل: تعذّر تسجيل الـSW أو سقوط تثبيته (redundant) ثم تأكيد أن service-worker.js نفسه
//    لا يُجلب من هذا المضيف (كي لا نقفز بين المضيفات بسبب مشكلة محلية كوضع التصفح الخاص).
//  • الهدف: أول مضيف آخر يردّ health.json سليمًا، مع حارس حلقات (?hf= قائمة ما جُرّب).
//  • تنبيه: localStorage خاص بكل نطاق، فجلسة الدخول لا تنتقل مع القفزة (تسجيل دخول جديد فقط).
// ══════════════════════════════════════════════════════════════
const HF = 'hf';
const _hostOf = (b) => new URL(b).host;

function _probeBase(base, ms = 4000) {
  return new Promise((resolve) => {
    const ctl = new AbortController();
    const t = setTimeout(() => { ctl.abort(); resolve(false); }, ms);
    fetch(new URL('health.json?t=' + Date.now(), base), { cache: 'no-store', mode: 'cors', signal: ctl.signal })
      .then((r) => (r.ok ? r.json() : null))
      .then((j) => { clearTimeout(t); resolve(!!(j && j.ok === true && j.app === 'akdar')); })
      .catch(() => { clearTimeout(t); resolve(false); });
  });
}

async function _hostIsBroken() {
  try {
    const r = await fetch(new URL('service-worker.js?t=' + Date.now(), CURRENT), { cache: 'no-store' });
    return !r.ok;
  } catch { return navigator.onLine !== false; }
}

export async function initHostFailover() {
  try {
    if (IS_LOCAL || IS_NATIVE || !('serviceWorker' in navigator)) return; // الغلاف: الملفات مضمَّنة ولا قفز بين مضيفات
    const q = new URLSearchParams(location.search);
    const tried = new Set((q.get(HF) || '').split(',').filter(Boolean));
    if (navigator.serviceWorker.controller) {
      if (q.has(HF)) { q.delete(HF); history.replaceState(null, '', location.pathname + (q.toString() ? '?' + q : '') + location.hash); }
      return;
    }
    const t0 = Date.now();
    let sawWorker = false;
    const verdict = await new Promise((resolve) => {
      const tick = async () => {
        if (navigator.serviceWorker.controller) return resolve('ok');
        let reg = null;
        try { reg = await navigator.serviceWorker.getRegistration(); } catch { /* تجاهل */ }
        const w = reg && (reg.installing || reg.waiting || reg.active);
        if (reg && reg.active && !reg.installing) return resolve('ok');
        if (w) {
          sawWorker = true;
          if (reg.installing && !reg.installing._hf) {
            reg.installing._hf = 1;
            reg.installing.addEventListener('statechange', function () { if (this.state === 'redundant') resolve('failed'); });
          }
        } else if (Date.now() - t0 > (sawWorker ? 1500 : 12000)) return resolve('failed');
        if (Date.now() - t0 > 120000) return resolve('slow');
        setTimeout(tick, 1500);
      };
      setTimeout(tick, 3000);
    });
    if (verdict !== 'failed' || !(await _hostIsBroken())) return;

    tried.add(_hostOf(CURRENT));
    const rel = location.pathname.slice(new URL(CURRENT).pathname.length);
    for (const base of MIRROR_HOSTS.map(_norm)) {
      if (tried.has(_hostOf(base))) continue;
      if (!(await _probeBase(base))) { tried.add(_hostOf(base)); continue; }
      location.replace(new URL(rel, base).href.split('?')[0] + '?' + HF + '=' + [...tried].join(',') + location.hash);
      return;
    }
  } catch { /* لا يؤثر على التطبيق أبدًا */ }
}
