// js/data/local-data.js — شبتوت بحري
// ══════════════════════════════════════════════════════════════
//  البيانات المحلية الثابتة
//  هذا الملف يُستخدم فقط مع local-adapter.js
//  عند التحويل لـ Firebase، هذه البيانات تنتقل لـ Firestore
// ══════════════════════════════════════════════════════════════

// ─── فئات الأخبار الرسمية ───────────────────────────────────────
// قائمة ثابتة (مش نص حر) — دي اللي هتُستخدم كقائمة اختيار (dropdown)
// في نموذج إضافة خبر بلوحة الإدارة لاحقاً.
export const NEWS_CATEGORIES = [
  { key: 'community', label: 'المجتمع' },
  { key: 'events',     label: 'فعاليات' },
  { key: 'projects',   label: 'مشاريع وتنمية' },
];

// ─── بيانات أخبار خفيفة (placeholder) ───────────────────────────
// بيانات تجريبية متعمّد فيها تنوّع (مش نسخ متطابقة) عشان تختبر
// الشكل الواقعي قبل الاتصال بـ Firestore:
//   - عنصر بدون صورة (image) وعنصر بيها — لاختبار الحقل الاختياري
//   - عنصر بعنوان قصير وعنصر بعنوان طويل
//   - عنصر body بجملة واحدة وعنصر بجملتين
//   - الفئات الثلاث ممثّلة كلها (community / history / projects)
// ما فيهاش مسارات صور وهمية — الحقل image يُترك فاضي لحد ما تُرفع
// صور حقيقية فعلاً (news.js وreader.js أصلاً بيتعاملوا مع غيابه بأمان).
//
// ملاحظات على الحقول:
//   - category: مفتاح من NEWS_CATEGORIES (مش نص عربي حر) — عشان التصنيف
//     يفضل مربوط بمصدر واحد للحقيقة، والتلوين/التسمية يتحسبوا منه.
//   - publishedAt: توقيت ISO حقيقي — التاريخ "منذ ساعة" أو "أمس" بيتحسب
//     وقت العرض (local-adapter.js) مش مكتوب يدوي، عشان يفضل صحيح دايماً.
// ─── تصنيفات الإشعارات ───────────────────────────────────────────
// مصدر الحقيقة الوحيد لشكل كل تصنيف (الأيقونة والصفحة الهدف).
// نفس الأيقونات المستخدمة أصلاً في فهرس "المجتمع" (community.js)
// عشان الهوية البصرية تفضل واحدة بين الإشعار والصفحة اللي بيودّي ليها.
// الألوان بتتحسب من توكنز التصنيف في tokens.css (--notif-{key}-*)
// مش من هنا — الملف ده بيّاني بس (بيانات)، مش تنسيق.
export const NOTIFICATION_TYPES = [
  { key: 'news',       label: 'خبر',        icon: 'newspaper',       page: 'news' },
  { key: 'event',      label: 'الفعاليات',   icon: 'calendar-heart',  page: 'events' },
  { key: 'congrats',   label: 'تبريك',       icon: 'party-popper',    page: 'community-occasions' },
  { key: 'condolence', label: 'تعزية',       icon: 'flower-2',        page: 'community-occasions' },
  { key: 'community',  label: 'مجتمع',       icon: 'megaphone',       page: 'community-occasions' },
  { key: 'project',    label: 'مشروع',       icon: 'trending-up',     page: 'development-projects' },
  { key: 'idea',       label: 'مصنع الأفكار', icon: 'lightbulb',      page: 'idea-box' },
  { key: 'worship',    label: 'العبادة',     icon: 'moon-star',       page: 'worship' },
  { key: 'nubian',     label: 'آنداندي',     icon: 'languages',       page: 'nubian-dictionary' },
  { key: 'system',     label: 'رسالة عامة', icon: 'bell',            page: '' },
  // ─── تفاعل شخصي (لايك/تعليق/رد/تأييد) ─────────────────────────
  // موجّهة لصاحب المحتوى تحديدًا (recipientUid)، مش بث عام زي فوق —
  // page فاضي عمدًا: التنقّل بيتحدد وقت الضغط حسب targetKind/targetId
  // (شوف _openInteractionTarget في notifications.js) لأن صفحات
  // التفاصيل بتاخد كائن المناسبة/الفكرة الكامل مش بس اسم صفحة.
  // personal: true — تتولّد تلقائيًا من فعل مستخدم، مش من لوحة الإدارة
  // (شوف admin-notifications.js: مستبعدة من قائمة اختيار النوع هناك).
  { key: 'like',    label: 'إعجاب', icon: 'heart',          page: '', personal: true },
  { key: 'comment', label: 'تعليق', icon: 'message-circle', page: '', personal: true },
  { key: 'reply',   label: 'رد',    icon: 'reply',          page: '', personal: true },
  { key: 'endorse', label: 'تأييد', icon: 'thumbs-up',      page: '', personal: true },
];

// خريطة تصنيف الإشعار (المفاتيح فوق) → مفتاح سويتش التحكم في صفحة
// الإعدادات (settings-notifications.js → NOTIF_GROUPS). 'system' عمداً
// غير موجودة — رسائل عامة من إدارة التطبيق تفضل شغالة دايمًا بدون توغل.
// ⚠️ فلترة الـ push الفعلية (service-worker.js، حدث 'push') عندها نسخة
// مكرَّرة يدويًا من نفس الخريطة (`NOTIF_TYPE_TO_TOGGLE`) لأنها سكريبت
// كلاسيكي ما يقدرش يعمل import لملف ES module زي ده — أي تعديل هنا
// لازم يتزامن هناك يدويًا برضو. أنواع التفاعل الشخصي (like/comment/
// reply/endorse) مش موجودة في نسخة service-worker.js لأنها أصلاً
// بدون push من الأساس (داخل التطبيق بس).
export const NOTIFICATION_TYPE_TO_SETTING = {
  news:       'notif-news',
  event:      'notif-events',
  solidarity: 'notif-community-life',
  congrats:   'notif-community-life',
  condolence: 'notif-community-life',
  community:  'notif-community',
  project:    'notif-projects',
  idea:       'notif-projects',
  worship:    'notif-worship',
  nubian:     'notif-community',
  like:       'notif-interactions',
  comment:    'notif-interactions',
  reply:      'notif-interactions',
  endorse:    'notif-interactions',
};

// ─── نصوص إشعارات التفاعل الشخصي ───────────────────────────────
// مصدر الحقيقة الوحيد لصياغة كل نوع تفاعل — يستخدمه المحوّلان
// (local-adapter.js وfirebase-adapter.js) عند إنشاء إشعار موجّه
// لصاحب المحتوى. kind من: like_occasion / comment_occasion /
// like_comment / comment_idea / endorse_idea.
export function buildInteractionMessage(kind, actorName, targetTitle) {
  const name = actorName || 'عضو من البلد';
  switch (kind) {
    case 'like_occasion':
      return { type: 'like', title: 'إعجاب بمناسبتك', body: `أعجب ${name} بمناسبتك «${targetTitle}»` };
    case 'comment_occasion':
      return { type: 'comment', title: 'تعليق على مناسبتك', body: `علّق ${name} على مناسبتك «${targetTitle}»` };
    case 'comment_idea':
      return { type: 'comment', title: 'تعليق على فكرتك', body: `علّق ${name} على فكرتك «${targetTitle}»` };
    case 'like_comment':
      return { type: 'like', title: 'إعجاب بتعليقك', body: `أعجب ${name} بتعليقك` };
    case 'endorse_idea':
      return { type: 'endorse', title: 'تأييد لفكرتك', body: `أيّد ${name} فكرتك «${targetTitle}»` };
    default:
      return null;
  }
}
