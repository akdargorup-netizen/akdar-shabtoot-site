// js/data/interaction-config.js — شبتوت بحري
// أي أنواع التفاعل تولّد إشعارًا شخصيًا لصاحب المحتوى؟ (الخطة المجانية: التعليقات فقط)
// الردّ على التعليقات اتشال من التطبيق (تقليل القراءات) فمافي إشعار ردود.
// لإعادة تفعيل نوع: أضفه هنا. الأنواع المتاحة: comment_idea,
// comment_occasion, like_occasion, like_comment, endorse_idea.
export const INTERACTION_NOTIFY_KINDS = new Set([
  'comment_idea', 'comment_occasion',
]);
