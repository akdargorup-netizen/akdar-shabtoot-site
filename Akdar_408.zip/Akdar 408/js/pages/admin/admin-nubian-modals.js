// js/pages/admin/admin-nubian-modals.js — شبتوت بحري
// نافذة واحدة مفتوحة في المرة داخل إدارة آنداندي: كل نافذة تسجّل دالة إغلاقها هنا،
// وفتح نافذة جديدة (أو الخروج) يغلق السابقة عبر closeComposeModal().
let _cleanup = null;
export function setCleanup(fn) { _cleanup = fn; }
export function closeComposeModal() {
  if (_cleanup) { const fn = _cleanup; _cleanup = null; fn(); }
}
