// pages/services.js
// ══════════════════════════════════════════════════════════════
//  2026-09-01: تنسيقات البطاقات هنا بقت نفس بطاقات فهرس دليل
//  الاتصال بالحرف (contact-group-card في village.css) — نفس البنية
//  (أيقونة + عنوان ووصف + سهم)، نفس الأسماء البصرية
//  (.service-card__icon / __body / __top / __title / __desc /
//  __arrow)، عشان الواجهتين تتشربا من نفس الهوية البصرية تمامًا:
//  نفس البطاقات، الفواصل، المسافات، ودرجات الألوان.
// ══════════════════════════════════════════════════════════════

/** سهم مفرد — نفس السعم المستخدم بالحرف في contact-group-card__arrow */
const ARROW_SVG = `
  <svg viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M11 6L7 10L11 14" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>
`;

function renderServiceCard({ variant = '', icon, title, desc, dataAttrs = '' }) {
  const variantClass = variant ? ` service-card--${variant}` : '';
  return `
    <article class="service-card${variantClass}" ${dataAttrs}>
      <div class="service-card__icon" data-icon="${icon}"></div>
      <div class="service-card__body">
        <div class="service-card__top">
          <span class="service-card__title">${title}</span>
        </div>
        <p class="service-card__desc">${desc}</p>
      </div>
      <div class="service-card__arrow" aria-hidden="true">${ARROW_SVG}</div>
    </article>
  `;
}

export function renderServices() {
  // مجموعة "عاجل": الطوارئ والصحة — منفصلة بصريًا فوق كل شيء
  const urgent = [
    {
      variant: 'emergency', icon: 'siren', title: 'الطوارئ والصحة',
      desc: 'أرقام الطوارئ والإسعاف، وطلب متبرع بالدم أو تبرعات لحالة مستعجلة.',
      dataAttrs: 'data-page="emergency-health"',
    },
  ];

  // مجموعة "خدمات القرية": باقي البطاقات.
  // 2026-09-28: مصنع الأفكار رجع للون الطبيعي (نفس بطاقة الخدمات
  // العادية) — اتشال التمييز الذهبي (--idea) اللي كان عليه.
  const village = [
    {
      icon: 'lightbulb', title: 'مصنع الأفكار',
      desc: 'شاركنا فكرة تفيد البلد، وخلّي الناس تأيدها وتناقشها.',
      dataAttrs: 'data-page="idea-box"',
    },
    {
      variant: 'featured', icon: 'phone', title: 'دليل البلد',
      desc: 'جهات الاتصال والخدمات الأساسية لأبناء القرية.',
      dataAttrs: 'data-section="contacts"',
    },
    {
      icon: 'trending-up', title: 'متابعة المشاريع',
      desc: 'المشاريع الرسمية الجارية والقادمة وتفاصيلها.',
      dataAttrs: 'data-page="development-projects"',
    },
    {
      icon: 'graduation-cap', title: 'خدمات الطلاب',
      desc: 'طلب كورس دراسي، حصص فيديو، ونصائح أكاديمية للشهادتين المتوسطة والثانوية.',
      dataAttrs: 'data-page="student-services"',
    },
  ];

  // مجموعة "ترفيه": الألعاب — منفصلة عن خدمات القرية (2026-10-04)
  const fun = [
    {
      variant: 'fun', icon: 'gamepad-2', title: 'تحدي التنجلاب',
      desc: 'أسئلة وتحديات عن البلد وغيرها — اجمع النجوم، وسابق الوقت، وكن البطل.',
      dataAttrs: 'data-page="tanjalab"',
    },
  ];

  return `
    <section class="page services-page">
      <div class="services-group">
        <h3 class="services-group__label">عاجل</h3>
        <div class="services-sections">
          ${urgent.map(renderServiceCard).join('')}
        </div>
      </div>
      <div class="services-group">
        <h3 class="services-group__label">خدمات القرية</h3>
        <div class="services-sections">
          ${village.map(renderServiceCard).join('')}
        </div>
      </div>
      <div class="services-group">
        <h3 class="services-group__label">ترفيه</h3>
        <div class="services-sections">
          ${fun.map(renderServiceCard).join('')}
        </div>
      </div>
    </section>
  `;
}

// نقطة "فيه جديد" على بطاقة "مصنع الأفكار" — نفس آلية وفلسفة
// _initNewContentDots في home.js بالحرف: بنضيف النقطة بعد ما أيقونة
// lucide خلصت رسمها (مش قبل)، لأن renderIcons() بيستبدل innerHTML
// بتاع أي عنصر data-icon بالكامل. وبنستخدم getLatestIdeaId() الرخيصة
// (استعلام limit(1))، مش getIdeas() الكاملة — نفس إصلاح الأداء
// الموجود في home.js (انظر شرحه هناك).
export async function initServices() {
  // عدّاد "جديد" على بطاقة مصنع الأفكار — نفس آلية الرئيسية
  // (js/shared/section-badges.js)، بعد ما الأيقونة خلصت رسمها.
  const { refreshSectionBadges } = await import('../shared/section-badges.js');
  await refreshSectionBadges();
}
