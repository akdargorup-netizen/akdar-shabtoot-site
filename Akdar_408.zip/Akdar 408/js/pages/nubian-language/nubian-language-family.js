// js/pages/nubian-language/nubian-language-family.js
import { renderNubianSub, initNubianSub } from './nubian-language-sub.js';

export const renderNubianFamily = () => renderNubianSub('family');
export const initNubianFamily   = () => initNubianSub('family');
