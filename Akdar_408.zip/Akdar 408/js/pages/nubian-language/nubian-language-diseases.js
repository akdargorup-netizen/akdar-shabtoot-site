// js/pages/nubian-language/nubian-language-diseases.js
import { renderNubianSub, initNubianSub } from './nubian-language-sub.js';

export const renderNubianDiseases = () => renderNubianSub('diseases');
export const initNubianDiseases   = () => initNubianSub('diseases');
