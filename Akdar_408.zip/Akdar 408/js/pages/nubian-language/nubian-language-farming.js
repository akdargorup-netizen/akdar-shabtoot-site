// js/pages/nubian-language/nubian-language-farming.js
import { renderNubianSub, initNubianSub } from './nubian-language-sub.js';

export const renderNubianFarming = () => renderNubianSub('farming');
export const initNubianFarming   = () => initNubianSub('farming');
