// js/pages/nubian-language/nubian-language-directions.js
import { renderNubianSub, initNubianSub } from './nubian-language-sub.js';

export const renderNubianDirections = () => renderNubianSub('directions');
export const initNubianDirections   = () => initNubianSub('directions');
