// js/pages/nubian-language/nubian-word-render.js — رندر مشترك لكلمات القاموس
// ═══════════════════════════════════════════════════════════════════
// شكل عرض واحد لكل كلمات آنداندي، مستخدم في مكانين:
//  - nubian-words.js         (فهرس الـ17 تصنيف كله في صفحة واحدة)
//  - nubian-language-sub.js  (صفحة تصنيف واحد كامل)
// كانا قبل كده كل واحد عامل نسخته الخاصة من renderWordRow (تكرار) —
// اتوحّدوا هنا عشان أي تحسين على شكل الكلمة ينعكس في المكانين مرة
// وحدة، ولتصميم بصري واحد متّسق للقاموس كله.
//
// كل كلمة بقت صف واحد بعرض القائمة كاملة (مش بلاطة مربعة جوه شبكة):
// النوبي هو النجم (خط كبير بالذهبي) وتحته النطق اللاتيني على جهة
// البداية، والمعنى العربي كسياق سريع على الجهة التانية مفصول بخط.
// الكلمات اللي لسع ما اتسجل نطقها بتاخد صف بحدود متقطعة (نفس منطق
// .nlang-empty في باقي التطبيق) عشان تبان "قيد الإضافة" مش خطأ.
// المجموعات (زي "الضمائر"/"ضمائر الملكية" جوه تصنيف واحد) بتاخد عنوان
// شريطي قبل صفوفها مباشرة.
// ═══════════════════════════════════════════════════════════════════

import { escapeHtml } from '../../shared/sanitize.js';
import { buildKey } from '../../shared/arabic-search.js';
import { clipButtonHtml, clipOffHtml } from '../../shared/audio-clips.js';

function wordSearchKey(w) {
  // عربي + نوبي + لاتيني (مطبّعة: Sērēn = seren) + ملاحظة الكلمة
  return buildKey(w.ar, w.nub, w.translit, w.note);
}

function renderTile(w) {
  const isMissing  = !w.nub && !w.translit;
  const searchKey  = escapeHtml(wordSearchKey(w));

  if (isMissing) {
    return `
      <div class="nword-tile nword-tile--empty" data-search="${searchKey}">
        <span class="nword-tile__ar">${escapeHtml(w.ar)}</span>
        <span class="nword-tile__note">${escapeHtml(w.note || 'لسع ما اتسجلت')}</span>
      </div>`;
  }

  // تكديس من ثلاثة مستويات بعرض البطاقة كاملًا (لا عمود جانبي يضيّق النص): الصف الأول = المعنى العربي +
  // الكلمة النوبية بالحروف العربية (يلتفّان لسطرين لو طالا)، والصف الثاني (الذيل) = النطق اللاتيني صغيرًا
  // وخافتًا في طرف وزر «استمع» في الطرف الآخر — فلا يزدحم النص مهما طالت الكلمة.
  return `
    <div class="nword-tile nword-tile--stack" data-search="${searchKey}">
      <div class="nword-tile__main">
        <span class="nword-tile__ar">${escapeHtml(w.ar)}</span>
        <span class="nword-tile__script">${escapeHtml(w.nub)}</span>
      </div>
      <div class="nword-tile__foot">
        <span class="nword-tile__translit">${escapeHtml(w.translit || '')}</span>
        <div class="nword-tile__audio">${clipButtonHtml(w.audio) || clipOffHtml()}</div>
      </div>
    </div>`;
}

/**
 * شبكة كلمات تصنيف واحد كامل — بلاطات + عناوين مجموعات لو الكلمات
 * فيها حقل group. لو التصنيف لسع بدون كلمات إطلاقاً، بترجع بلاطة
 * واحدة بعرض الشبكة بدل شبكة فاضية.
 */
export function renderWordGrid(words) {
  if (!words.length) {
    return `
      <div class="nword-grid">
        <div class="nword-tile nword-tile--empty nword-tile--wide" data-search="">
          <span class="nword-tile__note">الكلمات لسع ما اتضافت</span>
        </div>
      </div>`;
  }

  let lastGroup = null;
  const tiles = words.map(w => {
    const groupHeader = (w.group && w.group !== lastGroup)
      ? `<div class="nword-group-header">${escapeHtml(w.group)}</div>`
      : '';
    lastGroup = w.group || lastGroup;
    return groupHeader + renderTile(w);
  }).join('');

  return `<div class="nword-grid">${tiles}</div>`;
}
