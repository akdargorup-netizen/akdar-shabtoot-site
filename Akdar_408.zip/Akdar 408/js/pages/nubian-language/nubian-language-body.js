// js/pages/nubian-language/nubian-language-body.js
import { renderNubianSub, initNubianSub } from './nubian-language-sub.js';

export const renderNubianBody = () => renderNubianSub('body');
export const initNubianBody   = () => initNubianSub('body');
