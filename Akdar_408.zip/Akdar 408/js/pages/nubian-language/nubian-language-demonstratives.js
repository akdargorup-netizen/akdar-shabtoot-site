// js/pages/nubian-language/nubian-language-demonstratives.js
import { renderNubianSub, initNubianSub } from './nubian-language-sub.js';

export const renderNubianDemonstratives = () => renderNubianSub('demonstratives');
export const initNubianDemonstratives   = () => initNubianSub('demonstratives');
