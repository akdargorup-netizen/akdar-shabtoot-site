// js/pages/nubian-language/nubian-language-home.js
import { renderNubianSub, initNubianSub } from './nubian-language-sub.js';

export const renderNubianHome = () => renderNubianSub('home');
export const initNubianHome   = () => initNubianSub('home');
