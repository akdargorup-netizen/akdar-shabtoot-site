// js/pages/nubian-language/nubian-language-place.js
import { renderNubianSub, initNubianSub } from './nubian-language-sub.js';

export const renderNubianPlace = () => renderNubianSub('place');
export const initNubianPlace   = () => initNubianSub('place');
