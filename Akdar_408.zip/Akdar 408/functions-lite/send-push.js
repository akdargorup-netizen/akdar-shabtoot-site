// functions-lite/send-push.js — شبتوت بحري
// ══════════════════════════════════════════════════════════════
//  يشتغل جوّه GitHub Actions بس (مش في المتصفح ولا على الموبايل).
//  بيقرا كل الاشتراكات من Supabase (جدول push_subscriptions) ويبعت لكل
//  واحد منهم إشعار Push حقيقي عبر web-push (VAPID القياسي).
//
//  المدخلات (كلها من متغيرات البيئة، مجهّزة من send-notification.yml):
//  - VAPID_PUBLIC_KEY / VAPID_PRIVATE_KEY : زوج مفاتيح Push
//  - SUPABASE_URL                         : رابط المشروع (https://xxxx.supabase.co)
//  - SUPABASE_SERVICE_ROLE_KEY            : المفتاح السري (Secret key) — يتخطّى RLS، للسيرفر فقط
//  - NOTIF_TITLE / NOTIF_BODY / NOTIF_PAGE / NOTIF_TYPE: محتوى الرسالة
//    (NOTIF_TYPE يُستخدم في service-worker.js على جهاز المستخدم لفلترة
//    الإشعار حسب تصنيفه المفضّل في صفحة "الرسائل" — لو فاضي، يظهر دايمًا)
//
//  (v400) صار يتحمّل آلاف المشتركين: الإرسال بتزامن محدود (PUSH_CONCURRENCY، الافتراضي 40، الأقصى 200)
//  بدل فتح آلاف الاتصالات دفعة واحدة، ومهلة لكل إرسال، وإعادة محاولة تحترم Retry-After، وتهدئة مشتركة
//  عند 429، وميزانية وقت (PUSH_BUDGET_MIN، الافتراضي 25 دقيقة) فلا يعلق التشغيل.
// ══════════════════════════════════════════════════════════════

const webpush = require('web-push');

// ── Supabase REST (بدون مكتبات): قراءة الاشتراكات وحذف المنتهي منها ──
const SUPABASE_URL = (process.env.SUPABASE_URL || '').replace(/\/+$/, '');
const SUPABASE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY || '';

function sbHeaders() {
  const h = { apikey: SUPABASE_KEY };
  // المفاتيح القديمة (JWT) تُرسل أيضًا كـBearer؛ المفاتيح الجديدة sb_secret_ تكفيها apikey
  if (SUPABASE_KEY.startsWith('eyJ')) h.Authorization = `Bearer ${SUPABASE_KEY}`;
  return h;
}

async function fetchAllSubscriptions() {
  const rows = [];
  const PAGE = 1000;
  for (let offset = 0; ; offset += PAGE) {
    const res = await fetch(
      `${SUPABASE_URL}/rest/v1/push_subscriptions?select=device_id,subscription&order=device_id&limit=${PAGE}&offset=${offset}`,
      { headers: sbHeaders(), signal: AbortSignal.timeout(30000) },
    );
    if (!res.ok) throw new Error(`قراءة الاشتراكات فشلت: ${res.status} ${await res.text()}`);
    const page = await res.json();
    rows.push(...page);
    if (page.length < PAGE) return rows;
  }
}

async function deleteSubscription(deviceId) {
  await fetch(`${SUPABASE_URL}/rest/v1/push_subscriptions?device_id=eq.${encodeURIComponent(deviceId)}`, {
    method: 'DELETE', headers: sbHeaders(), signal: AbortSignal.timeout(15000),
  });
}

async function main() {
  const title = process.env.NOTIF_TITLE || 'شبتوت بحري';
  const body  = process.env.NOTIF_BODY  || '';
  const page  = process.env.NOTIF_PAGE  || '';
  const type  = process.env.NOTIF_TYPE  || '';

  if (!body) {
    console.log('[send-push] لا يوجد محتوى رسالة — تم التجاهل');
    return;
  }

  if (!SUPABASE_URL || !SUPABASE_KEY) {
    throw new Error('SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY غير مضبوطين في أسرار GitHub');
  }

  // ── تهيئة web-push بمفاتيح VAPID ──
  webpush.setVapidDetails(
    'mailto:akdargorup@gmail.com',
    process.env.VAPID_PUBLIC_KEY,
    process.env.VAPID_PRIVATE_KEY
  );

  // ── جلب كل الاشتراكات ──
  const rows = await fetchAllSubscriptions();
  console.log(`[send-push] عدد الاشتراكات: ${rows.length}`);
  if (rows.length === 0) {
    // تنبيه ظاهر في ملخّص تشغيل GitHub: الإرسال "نجح" لكن لا أحد سيستلم
    console.log('::warning title=لا توجد اشتراكات::جدول push_subscriptions فارغ — لن يصل أي إشعار خارجي. راجع PUSH-NOTIFICATIONS.md (قسم التشخيص).');
  }

  // id فريد لكل رسالة: الـservice worker بيبني منه tag الإشعار. من غيره كان الـtag
  // مبني على (العنوان+النص+اليوم) فرسالتين بنفس النص في يوم واحد بيستبدلوا بعض.
  const payload = JSON.stringify({ title, body, page, type, id: String(Date.now()) });

  // خيارات الإرسال — من غيرها أندرويد (خصوصًا الأجهزة الضعيفة/وضع توفير الطاقة) كان بيأخّر
  // الإشعار أو بيتجاهله لحد ما الشاشة تتفتح:
  //  - urgency 'high' : يصحّي الجهاز فورًا (بدل 'normal' الافتراضي اللي بيخضع لـDoze)
  //  - TTL            : المدة اللي خدمة الدفع تحتفظ فيها بالرسالة لو الجهاز أوفلاين (أسبوع)
  //  - timeout        : لا يعلق اتصال واحد بطيء على بقية الإرسال
  const sendOptions = { TTL: 7 * 24 * 60 * 60, urgency: 'high', timeout: 15000 };

  // منع التكرار: نفس الجهاز ممكن يكون ليه أكتر من مستند اشتراك بنفس الـendpoint.
  const seen = new Set();
  const targets = [];
  for (const row of rows) {
    const sub = row.subscription;
    if (!sub || !sub.endpoint || seen.has(sub.endpoint)) continue;
    seen.add(sub.endpoint);
    targets.push({ id: row.device_id, sub });
  }

  const CONCURRENCY = Math.min(200, Math.max(1, Number(process.env.PUSH_CONCURRENCY) || 40));
  const BUDGET_MS = (Number(process.env.PUSH_BUDGET_MIN) || 25) * 60 * 1000;
  const startedAt = Date.now();
  let pauseUntil = 0;           // تهدئة مشتركة: خدمة الدفع قالت «أبطئ» (429) فيتوقف الجميع قليلًا
  let sent = 0, failed = 0, cleaned = 0, skipped = 0, done = 0;
  const failuresByStatus = {};
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  async function sendOne(sub) {
    // حتى 3 محاولات للأخطاء المؤقتة (٥xx / ٤٢٩ / شبكة)، مع احترام Retry-After (بحد أقصى 30 ثانية)
    for (let attempt = 1; ; attempt++) {
      try {
        const wait = pauseUntil - Date.now();
        if (wait > 0) await sleep(wait);
        await webpush.sendNotification(sub, payload, sendOptions);
        return;
      } catch (err) {
        const code = err.statusCode;
        const transient = !code || code === 429 || code >= 500;
        if (!transient || attempt >= 3) throw err;
        const ra = Number(err.headers && (err.headers['retry-after'] || err.headers['Retry-After']));
        const delay = Math.min(30000, Number.isFinite(ra) && ra > 0 ? ra * 1000 : 2000 * attempt);
        if (code === 429) pauseUntil = Math.max(pauseUntil, Date.now() + delay);
        await sleep(delay);
      }
    }
  }

  let cursor = 0;
  async function worker() {
    while (cursor < targets.length) {
      if (Date.now() - startedAt > BUDGET_MS) { skipped += targets.length - cursor; cursor = targets.length; return; }
      const { id, sub } = targets[cursor++];
      try {
        await sendOne(sub);
        sent++;
      } catch (err) {
        failed++;
        const statusCode = err.statusCode || 'network';
        failuresByStatus[statusCode] = (failuresByStatus[statusCode] || 0) + 1;
        // 404/410 = الاشتراك انتهت صلاحيته أو الجهاز شال التطبيق — ننظفه
        if (statusCode === 404 || statusCode === 410) {
          await deleteSubscription(id).catch(() => {});
          cleaned++;
        } else if (failuresByStatus[statusCode] <= 10) {
          console.error(`[send-push] فشل إرسال لاشتراك ${id} (${statusCode}):`, err.message);
        }
      }
      if (++done % 500 === 0) console.log(`[send-push] تقدّم: ${done}/${targets.length}`);
    }
  }
  await Promise.all(Array.from({ length: Math.min(CONCURRENCY, targets.length) }, worker));

  console.log(`[send-push] تم: ${sent} ناجح، ${failed} فاشل (${cleaned} منها اشتراكات منتهية تم تنظيفها)${skipped ? `، ${skipped} لم يُرسل (انتهت ميزانية الوقت)` : ''}`);
  if (skipped) console.log(`::warning title=إشعار لم يصل للجميع::${skipped} اشتراكًا لم يُرسل لهم لانتهاء ميزانية الوقت — ارفع PUSH_CONCURRENCY أو PUSH_BUDGET_MIN.`);
  if (failed) console.log('[send-push] الفشل حسب الكود:', JSON.stringify(failuresByStatus));
  if (targets.length > 0 && sent === 0) {
    // كل الإرسالات فشلت (غالبًا مفاتيح VAPID غير متطابقة 401/403): نُفشل التشغيل ليظهر أحمر
    console.log('::error title=فشل كل الإرسالات::راجع الكود أعلاه — 401/403 تعني VAPID_PUBLIC_KEY/VAPID_PRIVATE_KEY غير متطابقين مع المفتاح في push.js.');
    process.exitCode = 1;
  }
}

main().catch((err) => {
  console.error('[send-push] خطأ عام:', err);
  process.exit(1);
});
