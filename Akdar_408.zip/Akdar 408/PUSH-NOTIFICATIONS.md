# الإشعارات الخارجية (Push) — دليل التشغيل والتشخيص

## كيف تعمل (السلسلة كاملة)
1. **الجهاز يشترك:** `js/shared/push.js` ← `pushManager.subscribe` بمفتاح `VAPID_PUBLIC_KEY` ← يرفع الاشتراك لـ Supabase عبر `rpc('register_push_subscription')` إلى جدول `push_subscriptions` (المفتاح: `device_id`).
2. **المشرف يرسل:** لوحة الإدارة ← `sendPush` ← دالة Supabase `send-notification` (تقبل owner فقط أو `X-Push-Key`) ← GitHub `repository_dispatch`.
3. **GitHub Actions** (`.github/workflows/send-notification.yml`) ← `functions-lite/send-push.js` يقرأ كل الاشتراكات ويرسل بـ `web-push`.
4. **الجهاز يستلم:** `service-worker.js` (حدث `push`) يعرض الإشعار.

## الأسرار والمفاتيح (لا تغيّرها بلا سبب)
| أين | الاسم | ملاحظة |
|---|---|---|
| GitHub Secrets | `VAPID_PUBLIC_KEY` / `VAPID_PRIVATE_KEY` | زوج واحد؛ العام يطابق الثابت `VAPID_PUBLIC_KEY` في `js/shared/push.js` حرفًا بحرف. تغييرهما يُبطل **كل** الاشتراكات. احتفظ بنسخة خارج المشروع. |
| GitHub Secrets | `SUPABASE_URL` / `SUPABASE_SERVICE_ROLE_KEY` | يُحدَّثان إن دُوِّر مفتاح Supabase. |
| Supabase | جدول `user_roles` | حساب المشرف يحتاج دور `owner` ليقبل الإرسال. |

## ما يمنع تكرار العطل (طُبّق في Akdar_324/325)
- **العلاج الذاتي:** عند كل فتح للتطبيق (والإذن ممنوح) يُعاد رفع الاشتراك لـ Supabase (upsert بنفس `device_id`). كان العطل أن علمًا محليًا (`push_subscription_uploaded`) يقنع الجهاز أنه مسجّل بينما الجدول فارغ.
- **أخطاء ظاهرة:** فشل الاشتراك/الرفع يعرض نص الخطأ في toast (١٠ ثوانٍ).
- **المرسل يتكلم:** تشغيل بلا اشتراكات يعطي `warning` أصفر في GitHub Actions؛ وفشل كل الإرسالات يعطي `error` أحمر.

## قائمة التحقق بعد أي نشر كبير
1. افتح التطبيق على هاتفك مرتين.
2. `select device_id, updated_at from push_subscriptions;` ← يجب صف على الأقل. (العمود `updated_at` لا `created_at`.)
3. أرسل رسالة من لوحة الإدارة والتطبيق **مغلق** ← يجب أن يصل إشعار خارجي.
4. في Actions: `عدد الاشتراكات` > 0 و`ناجح` > 0.

## التشخيص السريع
| العَرَض | السبب المرجّح | العلاج |
|---|---|---|
| `عدد الاشتراكات: 0` | لا جهاز مسجّل | افتح التطبيق؛ فعّل الإشعارات من الإعدادات ← الرسائل؛ اقرأ toast الخطأ؛ تحقق من `EXECUTE` للدالة. |
| `فاشل` بكود 401/403 | VAPID العام/الخاص غير متطابقين | اجعل سر GitHub العام = ثابت `push.js`؛ ثم يعيد كل جهاز الاشتراك (ارفع مفاتيح التخزين). |
| `404/410` | اشتراك منتهٍ | يُنظَّف تلقائيًا ويُعاد عند فتح التطبيق. |
| اللوحة تقول «اتحفظت جوّا التطبيق بس» | الحساب بلا دور `owner` | `select * from user_roles;` |
| لا يصل رغم `1 ناجح` | إعدادات الهاتف (توفير البطارية/كتم Chrome) أو iOS بلا «إضافة للشاشة الرئيسية» | راجع إعدادات الإشعارات للموقع في المتصفح. |

## استعلامات مفيدة (Supabase SQL Editor)
```sql
select device_id, updated_at from push_subscriptions;
select pg_get_functiondef(oid), proacl from pg_proc where proname = 'register_push_subscription';
select id, email, is_anonymous, last_sign_in_at from auth.users order by created_at desc;
select * from user_roles;
```

## بعد تغيير جذري (إفراغ الجدول/نقل المشروع/تبديل VAPID)
ارفع مفتاحي `UPLOADED_KEY` و`UPLOADED_AT_KEY` في `push.js` إلى `_v3` (وما بعده) وارفع `CACHE_VERSION`، فتعيد الأجهزة تسجيل نفسها.


## الإشعارات لا تصل والتطبيق مغلق تمامًا (Android)
المرسل يستخدم `urgency: high` و`TTL` أسبوع (راجع `functions-lite/send-push.js`)، فالمشكلة غالبًا في الهاتف نفسه لا في الخادم:
- **إيقاف إجباري (Force stop):** بعده لا يستلم التطبيق أي إشعار حتى يُفتح يدويًا مرة أخرى.
- **تقييد البطارية/منظّفات الذاكرة** (Phone Master في تكنو، Security في شاومي، Device care في سامسونج): تقتل التطبيق وتمنع إيقاظه.
- لا يوجد أي كود ويب يتجاوز هذه القيود؛ الحل إعدادات الهاتف. أضفنا للمستخدم شرحًا خطوة بخطوة داخل
  **الإعدادات ← الرسائل ← «الإشعارات ما بتوصلني لمن أقفل التطبيق»** (ملف `settings-notifications.js`).
- للاختبار: أرسل رسالة والتطبيق مقفول بالسحب من آخر التطبيقات (بدون إيقاف إجباري)، ثم بعد تحسين إعدادات البطارية.
- لو بقيت أجهزة معينة لا تستلم رغم ذلك فالبدائل خارج الويب (تطبيق أصلي أو واتساب/رسائل نصية).
