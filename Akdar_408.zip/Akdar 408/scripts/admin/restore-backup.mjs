// scripts/admin/restore-backup.mjs — شبتوت بحري
// ══════════════════════════════════════════════════════════════
//  يستعيد ملف نسخة احتياطية كاملًا (كل الجداول بما فيها الأفكار والتعليقات والمناسبات والإعدادات) إلى مشروع
//  Supabase — غالبًا مشروع جديد بعد توقّف القديم — بمفتاح الخدمة الذي يتجاوز سياسات الحماية.
//  لا يحذف شيئًا أبدًا. الجداول يجب أن تكون منشأة أصلًا (شغّل ملفات SQL/migrations في المشروع الجديد أولًا).
//
//  الاستخدام (Node 18+):
//    SUPABASE_URL=https://xxxx.supabase.co SUPABASE_SERVICE_ROLE_KEY=... \
//      node scripts/admin/restore-backup.mjs <ملف-النسخة.json> [--update] [--tables=news,events] [--dry-run]
//
//  --update  يستبدل الموجود بنفس الرقم (الافتراضي: يضيف الجديد فقط ويتجاهل الموجود)
//  --tables  قائمة أقسام محددة (الافتراضي: كلها)
//  --dry-run يعرض ما سيُرسل دون إرسال
//  مفتاحا الإعدادات cache_stamps و urgentAnnouncement لا يُستعادان أبدًا (حالة حيّة لا محتوى).
//  بعد الاستعادة في مشروع جديد: غيّر SUPABASE_URL/SUPABASE_KEY في js/data/supabase-client.js وانشر.
// ══════════════════════════════════════════════════════════════

import fs from 'node:fs';

const args = process.argv.slice(2);
const file = args.find((a) => !a.startsWith('--'));
const UPDATE = args.includes('--update');
const DRY = args.includes('--dry-run');
const ONLY = args.find((a) => a.startsWith('--tables='))?.split('=')[1]?.split(',').filter(Boolean) || null;
const BASE = (process.env.SUPABASE_URL || '').replace(/\/+$/, '');
const KEY = process.env.SUPABASE_SERVICE_ROLE_KEY || '';
const BATCH = 100, MAX_ROWS = 50000;

const IMPORT_ORDER = ['events', 'news', 'notifications', 'history_articles', 'association_journey_articles', 'gallery',
  'memory_videos', 'projects', 'project_milestones', 'contacts', 'worship_lectures', 'study_tips', 'study_videos',
  'nubian_phrase_categories', 'nubian_words', 'nubian_phrases', 'ideas', 'idea_comments', 'occasions',
  'occasion_comments', 'settings'];
const NEVER_KEYS = new Set(['cache_stamps', 'urgentAnnouncement']);

if (!file) { console.error('الاستخدام: node scripts/admin/restore-backup.mjs <ملف-النسخة.json> [--update] [--dry-run]'); process.exit(1); }
if (!DRY && (!BASE || !KEY)) { console.error('❌ حدّد SUPABASE_URL و SUPABASE_SERVICE_ROLE_KEY كمتغيّرات بيئة.'); process.exit(1); }

let snap;
try { snap = JSON.parse(fs.readFileSync(file, 'utf8')); } catch (e) { console.error(`❌ تعذّرت قراءة الملف: ${e.message}`); process.exit(1); }
if (!snap?.tables || typeof snap.tables !== 'object') { console.error('❌ ليس ملف نسخة احتياطية (لا يوجد tables).'); process.exit(1); }

const pkOf = (t) => (t === 'settings' ? 'key' : 'id');
const headers = { apikey: KEY, 'Content-Type': 'application/json' };
if (KEY.startsWith('eyJ')) headers.Authorization = `Bearer ${KEY}`;
const prefer = (UPDATE ? 'resolution=merge-duplicates' : 'resolution=ignore-duplicates') + ',return=minimal';

const dropCol = (rows, c) => rows.map((r) => { const { [c]: _x, ...rest } = r; return rest; });

async function writeBatch(table, rows) {
  const dropped = new Set();
  let cur = rows;
  for (let i = 0; i < 8; i++) {
    const res = await fetch(`${BASE}/rest/v1/${table}?on_conflict=${pkOf(table)}`, {
      method: 'POST', headers: { ...headers, Prefer: prefer }, body: JSON.stringify(cur), signal: AbortSignal.timeout(60000),
    });
    if (res.ok) return [...dropped];
    const text = await res.text();
    let j = {}; try { j = JSON.parse(text); } catch { /* نص */ }
    const msg = String(j.message || text || '');
    const col = (j.code === 'PGRST204' ? msg.match(/'([^']+)' column/) : msg.match(/column "([^"]+)"/))?.[1];
    if (col && (j.code === 'PGRST204' || j.code === '428C9' || /generated|non-DEFAULT/i.test(msg)) && !dropped.has(col)) {
      dropped.add(col); cur = dropCol(cur, col); continue;
    }
    throw new Error(`${table}: ${msg || `HTTP ${res.status}`}`);
  }
  throw new Error(`${table}: أعمدة كثيرة غير متوافقة`);
}

let failed = 0, sentTotal = 0;
for (const table of IMPORT_ORDER) {
  if (ONLY && !ONLY.includes(table)) continue;
  const raw = snap.tables[table];
  if (!Array.isArray(raw)) continue;
  const pk = pkOf(table);
  const rows = raw.filter((r) => r && typeof r === 'object' && !Array.isArray(r) && r[pk] != null
    && !(table === 'settings' && NEVER_KEYS.has(r.key))).slice(0, MAX_ROWS);
  if (!rows.length) continue;
  if (DRY) { console.log(`  (تجريبي) ${table}: ${rows.length} صفًا`); continue; }
  let sent = 0; const dropped = new Set();
  try {
    for (let i = 0; i < rows.length; i += BATCH) {
      (await writeBatch(table, rows.slice(i, i + BATCH))).forEach((c) => dropped.add(c));
      sent = Math.min(rows.length, i + BATCH);
    }
    sentTotal += sent;
    console.log(`  ✓ ${table}: ${sent}${dropped.size ? ` (تجاوز أعمدة: ${[...dropped].join('، ')})` : ''}`);
  } catch (e) {
    failed++; sentTotal += sent;
    console.error(`  ✗ ${table}: ${e.message} (أُرسل ${sent} من ${rows.length})`);
  }
}
console.log(`\n${failed ? '⚠️' : '✅'} أُرسل ${sentTotal} صفًا${failed ? `، تعثّر ${failed} جدولًا` : ''}${DRY ? ' — تجريبي بلا تنفيذ' : ''}.`);
process.exit(failed ? 1 : 0);
