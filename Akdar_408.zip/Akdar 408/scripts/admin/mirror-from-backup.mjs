// scripts/admin/mirror-from-backup.mjs — شبتوت بحري
// ══════════════════════════════════════════════════════════════
//  «نشر المحتوى من النسخة الاحتياطية»: لو توقّفت Supabase تمامًا (أو حُجبت)، يحوّل ملف النسخة الاحتياطية
//  (من صفحة «نسخ احتياطي واستيراد») إلى ملفات المرآة واللقطات التي يقرؤها التطبيق من الاستضافة:
//      content/mirror/<جدول>.json   +   content/feed-snapshot.json
//  فيظهر المحتوى للناس من جديد دون أي قاعدة بيانات. لا يحتاج إنترنت ولا أي مفتاح.
//
//  الاستخدام (Node 18+):
//    node scripts/admin/mirror-from-backup.mjs <ملف-النسخة.json> [--root=<مجلد المشروع>]
//  بعده: ارفع CACHE_VERSION في service-worker.js وانشر المشروع (Vercel/Firebase) كالمعتاد.
//  ملاحظة: لا يكتب _stamp.json عمدًا — فيسأل التطبيق السيرفر كالمعتاد، ولو تعذّر السيرفر يعرض المرآة.
// ══════════════════════════════════════════════════════════════

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const args = process.argv.slice(2);
const file = args.find((a) => !a.startsWith('--'));
const rootArg = args.find((a) => a.startsWith('--root='))?.split('=')[1];
const ROOT = path.resolve(rootArg || path.join(path.dirname(fileURLToPath(import.meta.url)), '../..'));

if (!file) { console.error('الاستخدام: node scripts/admin/mirror-from-backup.mjs <ملف-النسخة.json>'); process.exit(1); }

let snap;
try { snap = JSON.parse(fs.readFileSync(file, 'utf8')); } catch (e) { console.error(`❌ تعذّرت قراءة الملف: ${e.message}`); process.exit(1); }
if (!snap || typeof snap !== 'object' || !snap.tables || typeof snap.tables !== 'object') {
  console.error('❌ هذا ليس ملف نسخة احتياطية من التطبيق (لا يوجد tables).'); process.exit(1);
}

const MIRROR_TABLES = [
  'history_articles', 'association_journey_articles', 'projects', 'gallery', 'contacts',
  'study_videos', 'study_tips', 'worship_lectures',
  'nubian_words', 'nubian_phrase_categories', 'nubian_phrases',
];
const NEWS_COUNT = 20, EVENTS_COUNT = 40, EXCERPT_CHARS = 300, RETENTION_DAYS_NEWS = 45;
const byDateDesc = (k) => (a, b) => String(b[k] || '').localeCompare(String(a[k] || ''));

const outDir = path.join(ROOT, 'content/mirror');
fs.mkdirSync(outDir, { recursive: true });
const exportedAt = new Date().toISOString();
let tablesDone = 0, rowsTotal = 0;
for (const table of MIRROR_TABLES) {
  const rows = snap.tables[table];
  if (!Array.isArray(rows)) { console.log(`  ↷ ${table}: غير موجود في الملف — يبقى الملف الحالي`); continue; }
  fs.writeFileSync(path.join(outDir, `${table}.json`), JSON.stringify({ version: 1, exportedAt, table, rows }));
  tablesDone++; rowsTotal += rows.length;
  console.log(`  ✓ ${table}: ${rows.length}`);
}

// لقطة الأخبار والفعاليات (نفس تحويل export-feed-snapshot.mjs)
const cutoff = new Date(Date.now() - RETENTION_DAYS_NEWS * 86400000).toISOString();
const newsAll = Array.isArray(snap.tables.news) ? snap.tables.news : null;
const eventsAll = Array.isArray(snap.tables.events) ? snap.tables.events : null;
if (newsAll && eventsAll) {
  const news = newsAll
    .filter((r) => r.archive_state !== 'archived' && (String(r.published_at || '') >= cutoff || r.archive_state === 'restored' || r.breaking === true))
    .sort(byDateDesc('published_at')).slice(0, NEWS_COUNT)
    .map((r) => ({
      id: r.id, title: r.title, source: r.source, image: r.image,
      excerpt: (Array.isArray(r.body) ? (r.body[0] || '') : '').slice(0, EXCERPT_CHARS),
      category: r.category, breaking: r.breaking, type: r.type, event_id: r.event_id,
      published_at: r.published_at, archive_state: r.archive_state ?? null, extra: r.extra || {},
    }));
  const events = [...eventsAll].sort(byDateDesc('created_at')).slice(0, EVENTS_COUNT).map((r) => ({
    id: r.id, youtube_id: r.youtube_id, category: r.category, label: r.label,
    title: r.title, date_text: r.date_text, excerpt: r.excerpt, extra: r.extra || {}, created_at: r.created_at,
  }));
  fs.writeFileSync(path.join(ROOT, 'content/feed-snapshot.json'),
    JSON.stringify({ version: 1, exportedAt, collections: { news: { docs: news }, events: { docs: events } } }));
  console.log(`  ✓ feed-snapshot: ${news.length} خبرًا، ${events.length} فعالية`);
} else {
  console.log('  ↷ feed-snapshot: الأخبار أو الفعاليات غير موجودة في الملف — تبقى اللقطة الحالية');
}
console.log(`✅ ${tablesDone} جدولًا (${rowsTotal} صفًا) من نسخة بتاريخ ${snap.exportedAt || 'غير معروف'}.`);
console.log('ℹ️ ارفع CACHE_VERSION في service-worker.js ثم انشر المشروع.');
