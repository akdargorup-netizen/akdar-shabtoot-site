// scripts/admin/export-public-mirror.mjs — شبتوت بحري
// ══════════════════════════════════════════════════════════════
//  يصدّر المحتوى العام من Supabase إلى ملفات تُشحن مع التطبيق:
//      content/mirror/<جدول>.json   ({ version, exportedAt, table, rows })
//  التطبيق لا يقرؤها والسيرفر سليم. تُطلب فقط حين تفشل قراءة الجدول (حصة نفدت، عطل، قاطع الحماية)
//  ولا نسخة محفوظة بالجهاز — فبدل صفحة الخطأ يُعرض هذا (راجع mirrorRows في sb-helpers.js).
//  تُخدَّم من الاستضافة (Firebase/Vercel) لا من Supabase، وليست ضمن CORE_ASSETS فلا تزيد وزن أول تثبيت.
//
//  الاستخدام (يحتاج Node 18+ وإنترنت، بلا أي مفتاح سري):
//    node scripts/admin/export-public-mirror.mjs [--soft]
//  - يقرأ الرابط والمفتاح العام (publishable) من js/data/supabase-client.js. القراءة بسياسات RLS نفسها
//    التي يراها أي زائر، فلا يصدّر إلا ما هو عام أصلًا.
//  - --soft: لا يفشل أبدًا ولا يوقف البناء (يُستعمل داخل build-dist.js). جدول تعذّرت قراءته يُترك ملفه القديم.
//  - SKIP_MIRROR=1 يتخطّاه كليًا.
//  يُشغَّل تلقائيًا مع كل «firebase deploy» و«deploy-vercel.sh» عبر build/build-dist.js.
// ══════════════════════════════════════════════════════════════

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = process.env.MIRROR_ROOT || path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const OUT_DIR = path.join(ROOT, 'content/mirror');
const SOFT = process.argv.includes('--soft');
const PAGE = 1000;
const MAX_ROWS = 20000;

// الجداول التي تقرؤها makeStore في supabase-library-adapter.js (لا أخبار/فعاليات: لها لقطة feed-snapshot)
const TABLES = [
  'history_articles', 'association_journey_articles', 'projects', 'gallery', 'contacts',
  'study_videos', 'study_tips', 'worship_lectures',
  'nubian_words', 'nubian_phrase_categories', 'nubian_phrases',
];

if (process.env.SKIP_MIRROR) { console.log('⏭  المرآة: تخطّي (SKIP_MIRROR)'); process.exit(0); }

const fail = (msg) => { console.error(`${SOFT ? '⚠️' : '❌'} ${msg}`); process.exit(SOFT ? 0 : 1); };

let URL_ = process.env.SUPABASE_URL, KEY = process.env.SUPABASE_KEY;
if (!URL_ || !KEY) {
  const src = fs.readFileSync(path.join(ROOT, 'js/data/supabase-client.js'), 'utf8');
  URL_ = URL_ || src.match(/SUPABASE_URL\s*=\s*'([^']+)'/)?.[1];
  KEY  = KEY  || src.match(/SUPABASE_KEY\s*=\s*'([^']+)'/)?.[1];
}
if (!URL_ || !KEY) fail('ما لقيت SUPABASE_URL/SUPABASE_KEY في js/data/supabase-client.js');

async function fetchAll(table) {
  const rows = [];
  for (let from = 0; from < MAX_ROWS; from += PAGE) {
    const res = await fetch(`${URL_}/rest/v1/${table}?select=*&order=created_at.asc&order=id.asc`, {
      headers: { apikey: KEY, Authorization: `Bearer ${KEY}`, Range: `${from}-${from + PAGE - 1}`, 'Range-Unit': 'items' },
      signal: AbortSignal.timeout(20000),
    });
    if (!res.ok && res.status !== 206) throw new Error(`HTTP ${res.status}`);
    const page = await res.json();
    rows.push(...page);
    if (page.length < PAGE) break;
  }
  return rows;
}

// أختام التغيير تُقرأ *قبل* التصدير ثم تُكتب بجانب الملفات (_stamp.json): فيعرف الجهاز الجديد أن المرآة حديثة
// (ختمها = الختم الحي) فلا يقرأ الجداول من Supabase. القراءة قبل التصدير تعني أن أي تغيير أثناءه يظهر كاختلاف فيُجلب (آمن).
// الصيغة نفسها التي يكتبها scripts/admin/mirror-ci.mjs (stamp): الأخبار والفعاليات + جداول المرآة.
async function readStamps() {
  try {
    const res = await fetch(`${URL_}/rest/v1/settings?key=eq.cache_stamps&select=data`, {
      headers: { apikey: KEY, Authorization: `Bearer ${KEY}` }, signal: AbortSignal.timeout(20000),
    });
    if (!res.ok) return null;
    const d = (await res.json())?.[0]?.data;
    return d && typeof d === 'object' && !Array.isArray(d) ? d : null;
  } catch { return null; }
}
const stampRow = await readStamps();
const stampsCheckedAt = new Date().toISOString();

fs.mkdirSync(OUT_DIR, { recursive: true });
const exportedAt = new Date().toISOString();
let ok = 0, kept = 0, total = 0;
for (const table of TABLES) {
  try {
    const rows = await fetchAll(table);
    fs.writeFileSync(path.join(OUT_DIR, `${table}.json`), JSON.stringify({ version: 1, exportedAt, table, rows }));
    ok++; total += rows.length;
    console.log(`  ✓ ${table}: ${rows.length}`);
  } catch (err) {
    kept++;
    console.log(`  ↷ ${table}: تعذّرت القراءة (${err.message}) — يبقى الملف القديم إن وُجد`);
  }
}
console.log(`${kept ? '⚠️' : '✅'} المرآة: ${ok} جدولًا (${total} صفًا)${kept ? `، ${kept} تعذّر` : ''}.`);
// الختم يُكتب فقط لو صُدِّرت كل الجداول (وإلا يبقى القديم: أقدم من الواقع = آمن، أحدث منه = يدّعي حداثة غير موجودة)
if (!kept && stampRow) {
  const stamps = Object.fromEntries(['news', 'events', ...TABLES].map((k) => [k, Number(stampRow[k]) || 0]));
  fs.writeFileSync(path.join(OUT_DIR, '_stamp.json'), JSON.stringify({ v: 1, stamps, checkedAt: stampsCheckedAt }));
  console.log('  ✓ _stamp.json');
} else if (!kept) {
  console.log('  ↷ _stamp.json: تعذّرت قراءة الأختام — يبقى القديم إن وُجد (الجهاز الجديد سيسأل السيرفر كالمعتاد)');
}
if (kept && !SOFT) process.exit(2);
