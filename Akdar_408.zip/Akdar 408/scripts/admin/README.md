# سكريبتات الإدارة — شبتوت بحري

منفصلة تماماً عن كود التطبيق (`firebase.json` يستثني `scripts/**` من النشر). لا تحتاج `npm install` — كلها Node نظيف بلا اعتماديات.

## منح صلاحية (مالك / مشرف / مشرف الرُطانة)

الصلاحيات في جدول `user_roles` على Supabase (الأعمدة: `is_owner`, `is_admin`, `is_nubian`)، وتُمنح من **SQL Editor** فقط:

```sql
insert into public.user_roles (user_id, is_owner)
select id, true from auth.users where email = 'someone@gmail.com'
on conflict (user_id) do update set is_owner = true;
```

استبدل `is_owner` بـ`is_admin` أو `is_nubian` حسب الدور، و`false` لسحبه. الشخص لازم يكون سجّل دخول بجوجل في التطبيق مرة واحدة. التطبيق يقرأ الصلاحيات فورًا (`refreshClaims`) بلا خروج/دخول.

| | مشرف (admin) | مالك (owner) |
|---|---|---|
| إضافة/تعديل المحتوى وإخفاء العناصر | ✅ | ✅ |
| الحذف النهائي وتنظيف الأرشيف | ❌ | ✅ |
| إرسال الإشعارات (دالة `send-notification`) | ❌ | ✅ |

`is_nubian` يحصر الوصول بقسم القاموس النوبي فقط.

## السكربتات

| الأمر | الوظيفة |
|---|---|
| `node export-static-snapshot.mjs` | يولّد `content/static-snapshot.json` من ملفات البذرة (القاموس والعبارات). بعده: انشر وارفع `CACHE_VERSION`. |
| `node export-feed-snapshot.mjs` | يولّد `content/feed-snapshot.json` من Supabase (يقرأ الرابط والمفتاح العام من `supabase-client.js`). |
| `SUPABASE_URL=... SUPABASE_SERVICE_KEY=... node backup-images.mjs` | نسخة احتياطية لصور bucket `akdar-images`. مفتاح `service_role` من متغير بيئة فقط، ولا يُحفظ في أي ملف. |
| `node export-public-mirror.mjs [--soft]` | يولّد `content/mirror/<جدول>.json` (المحتوى العام) احتياطًا لو تعطّل Supabase. يعمل تلقائيًا مع كل نشر عبر `build/build-dist.js`؛ `SKIP_MIRROR=1` يتخطّاه. |
