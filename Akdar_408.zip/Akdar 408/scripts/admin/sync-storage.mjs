// scripts/admin/sync-storage.mjs — شبتوت بحري
// ══════════════════════════════════════════════════════════════
//  يرمّم النسخة الاحتياطية للصور والصوت: ينسخ إلى المشروع الثاني كل ملف موجود في الأول وناقص في الثاني
//  (ما فاته النسخ لانقطاع نت وقت الرفع، أو ما رُفع قبل تفعيل الكتابة المزدوجة). لا يحذف ولا يستبدل أي ملف أبدًا.
//
//  الاستخدام (Node 18+):
//    node scripts/admin/sync-storage.mjs [--dry-run] [--max-mb=200]
//
//  المتغيرات (كلها أسرار؛ لا تُكتب في الملفات):
//    SUPABASE_URL                 عنوان المشروع الأول
//    SUPABASE_SERVICE_ROLE_KEY    مفتاحه السرّي (للقائمة فقط؛ التنزيل من الرابط العام)
//    STORAGE2_URL                 عنوان المشروع الثاني
//    STORAGE2_SERVICE_KEY         مفتاحه السرّي (للرفع)
//  لو غاب أي منها يخرج بنجاح دون عمل (تحذير) كي لا يُفشل المهمة اليومية قبل إعداد الأسرار.
//
//  --max-mb: سقف ما ينسخه في التشغيل الواحد (الافتراضي ٢٠٠ ميجا) كي لا يستهلك نقل المشروع الأول دفعة واحدة.
//  الخروج بخطأ (١) لو فشل نسخ أي ملف، لتظهر المهمة حمراء في GitHub.
// ══════════════════════════════════════════════════════════════

const BUCKETS = ['akdar-images', 'akdar-audio'];
const DRY = process.argv.includes('--dry-run');
const MAX_BYTES = (Number((process.argv.find((a) => a.startsWith('--max-mb=')) || '').split('=')[1]) || 200) * 1024 * 1024;
const PAGE = 100;

const A = (process.env.SUPABASE_URL || '').replace(/\/+$/, '');
const AK = process.env.SUPABASE_SERVICE_ROLE_KEY || '';
const B = (process.env.STORAGE2_URL || '').replace(/\/+$/, '');
const BK = process.env.STORAGE2_SERVICE_KEY || '';

if (!A || !AK || !B || !BK) {
  console.log('::warning::sync-storage: أسرار ناقصة (SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY / STORAGE2_URL / STORAGE2_SERVICE_KEY) — لا عمل.');
  process.exit(0);
}

const hdr = (key) => {
  const h = { apikey: key, 'Content-Type': 'application/json' };
  if (key.startsWith('eyJ')) h.Authorization = `Bearer ${key}`; // المفاتيح القديمة (JWT) تُرسل Bearer أيضًا
  return h;
};

/** كل الملفات (مساراتها وأحجامها) داخل bucket، بما فيها المجلدات الفرعية */
async function listAll(base, key, bucket, prefix = '') {
  const out = [];
  for (let offset = 0; ; offset += PAGE) {
    const res = await fetch(`${base}/storage/v1/object/list/${bucket}`, {
      method: 'POST', headers: hdr(key), signal: AbortSignal.timeout(30000),
      body: JSON.stringify({ prefix, limit: PAGE, offset, sortBy: { column: 'name', order: 'asc' } }),
    });
    if (!res.ok) throw new Error(`list ${bucket}/${prefix} → HTTP ${res.status}`);
    const items = await res.json();
    for (const it of items) {
      const full = prefix ? `${prefix}/${it.name}` : it.name;
      if (it.id === null || it.id === undefined) out.push(...await listAll(base, key, bucket, full)); // مجلد
      else out.push({ path: full, size: Number(it.metadata?.size) || 0, type: it.metadata?.mimetype || 'application/octet-stream' });
    }
    if (items.length < PAGE) break;
  }
  return out;
}

const enc = (p) => p.split('/').map(encodeURIComponent).join('/');
let copied = 0, copiedBytes = 0, failed = 0, skippedByCap = 0;

for (const bucket of BUCKETS) {
  let a, b;
  try { [a, b] = await Promise.all([listAll(A, AK, bucket), listAll(B, BK, bucket)]); }
  catch (e) { console.error(`❌ ${bucket}: ${e.message}`); failed++; continue; }

  const have = new Set(b.map((x) => x.path));
  // مسارات s2/ للصوت هي ملفات الثاني وحده (فيض قديم) — ليست في الأول أصلًا فلا تظهر هنا
  const missing = a.filter((x) => !have.has(x.path));
  console.log(`${bucket}: الأول ${a.length} ملفًا، الثاني ${b.length}، الناقص في الثاني ${missing.length}`);

  for (const f of missing) {
    if (copiedBytes + f.size > MAX_BYTES) { skippedByCap++; continue; }
    if (DRY) { console.log(`  (تجريبي) سيُنسخ ${bucket}/${f.path} (${f.size}B)`); continue; }
    try {
      const dl = await fetch(`${A}/storage/v1/object/public/${bucket}/${enc(f.path)}`, { signal: AbortSignal.timeout(60000) });
      if (!dl.ok) throw new Error(`تنزيل HTTP ${dl.status}`);
      const body = Buffer.from(await dl.arrayBuffer());
      const up = await fetch(`${B}/storage/v1/object/${bucket}/${enc(f.path)}`, {
        method: 'POST', signal: AbortSignal.timeout(60000), body,
        headers: { ...hdr(BK), 'Content-Type': f.type, 'x-upsert': 'false', 'cache-control': 'max-age=31536000' },
      });
      if (!up.ok && up.status !== 409) throw new Error(`رفع HTTP ${up.status}`); // 409 = وُجد (نسخه التطبيق للتو)
      copied++; copiedBytes += body.length;
      console.log(`  ✓ ${bucket}/${f.path}`);
    } catch (e) {
      failed++;
      console.error(`  ✗ ${bucket}/${f.path}: ${e.message}`);
    }
  }
}

console.log(`\nالنتيجة: نُسخ ${copied} ملفًا (${(copiedBytes / 1048576).toFixed(1)}MB)، فشل ${failed}${skippedByCap ? `، أُجّل ${skippedByCap} لتجاوز سقف ${MAX_BYTES / 1048576}MB (يُكمل في التشغيل التالي)` : ''}${DRY ? ' — تجريبي بلا تنفيذ' : ''}.`);
process.exit(failed ? 1 : 0);
