// scripts/admin/export-feed-snapshot.mjs — شبتوت بحري
// ══════════════════════════════════════════════════════════════
//  يصدّر آخر الأخبار والفعاليات من Supabase إلى ملف يُشحن مع التطبيق:
//      content/feed-snapshot.json
//  التطبيق يعرضه فورًا عند أول فتح لقسم الأخبار/الفعاليات (قبل أي كاش) ثم يحدّثه من السيرفر بالخلفية
//  (راجع _rows({ seed }) في js/data/adapters/sb-helpers.js).
//
//  الاستخدام (من أي مجلد، يحتاج Node 18+ وإنترنت — لا يحتاج أي مفتاح سري):
//    node scripts/admin/export-feed-snapshot.mjs
//  يقرأ SUPABASE_URL والمفتاح العام (publishable) من js/data/supabase-client.js، والقراءة العامة مسموحة بسياسات RLS.
//  بعده: انشر المشروع وارفع CACHE_VERSION في service-worker.js (اللقطة ضمن CORE_ASSETS).
//
//  ما يُصدَّر: أحدث ٢٠ خبرًا ضمن نافذة الاحتفاظ (مع المستعاد والعاجل، بلا المؤرشف) بأول فقرة فقط (excerpt)،
//  وأحدث ٤٠ فعالية. لا شيء خاص: كله محتوى عام أصلًا (سياسة القراءة للجميع).
//  اللقطة تشيخ: كل ما مرّ أسبوعان أعد تشغيله مع النشر العادي (والتطبيق يتجاهل منها ما تجاوز مدة الاحتفاظ).
// ══════════════════════════════════════════════════════════════

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const OUT = path.join(ROOT, 'content/feed-snapshot.json');

const NEWS_COUNT = 20;
const EVENTS_COUNT = 40;
const RETENTION_DAYS_NEWS = 45;   // نفس js/data/retention.js
const EXCERPT_CHARS = 300;        // نفس العمود المولَّد في 20261016_news_list_excerpt.sql

const clientSrc = fs.readFileSync(path.join(ROOT, 'js/data/supabase-client.js'), 'utf8');
const URL_ = process.env.SUPABASE_URL || clientSrc.match(/SUPABASE_URL\s*=\s*'([^']+)'/)?.[1];
const KEY = process.env.SUPABASE_KEY || clientSrc.match(/SUPABASE_KEY\s*=\s*'([^']+)'/)?.[1];
if (!URL_ || !KEY) { console.error('❌ ما لقيت SUPABASE_URL/SUPABASE_KEY في js/data/supabase-client.js'); process.exit(1); }

async function get(table, query) {
  const res = await fetch(`${URL_}/rest/v1/${table}?${query}`, {
    headers: { apikey: KEY, Authorization: `Bearer ${KEY}` },
    signal: AbortSignal.timeout(30000),
  });
  if (!res.ok) throw new Error(`${table}: HTTP ${res.status} — ${(await res.text()).slice(0, 200)}`);
  return res.json();
}

const cutoff = new Date(Date.now() - RETENTION_DAYS_NEWS * 86400000).toISOString();
const orFilter = `(published_at.gte.${cutoff},archive_state.eq.restored,breaking.eq.true)`;
const newsRaw = await get('news', `select=*&or=${encodeURIComponent(orFilter)}&order=published_at.desc&limit=120`);
const news = newsRaw
  .filter((r) => r.archive_state !== 'archived')
  .slice(0, NEWS_COUNT)
  .map((r) => ({
    id: r.id, title: r.title, source: r.source, image: r.image,
    excerpt: (Array.isArray(r.body) ? (r.body[0] || '') : '').slice(0, EXCERPT_CHARS),
    category: r.category, breaking: r.breaking, type: r.type, event_id: r.event_id,
    published_at: r.published_at, archive_state: r.archive_state ?? null, extra: r.extra || {},
  }));

const eventsRaw = await get('events', `select=*&order=created_at.desc&limit=${EVENTS_COUNT}`);
const events = eventsRaw.map((r) => ({
  id: r.id, youtube_id: r.youtube_id, category: r.category, label: r.label,
  title: r.title, date_text: r.date_text, excerpt: r.excerpt, extra: r.extra || {}, created_at: r.created_at,
}));

const payload = {
  version: 1,
  exportedAt: new Date().toISOString(),
  collections: { news: { docs: news }, events: { docs: events } },
};
fs.mkdirSync(path.dirname(OUT), { recursive: true });
fs.writeFileSync(OUT, JSON.stringify(payload));
console.log(`  news    ${String(news.length).padEnd(4)} خبر`);
console.log(`  events  ${String(events.length).padEnd(4)} فعالية`);
console.log(`✅ ${path.relative(process.cwd(), OUT)} (${(fs.statSync(OUT).size / 1024).toFixed(1)} KB)`);
console.log('ℹ️ انشر المشروع وارفع CACHE_VERSION في service-worker.js.');
