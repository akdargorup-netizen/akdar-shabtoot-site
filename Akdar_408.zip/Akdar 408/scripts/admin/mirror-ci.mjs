// scripts/admin/mirror-ci.mjs — شبتوت بحري
// ══════════════════════════════════════════════════════════════
//  حرّاس تجديد المرآة الآلي (يستعمله .github/workflows/refresh-mirror.yml). بلا اعتماديات ولا مفاتيح سرية.
//
//    node scripts/admin/mirror-ci.mjs stamp
//      يقارن أختام التغيير في Supabase (settings/cache_stamps) بالمنشورة على الاستضافة (content/mirror/_stamp.json).
//      تغيّر شيء من محتوى المرآة، أو مرّ أكثر من ٧ أيام، أو لا ختم منشور، أو FORCE=1 ← changed=true
//      (ويكتب _stamp.json ليُشحن مع البناء). غير ذلك ← changed=false ولا نشر.
//      أختام الأفكار والمناسبات لا تُراقَب (ليست في المرآة)، فلا نشر مع كل تعليق.
//
//    node scripts/admin/mirror-ci.mjs verify     (بعد node build/build-dist.js)
//      يمنع النشر ويفشل لو:
//       • ملف مرآة ناقص/تالف، أو جدول صار فارغًا بعد أن كان عند المنشور (علامة عطل/RLS) ، أو لقطة الأخبار بلا تاريخ تصدير.
//       • كود التطبيق المبني يختلف عن المنشور حاليًا (CACHE_VERSION أو بصمات asset-manifest خارج content/) ←
//         يعني أن المستودع ليس نفس ما نشرتَه يدويًا؛ النشر الآلي كان سيستبدل نسختك. انشر يدويًا أو ادفع الكود أولًا.
//
//  متغيرات اختيارية: LIVE_ORIGIN (الافتراضي https://akdar-nine.vercel.app)، SUPABASE_URL / SUPABASE_KEY، FORCE=1، GITHUB_OUTPUT.
// ══════════════════════════════════════════════════════════════

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const LIVE = (process.env.LIVE_ORIGIN || 'https://akdar-nine.vercel.app').replace(/\/+$/, '');
const STAMP_FILE = path.join(ROOT, 'content/mirror/_stamp.json');
const MAX_AGE_MS = 7 * 86400000;

const read = (p) => fs.readFileSync(path.join(ROOT, p), 'utf8');
const client = read('js/data/supabase-client.js');
const URL_ = process.env.SUPABASE_URL || client.match(/SUPABASE_URL\s*=\s*'([^']+)'/)?.[1];
const KEY = process.env.SUPABASE_KEY || client.match(/SUPABASE_KEY\s*=\s*'([^']+)'/)?.[1];

// جداول المرآة تُقرأ من سكربت التصدير نفسه كي لا تتباعد القائمتان
const TABLES = [...read('scripts/admin/export-public-mirror.mjs').match(/const TABLES = \[([\s\S]*?)\];/)[1].matchAll(/'([a-z_]+)'/g)].map((m) => m[1]);
const WATCH = ['news', 'events', ...TABLES];

const setOutput = (k, v) => {
  console.log(`${k}=${v}`);
  if (process.env.GITHUB_OUTPUT) fs.appendFileSync(process.env.GITHUB_OUTPUT, `${k}=${v}\n`);
};
async function getJson(url, headers = {}) {
  const res = await fetch(url, { headers, signal: AbortSignal.timeout(20000) });
  if (!res.ok) return { ok: false, status: res.status };
  return { ok: true, json: await res.json() };
}
async function getText(url) {
  const res = await fetch(url, { signal: AbortSignal.timeout(20000) });
  return res.ok ? res.text() : null;
}

const cmd = process.argv[2];

if (cmd === 'stamp') {
  if (!URL_ || !KEY) { console.error('❌ ما لقيت SUPABASE_URL/SUPABASE_KEY'); process.exit(1); }
  let row;
  try {
    row = await getJson(`${URL_}/rest/v1/settings?key=eq.cache_stamps&select=data`, { apikey: KEY, Authorization: `Bearer ${KEY}` });
  } catch (e) { row = { ok: false, status: e.message }; }
  if (!row.ok) { console.log(`⚠️ تعذّرت قراءة الأختام (${row.status}) — لا نشر (التصدير نفسه سيفشل أيضًا).`); setOutput('changed', 'false'); process.exit(0); }
  const data = row.json?.[0]?.data || {};
  const current = Object.fromEntries(WATCH.map((k) => [k, Number(data[k]) || 0]));
  if (!Object.keys(data).length) console.log('ℹ️ صف الأختام فارغ (لم يُشغَّل 20261101_cache_stamps.sql؟) — التجديد أسبوعي فقط.');

  let live = null;
  try { const r = await getJson(`${LIVE}/content/mirror/_stamp.json`); if (r.ok) live = r.json; } catch { /* لا ختم منشور */ }

  const diff = live ? WATCH.filter((k) => (Number(live.stamps?.[k]) || 0) !== current[k]) : [];
  const age = live ? Date.now() - Date.parse(live.checkedAt || 0) : Infinity;
  let reason = '';
  if (process.env.FORCE === '1') reason = 'FORCE';
  else if (!live) reason = 'لا ختم منشور (أول تشغيل)';
  else if (diff.length) reason = `تغيّر: ${diff.join(', ')}`;
  else if (!(age < MAX_AGE_MS)) reason = 'مرّ أكثر من ٧ أيام';

  if (!reason) { console.log('✅ المحتوى لم يتغيّر — لا نشر.'); setOutput('changed', 'false'); process.exit(0); }
  console.log(`🔄 يلزم التجديد — ${reason}`);
  fs.mkdirSync(path.dirname(STAMP_FILE), { recursive: true });
  fs.writeFileSync(STAMP_FILE, JSON.stringify({ v: 1, stamps: current, checkedAt: new Date().toISOString() }));
  setOutput('changed', 'true');
} else if (cmd === 'verify') {
  const DIST = path.join(ROOT, 'dist');
  const problems = [];
  const j = (p) => { try { return JSON.parse(fs.readFileSync(path.join(DIST, p), 'utf8')); } catch { return null; } };

  // ١) اكتمال المرآة ولقطة الأخبار
  for (const t of TABLES) {
    const f = j(`content/mirror/${t}.json`);
    if (!f || !Array.isArray(f.rows)) { problems.push(`مرآة ${t}: الملف ناقص أو تالف`); continue; }
    try {
      const l = await getJson(`${LIVE}/content/mirror/${t}.json`);
      if (l.ok && Array.isArray(l.json?.rows) && l.json.rows.length > 0 && f.rows.length === 0) problems.push(`مرآة ${t}: صارت فارغة بعد أن كان فيها ${l.json.rows.length} صفًا (عطل أو RLS؟)`);
    } catch { /* المنشور غير متاح: لا مقارنة */ }
  }
  const feed = j('content/feed-snapshot.json');
  if (!feed?.exportedAt || !Array.isArray(feed.collections?.news?.docs) || !Array.isArray(feed.collections?.events?.docs)) problems.push('feed-snapshot.json: بلا تاريخ تصدير أو ناقص (تعذّر تصدير الأخبار)');
  if (!j('content/mirror/_stamp.json')) problems.push('_stamp.json غير موجود في dist (شغّل stamp قبل البناء)');

  // ٢) حارس الكود: ما نبنيه = ما هو منشور (خارج content/)
  const swLive = await getText(`${LIVE}/service-worker.js`).catch(() => null);
  const vLive = swLive?.match(/const CACHE_VERSION = '([^']+)'/)?.[1];
  const vHere = read('service-worker.js').match(/const CACHE_VERSION = '([^']+)'/)?.[1];
  if (!vLive) problems.push('تعذّر قراءة service-worker.js المنشور للمقارنة');
  else if (vLive !== vHere) problems.push(`CACHE_VERSION مختلف: المنشور ${vLive} والمستودع ${vHere}`);
  const mLive = await getJson(`${LIVE}/asset-manifest.json`).catch(() => ({ ok: false }));
  const mHere = j('asset-manifest.json');
  if (!mLive.ok || !mHere) problems.push('تعذّرت قراءة asset-manifest للمقارنة');
  else {
    const fl = mLive.json.files || {}, fh = mHere.files || {};
    const keys = new Set([...Object.keys(fl), ...Object.keys(fh)]);
    const diff = [...keys].filter((k) => !k.startsWith('./content/') && fl[k] !== fh[k]);
    if (diff.length) problems.push(`كود مختلف عن المنشور في ${diff.length} ملفًا (مثل ${diff.slice(0, 3).join(', ')})`);
  }

  if (problems.length) { console.error('❌ لن يُنشر:\n - ' + problems.join('\n - ')); process.exit(1); }
  console.log(`✅ المرآة سليمة (${TABLES.length} جدولًا + الأخبار) والكود مطابق للمنشور — جاهز للنشر.`);
} else {
  console.error('الاستخدام: node scripts/admin/mirror-ci.mjs stamp|verify'); process.exit(1);
}
