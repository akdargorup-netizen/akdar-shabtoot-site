// scripts/admin/quota-check.mjs — شبتوت بحري
// ══════════════════════════════════════════════════════════════
//  مراقبة الحصص دون أن تفتح لوحة الإدارة: يقيس لكل مشروع Supabase حجم قاعدة البيانات وحجم الملفات
//  ويقارنها بحدود الخطة المجانية (supabase.com/pricing: ٥٠٠MB قاعدة، ١GB ملفات لكل مشروع).
//    ≥ 70%  تحذير (يظهر في ملخص التشغيل)        ≥ 90%  فشل التشغيل ← GitHub يرسل لك بريدًا بفشل المهمة
//  ⚠️ لا يقيس نقل البيانات (egress، حدّه ٥GB للمنظمة كلها): Supabase لا تتيحه عبر أي واجهة برمجية.
//     راجع Dashboard ← Organization ← Usage يدويًا مرة في الأسبوع.
//
//  المتغيرات: PROJECTS_JSON = [{"name":"akdar","url":"https://..","key":"<service_role/secret>"}, ...]
//  (سرّ في GitHub: QUOTA_PROJECTS_JSON). DB يحتاج ملف 20261109_quota_snapshot.sql؛ لو غاب يُقاس حجم الملفات بالتعداد.
//  الاستخدام: node scripts/admin/quota-check.mjs
// ══════════════════════════════════════════════════════════════
import fs from 'node:fs';

const LIMITS = { db: 500 * 1024 * 1024, storage: 1024 * 1024 * 1024 };
const WARN = 0.7, FAIL = 0.9;
const BUCKETS = ['akdar-images', 'akdar-audio'];
const PAGE = 100;

let projects;
try { projects = JSON.parse(process.env.PROJECTS_JSON || '[]'); } catch { projects = null; }
if (!Array.isArray(projects)) { console.error('❌ PROJECTS_JSON ليس JSON صالحًا'); process.exit(1); }
if (!projects.length) { console.log('::warning::quota-check: لا مشاريع (QUOTA_PROJECTS_JSON غير مضبوط) — لا عمل.'); process.exit(0); }

const hdr = (key) => { const h = { apikey: key, 'Content-Type': 'application/json' }; if (key.startsWith('eyJ')) h.Authorization = `Bearer ${key}`; return h; };
const mb = (b) => (b / 1048576).toFixed(1);
const pct = (v, lim) => v / lim;

async function listBytes(base, key, bucket, prefix = '') {
  let total = 0, files = 0;
  for (let offset = 0; ; offset += PAGE) {
    const res = await fetch(`${base}/storage/v1/object/list/${bucket}`, {
      method: 'POST', headers: hdr(key), signal: AbortSignal.timeout(30000),
      body: JSON.stringify({ prefix, limit: PAGE, offset, sortBy: { column: 'name', order: 'asc' } }),
    });
    if (!res.ok) throw new Error(`list ${bucket} → HTTP ${res.status}`);
    const items = await res.json();
    for (const it of items) {
      if (it.id == null) { const s = await listBytes(base, key, bucket, prefix ? `${prefix}/${it.name}` : it.name); total += s.total; files += s.files; }
      else { total += Number(it.metadata?.size) || 0; files++; }
    }
    if (items.length < PAGE) break;
  }
  return { total, files };
}

async function measure(p) {
  const base = String(p.url || '').replace(/\/+$/, '');
  const out = { name: p.name || base, db: null, storage: null, files: null, notes: [] };
  try {
    const res = await fetch(`${base}/rest/v1/rpc/akdar_quota_snapshot`, { method: 'POST', headers: hdr(p.key), body: '{}', signal: AbortSignal.timeout(30000) });
    if (res.ok) { const j = await res.json(); out.db = Number(j.db_bytes); out.storage = Number(j.storage_bytes); out.files = Number(j.storage_files); }
    else out.notes.push(`الدالة akdar_quota_snapshot غير متاحة (HTTP ${res.status}) — شغّل 20261109_quota_snapshot.sql لقياس القاعدة`);
  } catch (e) { out.notes.push(`تعذّر الاتصال: ${e.message}`); }
  if (out.storage == null) {
    try {
      let t = 0, f = 0;
      for (const b of BUCKETS) { const s = await listBytes(base, p.key, b); t += s.total; f += s.files; }
      out.storage = t; out.files = f;
    } catch (e) { out.notes.push(`تعذّر قياس الملفات: ${e.message}`); }
  }
  return out;
}

const rows = [];
let worst = 0;
for (const p of projects) {
  const m = await measure(p);
  const items = [['القاعدة', m.db, LIMITS.db], ['الملفات', m.storage, LIMITS.storage]];
  for (const [label, v, lim] of items) {
    if (v == null) { rows.push(`| ${m.name} | ${label} | غير معروف | — | ❔ |`); continue; }
    const r = pct(v, lim); worst = Math.max(worst, r);
    const icon = r >= FAIL ? '🔴' : r >= WARN ? '🟠' : '🟢';
    rows.push(`| ${m.name} | ${label} | ${mb(v)}MB من ${mb(lim)}MB | ${(r * 100).toFixed(0)}% | ${icon} |`);
    if (r >= FAIL) console.error(`::error::${m.name}: ${label} وصل ${(r * 100).toFixed(0)}% من الحد المجاني`);
    else if (r >= WARN) console.log(`::warning::${m.name}: ${label} وصل ${(r * 100).toFixed(0)}% من الحد المجاني`);
  }
  m.notes.forEach((n) => console.log(`::notice::${m.name}: ${n}`));
}
const table = ['| المشروع | المورد | الاستهلاك | النسبة | الحالة |', '|---|---|---|---|---|', ...rows].join('\n');
console.log(table);
if (process.env.GITHUB_STEP_SUMMARY) fs.appendFileSync(process.env.GITHUB_STEP_SUMMARY, `## مراقبة الحصص\n\n${table}\n\n> نقل البيانات (egress) لا يُقاس هنا — راجع Dashboard ← Organization ← Usage.\n`);
process.exit(worst >= FAIL ? 1 : 0);
