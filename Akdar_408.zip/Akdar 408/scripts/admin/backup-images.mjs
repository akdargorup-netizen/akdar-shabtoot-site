// scripts/admin/backup-images.mjs — شبتوت بحري
// ══════════════════════════════════════════════════════════════
//  نسخة احتياطية لكل الصور المرفوعة في Supabase Storage إلى جهازك.
//  الخطة المجانية ما فيها نسخ احتياطي تلقائي، فالصور التاريخية لازم
//  تنحفظ عندك بنفسك. يُشغَّل من جهازك (Node 18+) — خارج التطبيق تمامًا.
//
//  الاستخدام (من مجلد scripts/admin):
//    SUPABASE_URL="https://xxxx.supabase.co" \
//    SUPABASE_SERVICE_KEY="<service_role key>" \
//    node backup-images.mjs [--bucket=akdar-images] [--out=/المسار/المطلوب]
//
//  - الافتراضي للحفظ: ~/akdar-backup/images (خارج المشروع).
//  - service_role مفتاح سرّي: ضعه في متغير البيئة فقط، لا تكتبه في أي
//    ملف داخل المشروع (المشروع بيتنشر علنًا) ولا تشاركه مع أحد.
//    تلقاه في Supabase ← Project Settings ← API.
//  - آمن للتكرار: يتخطّى الصور المحفوظة سابقًا (نفس الاسم والحجم)،
//    فتنزل الجديد فقط. ما بيحذف شيء لا من Supabase ولا من جهازك.
//  - يكتب manifest.json فيه قائمة الملفات وأحجامها وتاريخ النسخة.
// ══════════════════════════════════════════════════════════════

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const args = Object.fromEntries(
  process.argv.slice(2).filter(a => a.startsWith('--')).map(a => {
    const [k, ...v] = a.slice(2).split('=');
    return [k, v.join('=') || true];
  })
);

const BASE   = (process.env.SUPABASE_URL || '').replace(/\/+$/, '');
const KEY    = process.env.SUPABASE_SERVICE_KEY || '';
const BUCKET = args.bucket || 'akdar-images';
const OUT    = path.resolve(String(args.out || path.join(os.homedir(), 'akdar-backup', 'images')));

if (!BASE || !KEY) {
  console.error('❌ لازم تحدد SUPABASE_URL وSUPABASE_SERVICE_KEY كمتغيرات بيئة (انظر التعليق أعلى الملف).');
  process.exit(1);
}

const headers = { apikey: KEY, Authorization: `Bearer ${KEY}`, 'Content-Type': 'application/json' };

/** يسرد محتوى مجلد واحد (مع الترقيم). العناصر بدون id هي مجلدات فرعية. */
async function listFolder(prefix) {
  const items = [];
  for (let offset = 0; ; offset += 100) {
    const res = await fetch(`${BASE}/storage/v1/object/list/${BUCKET}`, {
      method: 'POST',
      headers,
      body: JSON.stringify({ prefix, limit: 100, offset, sortBy: { column: 'name', order: 'asc' } }),
    });
    if (!res.ok) throw new Error(`فشل سرد "${prefix}" (HTTP ${res.status}) — اتأكد من الرابط والمفتاح واسم الـbucket`);
    const page = await res.json();
    items.push(...page);
    if (page.length < 100) break;
  }
  return items;
}

/** يمشي على كل المجلدات ويرجّع قائمة الملفات بمساراتها الكاملة */
async function listAll(prefix = '') {
  const files = [];
  for (const item of await listFolder(prefix)) {
    const full = prefix ? `${prefix}/${item.name}` : item.name;
    if (item.id === null || item.id === undefined) files.push(...await listAll(full)); // مجلد
    else files.push({ path: full, size: item.metadata?.size ?? null });
  }
  return files;
}

async function download(file) {
  const dest = path.join(OUT, ...file.path.split('/'));
  if (file.size != null && fs.existsSync(dest) && fs.statSync(dest).size === file.size) return 'skipped';
  const res = await fetch(`${BASE}/storage/v1/object/${BUCKET}/${file.path.split('/').map(encodeURIComponent).join('/')}`, { headers });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  fs.writeFileSync(dest, Buffer.from(await res.arrayBuffer()));
  return 'downloaded';
}

console.log(`▶ النسخ الاحتياطي من bucket "${BUCKET}" إلى ${OUT}\n`);
const files = await listAll();
if (!files.length) { console.log('ℹ️ الـbucket فاضي — لا شيء للنسخ.'); process.exit(0); }

let downloaded = 0, skipped = 0;
const failed = [];
for (const [i, f] of files.entries()) {
  try {
    const r = await download(f);
    if (r === 'downloaded') downloaded++; else skipped++;
  } catch (err) {
    failed.push(`${f.path} (${err.message})`);
  }
  if ((i + 1) % 25 === 0) console.log(`  ... ${i + 1}/${files.length}`);
}

fs.mkdirSync(OUT, { recursive: true });
fs.writeFileSync(path.join(OUT, 'manifest.json'), JSON.stringify({
  bucket: BUCKET, backedUpAt: new Date().toISOString(), count: files.length, files,
}, null, 2));

console.log(`\n✅ انتهى — جديد: ${downloaded} | موجود سابقًا: ${skipped} | إجمالي في الـbucket: ${files.length}`);
if (failed.length) {
  console.log(`⚠️ فشل ${failed.length}:\n  - ${failed.join('\n  - ')}\n  أعد التشغيل لمحاولة الباقي.`);
  process.exit(2);
}
