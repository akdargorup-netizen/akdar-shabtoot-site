// scripts/admin/export-static-snapshot.mjs — شبتوت بحري
// ══════════════════════════════════════════════════════════════
//  يصدّر محتوى القاموس والعبارات (ثابت تقريبًا) إلى ملف JSON يُشحن مع التطبيق:
//      content/static-snapshot.json
//  التطبيق يقرأ الملف مباشرة (supabase-library-adapter.js) قبل أي طلب شبكة.
//
//  الاستخدام (من مجلد scripts/admin):
//    node export-static-snapshot.mjs   ← من ملفات البذرة (js/data) — بدون مفتاح ولا إنترنت.
//  بعد التصدير: انشر المشروع وارفع CACHE_VERSION في service-worker.js.
//
//  جهات الاتصال مستثناة عمدًا (بيانات وهمية هتتغير).
// ══════════════════════════════════════════════════════════════

import { fileURLToPath, pathToFileURL } from 'node:url';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR = path.resolve(HERE, '../../js/data');
const OUT = path.resolve(HERE, '../../content/static-snapshot.json');
const COLLECTIONS = ['nubianWords', 'nubianPhraseCategories', 'nubianPhrases'];

async function fromSeed() {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'shabtoot-snap-'));
  try {
    fs.writeFileSync(path.join(tmp, 'package.json'), '{"type":"module"}');
    for (const f of ['nubian-language-data.js', 'nubian-phrases-data.js']) {
      fs.copyFileSync(path.join(DATA_DIR, f), path.join(tmp, f));
    }
    const load = f => import(pathToFileURL(path.join(tmp, f)).href);
    const [nubian, phrases] = await Promise.all([load('nubian-language-data.js'), load('nubian-phrases-data.js')]);

    const words = nubian.NUBIAN_LANGUAGE_CATEGORIES.flatMap(cat =>
      (cat.words || []).map((w, i) => ({
        id: `${cat.key}-${String(i + 1).padStart(3, '0')}`, ...w, category: cat.key,
      })));
    const categories = phrases.NUBIAN_PHRASE_CATEGORIES_SEED.map(c => ({ id: String(c.key), title: c.title, icon: c.icon }));
    const items = phrases.NUBIAN_PHRASES_SEED.map((p, i) => {
      const { id, ...rest } = p;
      return { id: String(id ?? `phrase-${String(i + 1).padStart(3, '0')}`), ...rest };
    });
    return {
      nubianWords: { stamp: 0, docs: words },
      nubianPhraseCategories: { stamp: 0, docs: categories },
      nubianPhrases: { stamp: 0, docs: items },
    };
  } finally {
    fs.rmSync(tmp, { recursive: true, force: true });
  }
}

const collections = await fromSeed();
const payload = {
  version: 1,
  source: 'seed',
  exportedAt: new Date().toISOString(),
  collections,
};
fs.mkdirSync(path.dirname(OUT), { recursive: true });
fs.writeFileSync(OUT, JSON.stringify(payload));
for (const name of COLLECTIONS) {
  console.log(`  ${name.padEnd(26)} ${String(collections[name].docs.length).padEnd(5)} مستند | ختم ${collections[name].stamp}`);
}
console.log(`✅ ${path.relative(process.cwd(), OUT)} (${(fs.statSync(OUT).size / 1024).toFixed(1)} KB) — المصدر: ${payload.source}`);
console.log('ℹ️ انشر المشروع وارفع CACHE_VERSION في service-worker.js.');
process.exit(0);
