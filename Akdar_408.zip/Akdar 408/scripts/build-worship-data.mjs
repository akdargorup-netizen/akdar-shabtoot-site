// scripts/build-worship-data.mjs — شبتوت بحري
// ══════════════════════════════════════════════════════════════
//  يقرأ content/worship-content.json (أحاديث + قصص) ويولّد منه
//  ملفّي البيانات اللي بتقراهم صفحة العبادة:
//      js/data/worship-hadith-data.js   ← "hadith"
//      js/data/worship-story-data.js    ← "stories"
//
//  الاستخدام (من مجلد المشروع، في Termux أو أي جهاز فيه Node):
//      node scripts/build-worship-data.mjs            # يتحقق + يولّد + يرفع نسخة الكاش
//      node scripts/build-worship-data.mjs --check    # تحقق فقط، بدون كتابة أي ملف
//      node scripts/build-worship-data.mjs --no-bump  # يولّد بدون تغيير CACHE_VERSION
//      node scripts/build-worship-data.mjs --dump     # عكسي: يستخرج البيانات الحالية للـJSON
//
//  المولّد بيستبدل مصفوفة البيانات بس (بين `export const ... = [` و`];`)
//  ويسيب باقي الملف (الشرح، السياسة التحريرية، منطق الاختيار) كما هو —
//  فلا تعدّل المصفوفتين يدويًا: أي تعديل يدوي هناك هيتمسح عند التوليد.
// ══════════════════════════════════════════════════════════════

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const ROOT = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
const CONTENT = path.join(ROOT, 'content', 'worship-content.json');
const SW = path.join(ROOT, 'service-worker.js');

const TARGETS = {
  hadith: {
    file: path.join(ROOT, 'js/data/worship-hadith-data.js'),
    constName: 'WORSHIP_HADITH',
    prefix: 'h',
    fields: ['text', 'source', 'sharh'],
    labels: { text: 'نص الحديث', source: 'المصدر', sharh: 'الشرح' },
  },
  stories: {
    file: path.join(ROOT, 'js/data/worship-story-data.js'),
    constName: 'WORSHIP_STORIES',
    prefix: 's',
    fields: ['title', 'story', 'wisdom'],
    labels: { title: 'العنوان', story: 'نص القصة', wisdom: 'الحكمة' },
    allowEmpty: true, // ⟲ أكتوبر ٢٠٢٦: تصفير "قصة اليوم" — الودجت بتختفي لما القائمة فاضية
  },
};

const args = new Set(process.argv.slice(2));

// ── استخراج المصفوفة من ملف JS موجود ───────────────────────────
function arrayBounds(src, constName) {
  const start = src.indexOf(`export const ${constName} = [`);
  if (start === -1) throw new Error(`ما لقيت "export const ${constName} = [" في الملف`);
  const end = src.indexOf('\n];', start);
  if (end === -1) throw new Error(`ما لقيت نهاية مصفوفة ${constName}`);
  return { start, end: end + 3 };
}

// ── --dump: من الملفات الحالية إلى JSON ─────────────────────────
async function dump() {
  if (fs.existsSync(CONTENT) && !args.has('--force')) {
    console.error('❌ content/worship-content.json موجود أصلًا. استخدم --dump --force لو عايز تستبدله.');
    process.exit(1);
  }
  const out = {};
  for (const [key, t] of Object.entries(TARGETS)) {
    const mod = await import(pathToFileURL(t.file).href);
    out[key] = mod[t.constName].map(item => Object.fromEntries(t.fields.map(f => [f, item[f]])));
  }
  fs.mkdirSync(path.dirname(CONTENT), { recursive: true });
  fs.writeFileSync(CONTENT, JSON.stringify(out, null, 2) + '\n', 'utf8');
  console.log(`✅ اتكتب ${path.relative(ROOT, CONTENT)} (${out.hadith.length} حديث، ${out.stories.length} قصة)`);
}

// ── التحقق ─────────────────────────────────────────────────────
function validate(data) {
  const errors = [];
  const warnings = [];

  for (const [key, t] of Object.entries(TARGETS)) {
    const list = data[key];
    if (!Array.isArray(list)) { errors.push(`"${key}" لازم يكون قائمة []`); continue; }
    if (!list.length && !t.allowEmpty) errors.push(`"${key}" فاضية — الصفحة محتاجة عنصر واحد على الأقل`);

    const seen = new Map();
    list.forEach((item, i) => {
      const where = `${key}[${i + 1}]`;
      if (typeof item !== 'object' || item === null) { errors.push(`${where}: مش كائن {}`); return; }

      for (const f of t.fields) {
        const v = item[f];
        if (typeof v !== 'string' || !v.trim()) errors.push(`${where}: حقل "${f}" (${t.labels[f]}) فاضي أو مفقود`);
      }
      const known = new Set([...t.fields, 'id']);
      for (const f of Object.keys(item)) if (!known.has(f)) warnings.push(`${where}: حقل غير معروف "${f}" — هيتجاهل`);

      // تكرار: نفس النص الأساسي مرتين
      const main = String(item[t.fields[0]] || '').replace(/\s+/g, ' ').trim();
      if (main) {
        if (seen.has(main)) warnings.push(`${where}: نفس نص ${where.replace(/\[\d+\]/, `[${seen.get(main)}]`)} (تكرار؟)`);
        else seen.set(main, i + 1);
      }
      if (item.id !== undefined && !/^[A-Za-z0-9_-]+$/.test(String(item.id))) errors.push(`${where}: id غير صالح ("${item.id}")`);

      const long = key === 'hadith' ? item.sharh : item.story;
      if (typeof long === 'string' && long.length > 1200) warnings.push(`${where}: نص طويل (${long.length} حرف) — الكارت هيطول على الجوال`);
    });

    const ids = list.map(x => x && x.id).filter(Boolean).map(String);
    ids.filter((id, i) => ids.indexOf(id) !== i).forEach(id => errors.push(`${key}: id مكرر "${id}"`));
  }
  return { errors, warnings };
}

// ── التوليد ────────────────────────────────────────────────────
function render(t, list) {
  const pad = String(list.length).length < 3 ? 3 : String(list.length).length;
  const items = list.map((item, i) => {
    const id = item.id ? String(item.id) : `${t.prefix}${String(i + 1).padStart(pad, '0')}`;
    const lines = [`    id: ${JSON.stringify(id)},`];
    for (const f of t.fields) lines.push(`    ${f}: ${JSON.stringify(String(item[f]).trim())},`);
    return `  {\n${lines.join('\n')}\n  },`;
  });
  return `export const ${t.constName} = [\n${items.join('\n')}\n];`;
}

function bumpCache() {
  const s = fs.readFileSync(SW, 'utf8');
  const m = s.match(/const CACHE_VERSION = '([A-Za-z-]*?)(\d+)';/);
  if (!m) { console.warn('⚠️ ما لقيت CACHE_VERSION في service-worker.js — ارفعه يدويًا'); return; }
  const next = `${m[1]}${Number(m[2]) + 1}`;
  fs.writeFileSync(SW, s.replace(m[0], `const CACHE_VERSION = '${next}';`), 'utf8');
  console.log(`🔄 CACHE_VERSION: ${m[1]}${m[2]} → ${next}`);
}

async function main() {
  if (args.has('--dump')) return dump();

  if (!fs.existsSync(CONTENT)) {
    console.error('❌ ما لقيت content/worship-content.json — شغّل الأول: node scripts/build-worship-data.mjs --dump');
    process.exit(1);
  }
  let data;
  try { data = JSON.parse(fs.readFileSync(CONTENT, 'utf8')); }
  catch (e) { console.error(`❌ JSON غير صالح: ${e.message}\n   (غالبًا فاصلة ناقصة/زايدة أو علامة تنصيص " جوّه النص من غير \\ قبلها)`); process.exit(1); }

  const { errors, warnings } = validate(data);
  warnings.forEach(w => console.warn(`⚠️  ${w}`));
  if (errors.length) {
    errors.forEach(e => console.error(`❌ ${e}`));
    console.error(`\nما اتكتب أي ملف — صلّح الأخطاء (${errors.length}) وأعد المحاولة.`);
    process.exit(1);
  }
  if (args.has('--check')) {
    console.log(`✅ سليم: ${data.hadith.length} حديث، ${data.stories.length} قصة (تحقق فقط — ما اتكتب شيء)`);
    return;
  }

  for (const [key, t] of Object.entries(TARGETS)) {
    const src = fs.readFileSync(t.file, 'utf8');
    const { start, end } = arrayBounds(src, t.constName);
    fs.writeFileSync(t.file, src.slice(0, start) + render(t, data[key]) + src.slice(end), 'utf8');
    console.log(`✅ ${path.relative(ROOT, t.file)} ← ${data[key].length} عنصر`);
  }
  if (!args.has('--no-bump')) bumpCache();
}

main().catch(e => { console.error('❌', e.message); process.exit(1); });
