// app.js — شبتوت بحري
import { navigateTo, hasPage }   from './js/core/router.js';
import { initAuth }              from './js/data/auth.js';
import { refreshNotifBadge }     from './js/shared/notif-badge.js';
import { initSectionBadges }     from './js/shared/section-badges.js';
import { initIOSInstallPrompt }  from './js/shared/ios-install-prompt.js';
import { initPermissionOnboarding } from './js/shared/permission-onboarding.js';
import { listenForMessages, syncPushSubscription } from './js/shared/push.js';
import { initKeyboardScroll }    from './js/shared/keyboard-scroll.js';
import { initAppSplash }         from './js/shared/app-splash.js';
import { initTheme }             from './js/shared/theme.js';
import { initHostFailover }      from './js/data/hosts.js';

// بدء عدّاد الشاشة الانتقالية فورًا (أول سطر) — مستقل تمامًا عن باقي
// التهيئة تحت، عشان توقيتها يفضل ثابت وقصير زي ما هو مقصود بالظبط.
initAppSplash();

// ─── بدء جلسة المستخدم (محلية الآن، Firebase لاحقاً) ─────────────────
// غير حاجبة عمداً: لا تؤخّر أول رسم للصفحة.
initAuth();

// تبديل المضيف تلقائيًا لو فشل أول تثبيت بسبب نفاد حصة المضيف الحالي (غير حاجب)
initHostFailover();

// ─── تطبيق الإعدادات المحفوظة قبل أي render ─────────────────────────
(function applyStoredSettings() {
  // حجمان: "عادي" (24.75px — الافتراضي) و"كبير" (27.5px). القيم القديمة: large/xlarge → كبير، وغير المحفوظ → عادي.
  const textSize = localStorage.getItem('app-text-size');
  const vision   = localStorage.getItem('vision-enhanced') === 'true';

  initTheme();   // data-theme + data-scheme (المحلولة) + لون شريط الحالة + متابعة تغيّر إعداد الجهاز

  const normalizedTextSize = (textSize === 'large' || textSize === 'xlarge') ? 'large' : 'normal';
  document.documentElement.setAttribute('data-text-size', normalizedTextSize);

  if (vision) document.documentElement.setAttribute('data-vision', 'enhanced');
})();

// المحمّل في index.html يبدأ app.js بعد جاهزية DOM (وقد يكون DOMContentLoaded مرّ): نشغّل مباشرة في هذه الحالة
const _onReady = (fn) => (document.readyState === 'loading' ? document.addEventListener('DOMContentLoaded', fn, { once: true }) : fn());
_onReady(() => {
  const hash      = location.hash.replace('#', '').trim();
  const startPage = (hash && hasPage(hash)) ? hash : 'home';
  navigateTo(startPage, false);
  initKeyboardScroll();

  // ⚡ أداء: باقي التهيئة (شارات، إشعارات، push، نوافذ الإذن) مش لازمة لأول رسم،
  // وبتنافس الإنترو على المعالج والشبكة وقت أول ثانية. نأجّلها لحد ما الإنترو
  // يكمل أول ثانية ويكون المتصفح فاضي (requestIdleCallback مع مهلة قصوى).
  const runSecondaryInit = () => {
    window.__akdarReady = true; // يلغي رسالة أول تشغيل (index.html) لو لسه ما ظهرتش
    refreshNotifBadge();
    initSectionBadges();
    initPermissionOnboarding();
    initIOSInstallPrompt();
    listenForMessages();
    syncPushSubscription(); // لو الإذن ممنوح ولا يوجد اشتراك مرفوع — يكمّله في الخلفية
    // عمليات إدارة اتسجّلت وقت انقطاع النت؟ حمّل وحدة الطابور عشان ترفعها لوحدها لما النت يرجع
    try {
      const q = localStorage.getItem('sbb:admin-batch-queue');
      if (q && q.length > 2) import('./js/shared/admin-batch.js').catch(() => {});
    } catch { /* اختياري */ }
    // تعليقات (مناسبات/أفكار) معلّقة من جلسة سابقة؟ نحمّل الطابور ليرسلها في الخلفية حتى لو لم يفتح المستخدم صفحتها
    try {
      const pending = ['akdar_occasion_comment_outbox', 'akdar_idea_comment_outbox'].some((k) => (localStorage.getItem(k) || '{}').length > 2);
      if (pending) import('./js/shared/comment-outbox.js').catch(() => {});
    } catch { /* اختياري */ }
    // إعجابات/أصوات (مناسبات/أفكار) معلّقة من جلسة سابقة؟ نفس الفكرة
    try {
      if ((localStorage.getItem('akdar_reaction_outbox') || '{}').length > 2) import('./js/shared/reaction-outbox.js').catch(() => {});
    } catch { /* اختياري */ }
  };
  setTimeout(() => {
    if ('requestIdleCallback' in window) requestIdleCallback(runSecondaryInit, { timeout: 1500 });
    else runSecondaryInit();
  }, 1000);

  scheduleOfflineWarmup();
  requestPersistentStorage();
});

// ⚡ باقي ملفات التطبيق (صفحات/خطوط/صور) ما تُحمَّل أثناء تثبيت الـ service worker
// (كانت تنافس الصفحة على الشبكة). نطلب من الـ SW يسخّنها في الخلفية بعد الإقلاع بفترة،
// ونتخطّى وضع توفير البيانات والشبكات البطيئة (تتخزّن هناك عند أول استخدام فقط).
// (v386) التسخين ملف واحد في كل مرة، ويتوقف تلقائيًا ما دام المستخدم يلمس الشاشة أو
// يتنقّل (يستأنف بعد ٦ ثوانٍ هدوء) — بإنترنت القرية الضعيف لا يزاحم تصفّحه أبدًا.
// (v472) تسخين على مراحل بحسب اليوم لا الجلسة: يوم أول فتح = الأساسي فقط (~٢١٦KB) + ما يفتحه المستخدم،
// وأول عودة في يوم آخر = تسخين كامل (انظر WARM_RARE_RE في service-worker.js). السبب: حد نقل Firebase
// المجاني يومي (٣٦٠MB)، وفي يوم الإطلاق يفتح كثيرون التطبيق أكثر من مرة؛ كان كل فتح ثانٍ يضيف ~٤٥٠KB.
// الآن يتوزّع التسخين على الأيام التالية بحسب عودة كل مستخدم، والعمل بدون إنترنت يكتمل لمن يعود فعلًا.
function _warmDue() {
  try {
    const today = new Date().toLocaleDateString('en-CA'); // YYYY-MM-DD بتوقيت الجهاز
    let first = localStorage.getItem('akdar:first-day');
    if (!first) {
      // جهاز من إصدار سابق (له عدّاد جلسات) = استُخدم قبل اليوم → يُعامَل كعائد
      first = localStorage.getItem('akdar:sessions') ? '0000-00-00' : today;
      localStorage.setItem('akdar:first-day', first);
    }
    return first !== today;
  } catch { return false; }
}

// يطلب من المتصفح عدم مسح كاش الصور والصوت عند امتلاء ذاكرة الهاتف (أجهزة القرية محدودة المساحة).
// Chrome يمنحه تلقائيًا للتطبيق المثبّت/المستخدَم، ويُطلب بعد أول تفاعل حقيقي لا عند الإقلاع. طلب واحد لكل جلسة، وبلا أي واجهة.
function requestPersistentStorage() {
  try {
    if (!navigator.storage || !navigator.storage.persist) return;
    const ask = async () => {
      window.removeEventListener('pointerdown', ask, true);
      try { if (!(await navigator.storage.persisted())) await navigator.storage.persist(); } catch { /* تحسين فقط */ }
    };
    window.addEventListener('pointerdown', ask, { once: true, capture: true, passive: true });
  } catch { /* */ }
}

function scheduleOfflineWarmup() {
  const fullWarm = _warmDue();
  // (v456/v472) يوم أول فتح: لا تسخين خلفي إطلاقًا (الباقي يُخزَّن عند أول استخدام). التسخين الكامل عند أول عودة في يوم آخر.
  if (!fullWarm) return;
  if (!('serviceWorker' in navigator)) return;
  const conn = navigator.connection;
  if (conn && (conn.saveData || /(^|-)2g$/.test(conn.effectiveType || ''))) return;

  const send = (type) => navigator.serviceWorker.ready
    .then(reg => { if (reg.active) reg.active.postMessage(type === 'WARM_CACHE' ? { type, full: fullWarm } : { type }); })
    .catch(() => { /* لا شيء: التخزين بالاستخدام يكفي */ });

  let started = false;
  let paused = false;
  let resumeTimer = null;
  const onActivity = () => {
    if (!started) return;
    if (!paused) { paused = true; send('WARM_PAUSE'); }
    clearTimeout(resumeTimer);
    resumeTimer = setTimeout(() => { paused = false; send('WARM_RESUME'); }, 6000);
  };
  ['pointerdown', 'touchstart', 'keydown', 'scroll'].forEach(ev =>
    window.addEventListener(ev, onActivity, { passive: true, capture: true }));

  const go = () => { started = true; send('WARM_CACHE'); };
  setTimeout(() => {
    if ('requestIdleCallback' in window) requestIdleCallback(go, { timeout: 5000 });
    else go();
  }, 8000);
}

// ملاحظة: معالج popstate (زر/جستشر رجوع الجهاز) انتقل لداخل
// js/core/router.js نفسه — عشان يكون عنده وصول مباشر لـ history_stack
// الداخلية ويستخدم بالظبط نفس مسار سهم الرجوع في الهيدر (goBack).
