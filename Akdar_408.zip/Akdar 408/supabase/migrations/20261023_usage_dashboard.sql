-- supabase/migrations/20261023_usage_dashboard.sql — شبتوت بحري
-- لوحة الاستهلاك للإدارة: عدّاد يومي دائم لاستدعاءات المساعد + أحجام الجداول وقاعدة البيانات.
-- شغّله في SQL Editor. آمن لو أعدت تشغيله.

-- ١) عدّاد المساعد (تكتبه دالة ask بـservice_role؛ لا وصول مباشر لأحد غيرها)
create table if not exists public.ai_usage (
  day              date primary key,
  route            int not null default 0,   -- استدعاءات التوجيه إلى Gemini
  ask              int not null default 0,   -- استدعاءات الإجابة إلى Gemini
  cache_hit        int not null default 0,   -- إجابات من الكاش (لم تستهلك Gemini)
  route_cache_hit  int not null default 0
);
alter table public.ai_usage enable row level security;
revoke all on public.ai_usage from anon, authenticated;

create or replace function public.ai_usage_bump(p_kind text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if p_kind not in ('route','ask','cache_hit','route_cache_hit') then return; end if;
  insert into public.ai_usage(day) values ((now() at time zone 'utc')::date) on conflict (day) do nothing;
  execute format('update public.ai_usage set %I = %I + 1 where day = (now() at time zone ''utc'')::date', p_kind, p_kind);
end $$;
revoke all on function public.ai_usage_bump(text) from public, anon, authenticated;
grant execute on function public.ai_usage_bump(text) to service_role;

-- ٢) إحصاءات للوحة (المشرف/المالك فقط): المساعد اليوم + آخر ٧ أيام + حجم القاعدة + أكبر الجداول
create or replace function public.akdar_usage_stats() returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare
  today_row jsonb; week_row jsonb; tables jsonb; db_bytes bigint;
begin
  if not public.akdar_is_admin() then raise exception 'not_allowed'; end if;

  select to_jsonb(u) into today_row from public.ai_usage u where day = (now() at time zone 'utc')::date;
  select jsonb_build_object('route', coalesce(sum(route),0), 'ask', coalesce(sum(ask),0),
                            'cache_hit', coalesce(sum(cache_hit),0))
    into week_row from public.ai_usage where day > (now() at time zone 'utc')::date - 7;

  select pg_database_size(current_database()) into db_bytes;

  select coalesce(jsonb_agg(t order by (t->>'bytes')::bigint desc), '[]'::jsonb) into tables from (
    select jsonb_build_object('name', c.relname, 'bytes', pg_total_relation_size(c.oid), 'rows', greatest(c.reltuples,0)::bigint) as t
    from pg_class c join pg_namespace n on n.oid = c.relnamespace
    where n.nspname = 'public' and c.relkind = 'r'
    order by pg_total_relation_size(c.oid) desc limit 8
  ) s;

  return jsonb_build_object('ai_today', coalesce(today_row, '{}'::jsonb), 'ai_week', week_row,
                            'db_bytes', db_bytes, 'tables', tables);
end $$;
revoke all on function public.akdar_usage_stats() from public, anon;
grant execute on function public.akdar_usage_stats() to authenticated;
