-- supabase/migrations/20261020_ai_cache.sql — شبتوت بحري
-- كاش دائم لإجابات المساعد (دالة ask): يبقى بعد إعادة تشغيل الدالة فلا يتكرر السؤال على Gemini.
-- يقرأ ويكتب فيه service_role فقط (من الدالة)؛ RLS مفعّل بلا أي سياسة = مغلق على anon/authenticated.
-- آمن لو أعدت تشغيله.

create table if not exists public.ai_cache (
  key        text primary key,
  value      jsonb not null,
  expires_at timestamptz not null
);
create index if not exists ai_cache_expires_idx on public.ai_cache (expires_at);

alter table public.ai_cache enable row level security;
revoke all on public.ai_cache from anon, authenticated;

-- حذف المنتهي (تستدعيه الدالة أحيانًا عند الكتابة)
create or replace function public.ai_cache_purge() returns void
language sql security definer set search_path = public as $$
  delete from public.ai_cache where expires_at < now();
$$;
revoke all on function public.ai_cache_purge() from public, anon, authenticated;
grant execute on function public.ai_cache_purge() to service_role;
