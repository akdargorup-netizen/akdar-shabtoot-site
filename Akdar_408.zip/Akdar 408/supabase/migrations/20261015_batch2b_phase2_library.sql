-- supabase/migrations/20261015_batch2b_phase2_library.sql — شبتوت بحري
-- ══════════════════════════════════════════════════════════════
--  الدفعة ٢ب — المرحلة ٢: ذاكرة الصوت، التاريخ، مسيرة الرابطة، المشاريع،
--  المعرض، دليل الاتصال، قاموس الرُطانة وتعلّم الكلام.
--  شغّله بعد ملف المرحلة ١ (يعتمد على دوال akdar_is_* وakdar_touch_updated_at).
--  آمن لو أعدت تشغيله.
--
--  الصلاحيات مطابقة لقواعد Firestore القديمة:
--    • القراءة: للجميع.
--    • الإضافة والتعديل: مشرف/مالك — عدا القاموس والعبارات (+ مشرف الرُطانة is_nubian)
--      ودليل الاتصال (المالك فقط، لأنه يشمل جهات الطوارئ).
--    • الحذف النهائي: المالك فقط (في كل الجداول).
--  المعرّفات نصية لتبقى معرّفات Firestore. الترتيب بـcreated_at (ينقله سكربت النسخ من createTime).
-- ══════════════════════════════════════════════════════════════

create table if not exists public.memory_videos (
  id text primary key default gen_random_uuid()::text,
  youtube_id text not null default '', category text not null default 'other', label text not null default '',
  title text not null default '', narrator text not null default '', date_text text not null default '', excerpt text not null default '',
  extra jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);

-- مقالات التاريخ ومسيرة الرابطة: نفس الشكل (type يفرّق: 'history' | 'association')
create table if not exists public.history_articles (
  id text primary key default gen_random_uuid()::text,
  type text not null default 'history', section text not null default '', category text not null default '',
  title text not null default '', source text not null default '', date_text text not null default '', image text not null default '',
  body text[] not null default '{}', important boolean not null default false,
  extra jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);

create table if not exists public.association_journey_articles (
  id text primary key default gen_random_uuid()::text,
  type text not null default 'association', section text not null default '', category text not null default '',
  title text not null default '', source text not null default '', date_text text not null default '', image text not null default '',
  body text[] not null default '{}', important boolean not null default false,
  extra jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);

create table if not exists public.projects (
  id text primary key default gen_random_uuid()::text,
  title text not null default '', status text not null default 'planned', progress numeric not null default 0,
  image text not null default '', description text not null default '',
  executors jsonb not null default '[]'::jsonb, contributors jsonb not null default '[]'::jsonb,
  contribution_methods jsonb not null default '[]'::jsonb,
  finance jsonb,                                  -- null = الجانب المالي غير مفعّل
  extra jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);

create table if not exists public.gallery (
  id text primary key default gen_random_uuid()::text,
  title text not null default '', source text not null default '', excerpt text not null default '',
  category text not null default '', label text not null default '', image text not null default '',
  extra jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);

create table if not exists public.contacts (
  id text primary key default gen_random_uuid()::text,
  name text not null default '', role text, phone text,
  category_key text not null default '', category text not null default '',
  ai_public boolean not null default false,       -- يظهر للمساعد الذكي (aiPublic)
  extra jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);

create table if not exists public.nubian_words (
  id text primary key default gen_random_uuid()::text,
  category text not null default '', ar text not null default '', nub text not null default '',
  translit text not null default '', grp text not null default '',   -- grp = الحقل group (كلمة محجوزة)
  note text not null default '',
  extra jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);

create table if not exists public.nubian_phrase_categories (
  id text primary key default gen_random_uuid()::text,                -- id = key في التطبيق
  title text not null default '', icon text not null default 'message-square',
  extra jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);

create table if not exists public.nubian_phrases (
  id text primary key default gen_random_uuid()::text,
  category text not null default '',               -- مفتاح التصنيف (nubian_phrase_categories.id)
  ar text not null default '', nub text not null default '', translit text not null default '', note text not null default '',
  extra jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);

create index if not exists history_section_idx  on public.history_articles (section, created_at desc);
create index if not exists journey_section_idx  on public.association_journey_articles (section, created_at desc);
create index if not exists contacts_cat_idx     on public.contacts (category_key);
create index if not exists nubian_words_cat_idx on public.nubian_words (category);
create index if not exists nubian_phr_cat_idx   on public.nubian_phrases (category);

-- ── المحفّزات + RLS + الصلاحيات (حلقة واحدة بدل التكرار) ──
do $$
declare
  t text;
  write_check text;
begin
  foreach t in array array[
    'memory_videos','history_articles','association_journey_articles','projects','gallery',
    'contacts','nubian_words','nubian_phrase_categories','nubian_phrases'
  ] loop
    execute format('drop trigger if exists %I on public.%I', t || '_touch', t);
    execute format('create trigger %I before update on public.%I for each row execute function public.akdar_touch_updated_at()', t || '_touch', t);
    execute format('alter table public.%I enable row level security', t);

    write_check := case
      when t = 'contacts' then 'public.akdar_is_owner()'
      when t in ('nubian_words','nubian_phrase_categories','nubian_phrases') then '(public.akdar_is_admin() or public.akdar_is_nubian())'
      else 'public.akdar_is_admin()'
    end;

    execute format('drop policy if exists %I on public.%I', t || '_read', t);
    execute format('drop policy if exists %I on public.%I', t || '_insert', t);
    execute format('drop policy if exists %I on public.%I', t || '_update', t);
    execute format('drop policy if exists %I on public.%I', t || '_delete', t);
    execute format('create policy %I on public.%I for select using (true)', t || '_read', t);
    execute format('create policy %I on public.%I for insert with check (%s)', t || '_insert', t, write_check);
    execute format('create policy %I on public.%I for update using (%s) with check (%s)', t || '_update', t, write_check, write_check);
    execute format('create policy %I on public.%I for delete using (public.akdar_is_owner())', t || '_delete', t);

    execute format('grant select on public.%I to anon, authenticated', t);
    execute format('grant insert, update, delete on public.%I to authenticated', t);
  end loop;
end $$;
