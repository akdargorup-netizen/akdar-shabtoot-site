-- supabase/migrations/20261109_quota_snapshot.sql — شبتوت بحري
-- لقطة الاستهلاك لمراقبة الحصص (scripts/admin/quota-check.mjs): حجم قاعدة البيانات وحجم الملفات.
-- تُستدعى بمفتاح الخدمة فقط (service_role). آمنة لو أعدت تشغيلها. شغّلها في SQL Editor في كل مشروع تراقبه.
create or replace function public.akdar_quota_snapshot() returns jsonb
language sql stable security definer set search_path = public, storage as $$
  select jsonb_build_object(
    'db_bytes', pg_database_size(current_database()),
    'storage_bytes', coalesce((select sum((metadata->>'size')::bigint) from storage.objects), 0),
    'storage_files', (select count(*) from storage.objects)
  );
$$;
revoke all on function public.akdar_quota_snapshot() from public, anon, authenticated;
grant execute on function public.akdar_quota_snapshot() to service_role;
