-- supabase/migrations/20261103_ai_provider_usage.sql — شبتوت بحري
-- مراقبة حصة الذكاء الاصطناعي لكل مزوّد: كم نجح/كم اصطدم بالحصة/كم فشل اليوم،
-- ومتى آخر مرة نفدت حصته، وآخر قيمة متبقية أبلغ عنها المزوّد (Groq يرسلها في ترويسات الرد).
-- تكتبه دالة ask بـservice_role فقط، وتقرؤه دالة ask نفسها لصفحة «الذكاء الاصطناعي» في الإدارة.
-- شغّله في SQL Editor. آمن لو أعدت تشغيله.

create table if not exists public.ai_provider_usage (
  day            date not null,
  provider       text not null,
  ok             int  not null default 0,   -- طلبات بدأ فيها المزوّد بإرسال نص
  quota          int  not null default 0,   -- فشل بسبب الحصة (429)
  fail           int  not null default 0,   -- أي فشل آخر (مفتاح، نموذج، مهلة، عطل)
  last_quota_at  timestamptz,
  rl_limit       int,                       -- آخر سقف طلبات أبلغ عنه المزوّد (إن أبلغ)
  rl_remaining   int,                       -- آخر متبقٍّ أبلغ عنه المزوّد
  rl_reset       text,                      -- نص تجدّد الحصة كما أرسله المزوّد (مثل 2m59s)
  rl_seen_at     timestamptz,
  primary key (day, provider)
);

alter table public.ai_provider_usage enable row level security;
revoke all on public.ai_provider_usage from anon, authenticated;

create or replace function public.ai_provider_bump(
  p_provider     text,
  p_outcome      text,
  p_rl_limit     int  default null,
  p_rl_remaining int  default null,
  p_rl_reset     text default null
) returns void
language plpgsql security definer set search_path = public as $$
declare
  d date := (now() at time zone 'utc')::date;
  prov text := left(coalesce(p_provider, ''), 80);
begin
  if prov = '' or p_outcome not in ('ok', 'quota', 'fail') then return; end if;

  insert into public.ai_provider_usage(day, provider, ok, quota, fail, last_quota_at,
                                       rl_limit, rl_remaining, rl_reset, rl_seen_at)
  values (d, prov,
          (p_outcome = 'ok')::int, (p_outcome = 'quota')::int, (p_outcome = 'fail')::int,
          case when p_outcome = 'quota' then now() end,
          p_rl_limit, p_rl_remaining, left(p_rl_reset, 40),
          case when p_rl_remaining is not null or p_rl_limit is not null then now() end)
  on conflict (day, provider) do update set
    ok            = public.ai_provider_usage.ok    + (p_outcome = 'ok')::int,
    quota         = public.ai_provider_usage.quota + (p_outcome = 'quota')::int,
    fail          = public.ai_provider_usage.fail  + (p_outcome = 'fail')::int,
    last_quota_at = case when p_outcome = 'quota' then now() else public.ai_provider_usage.last_quota_at end,
    rl_limit      = coalesce(p_rl_limit,     public.ai_provider_usage.rl_limit),
    rl_remaining  = coalesce(p_rl_remaining, public.ai_provider_usage.rl_remaining),
    rl_reset      = coalesce(left(p_rl_reset, 40), public.ai_provider_usage.rl_reset),
    rl_seen_at    = case when p_rl_remaining is not null or p_rl_limit is not null
                         then now() else public.ai_provider_usage.rl_seen_at end;

  -- تنظيف دوري خفيف: نحتفظ بـ٣٠ يومًا فقط
  if random() < 0.01 then
    delete from public.ai_provider_usage where day < d - 30;
  end if;
end $$;

revoke all on function public.ai_provider_bump(text, text, int, int, text) from public, anon, authenticated;
grant execute on function public.ai_provider_bump(text, text, int, int, text) to service_role;
