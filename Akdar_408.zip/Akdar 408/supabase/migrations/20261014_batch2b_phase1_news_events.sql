-- supabase/migrations/20261014_batch2b_phase1_news_events.sql — شبتوت بحري
-- ══════════════════════════════════════════════════════════════
--  الدفعة ٢ب — المرحلة ١: الأخبار + الفعاليات
--  شغّله مرة واحدة من Supabase → SQL Editor (آمن لو أعدت تشغيله).
--
--  الصلاحيات مطابقة لقواعد Firestore القديمة:
--    • القراءة: للجميع (حتى الزائر المجهول).
--    • الإضافة والتعديل: مشرف (is_admin) أو مالك (is_owner).
--    • الحذف النهائي: المالك فقط.
--  المعرّفات نصية (text) كي تبقى معرّفات Firestore القديمة كما هي
--  (روابط الأخبار، وربط الخبر بفعالية eventId، وأهداف الإشعارات).
-- ══════════════════════════════════════════════════════════════

-- ── دوال الصلاحيات (security definer: تقرأ user_roles بغضّ النظر عن RLS عليه) ──
create or replace function public.akdar_is_owner() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles r where r.user_id = auth.uid() and r.is_owner is true);
$$;

create or replace function public.akdar_is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles r
                 where r.user_id = auth.uid() and (r.is_admin is true or r.is_owner is true));
$$;

create or replace function public.akdar_is_nubian() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles r where r.user_id = auth.uid() and r.is_nubian is true);
$$;

grant execute on function public.akdar_is_owner(), public.akdar_is_admin(), public.akdar_is_nubian()
  to anon, authenticated;

-- ── محدّث updated_at (مشترك لكل جداول المحتوى) ──
create or replace function public.akdar_touch_updated_at() returns trigger
language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

-- ══════════════════════════════════════════════════════════════
--  الأخبار
-- ══════════════════════════════════════════════════════════════
create table if not exists public.news (
  id            text primary key default gen_random_uuid()::text,
  title         text        not null default '',
  source        text        not null default '',
  image         text        not null default '',
  body          text[]      not null default '{}',      -- فقرات الخبر
  category      text        not null default 'general',
  breaking      boolean     not null default false,
  type          text        not null default 'news',
  event_id      text        not null default '',        -- ربط اختياري بفعالية (events.id)
  published_at  timestamptz not null default now(),
  archive_state text,                                   -- null | 'archived' | 'restored'
  extra         jsonb       not null default '{}'::jsonb, -- أي حقل غير معروف من Firestore
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

create index if not exists news_published_idx on public.news (published_at desc);
create index if not exists news_breaking_idx  on public.news (published_at desc) where breaking;

drop trigger if exists news_touch on public.news;
create trigger news_touch before update on public.news
  for each row execute function public.akdar_touch_updated_at();

alter table public.news enable row level security;

drop policy if exists news_read   on public.news;
drop policy if exists news_insert on public.news;
drop policy if exists news_update on public.news;
drop policy if exists news_delete on public.news;
create policy news_read   on public.news for select using (true);
create policy news_insert on public.news for insert with check (public.akdar_is_admin());
create policy news_update on public.news for update using (public.akdar_is_admin()) with check (public.akdar_is_admin());
create policy news_delete on public.news for delete using (public.akdar_is_owner());

-- ══════════════════════════════════════════════════════════════
--  الفعاليات (فيديوهات يوتيوب)
-- ══════════════════════════════════════════════════════════════
create table if not exists public.events (
  id          text primary key default gen_random_uuid()::text,
  youtube_id  text        not null default '',
  category    text        not null default 'social',
  label       text        not null default '',
  title       text        not null default '',
  date_text   text        not null default '',          -- تاريخ العرض كنص حر (مثل "١٥ رمضان")
  excerpt     text        not null default '',
  extra       jsonb       not null default '{}'::jsonb,
  created_at  timestamptz not null default now(),       -- الأحدث أولاً (بدل ترتيب المعرّف النصي في Firestore)
  updated_at  timestamptz not null default now()
);

create index if not exists events_created_idx on public.events (created_at desc);

drop trigger if exists events_touch on public.events;
create trigger events_touch before update on public.events
  for each row execute function public.akdar_touch_updated_at();

alter table public.events enable row level security;

drop policy if exists events_read   on public.events;
drop policy if exists events_insert on public.events;
drop policy if exists events_update on public.events;
drop policy if exists events_delete on public.events;
create policy events_read   on public.events for select using (true);
create policy events_insert on public.events for insert with check (public.akdar_is_admin());
create policy events_update on public.events for update using (public.akdar_is_admin()) with check (public.akdar_is_admin());
create policy events_delete on public.events for delete using (public.akdar_is_owner());

-- ── صلاحيات الجداول لدور الـAPI (RLS هي الحارس الفعلي) ──
grant select on public.news, public.events to anon, authenticated;
grant insert, update, delete on public.news, public.events to authenticated;
