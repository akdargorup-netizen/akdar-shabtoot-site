-- للفحص فقط (ما يغيّر شيء): شغّله وابعت لي النتيجة. يعرض سياسات الجداول الحساسة.
select tablename, policyname, cmd, roles, qual as using_expr, with_check
from pg_policies
where schemaname = 'public'
  and tablename in ('inbox_messages','member_moderation','settings','notifications','user_roles','activity_log')
order by tablename, cmd, policyname;

-- جداول RLS فيها مقفول (لازم تكون كلها true):
select relname, relrowsecurity as rls_on
from pg_class c join pg_namespace n on n.oid = c.relnamespace
where n.nspname = 'public' and c.relkind = 'r' order by relrowsecurity, relname;
