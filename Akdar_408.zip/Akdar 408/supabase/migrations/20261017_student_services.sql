-- supabase/migrations/20261017_student_services.sql — شبتوت بحري
-- ══════════════════════════════════════════════════════════════
--  خدمات الطلاب: فيديوهات الحصص (روابط يوتيوب) + النصائح الأكاديمية.
--  شغّله بعد ملفات الدفعة ٢ب (يعتمد على akdar_is_admin / akdar_is_owner / akdar_touch_updated_at).
--  آمن لو أعدت تشغيله. نفس صلاحيات باقي مكتبة المحتوى:
--    • القراءة للجميع  • الإضافة والتعديل: مشرف/مالك  • الحذف النهائي: المالك فقط
--  stage: 'intermediate' | 'secondary'  (والنصائح تقبل أيضًا 'general')
-- ══════════════════════════════════════════════════════════════

create table if not exists public.study_videos (
  id text primary key default gen_random_uuid()::text,
  youtube_id text not null default '', stage text not null default 'intermediate',
  subject text not null default '', title text not null default '',
  teacher text not null default '', excerpt text not null default '',
  extra jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);

create table if not exists public.study_tips (
  id text primary key default gen_random_uuid()::text,
  stage text not null default 'general', title text not null default '', body text not null default '',
  extra jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);

create index if not exists study_videos_stage_idx on public.study_videos (stage, created_at desc);
create index if not exists study_tips_stage_idx   on public.study_tips (stage, created_at desc);

do $$
declare t text;
begin
  foreach t in array array['study_videos','study_tips'] loop
    execute format('drop trigger if exists %I on public.%I', t || '_touch', t);
    execute format('create trigger %I before update on public.%I for each row execute function public.akdar_touch_updated_at()', t || '_touch', t);
    execute format('alter table public.%I enable row level security', t);

    execute format('drop policy if exists %I on public.%I', t || '_read', t);
    execute format('drop policy if exists %I on public.%I', t || '_insert', t);
    execute format('drop policy if exists %I on public.%I', t || '_update', t);
    execute format('drop policy if exists %I on public.%I', t || '_delete', t);
    execute format('create policy %I on public.%I for select using (true)', t || '_read', t);
    execute format('create policy %I on public.%I for insert with check (public.akdar_is_admin())', t || '_insert', t);
    execute format('create policy %I on public.%I for update using (public.akdar_is_admin()) with check (public.akdar_is_admin())', t || '_update', t);
    execute format('create policy %I on public.%I for delete using (public.akdar_is_owner())', t || '_delete', t);

    execute format('grant select on public.%I to anon, authenticated', t);
    execute format('grant insert, update, delete on public.%I to authenticated', t);
  end loop;
end $$;
