-- إصلاح الحظر: (1) كل عضو يقدر يقرأ حالته هو فقط، (2) تنفيذ الحظر في السيرفر.
-- آمن للتشغيل أكثر من مرة.

alter table public.member_moderation enable row level security;

drop policy if exists member_moderation_select_own on public.member_moderation;
create policy member_moderation_select_own on public.member_moderation
  for select using (uid::text = auth.uid()::text);

create or replace function public.akdar_block_banned()
returns trigger language plpgsql security definer set search_path = public as $$
declare v_uid text; v_status text;
begin
  v_uid := coalesce(
    nullif(to_jsonb(NEW)->>'author_uid',''),
    nullif(to_jsonb(NEW)->>'uid',''),
    nullif(to_jsonb(NEW)->>'voter_uid',''));
  if v_uid is null then return NEW; end if;
  select status into v_status from public.member_moderation where uid::text = v_uid;
  if v_status in ('banned-full','banned-partial') then
    raise exception 'member_banned' using errcode = 'P0001';
  end if;
  return NEW;
end $$;

do $$
declare t text;
begin
  foreach t in array array['ideas','occasions','idea_comments','occasion_comments','idea_votes'] loop
    if to_regclass('public.'||t) is not null then
      execute format('drop trigger if exists akdar_block_banned_trg on public.%I', t);
      execute format('create trigger akdar_block_banned_trg before insert on public.%I
                      for each row execute function public.akdar_block_banned()', t);
    end if;
  end loop;
end $$;
