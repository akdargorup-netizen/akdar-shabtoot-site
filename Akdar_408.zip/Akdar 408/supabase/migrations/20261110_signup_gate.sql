-- 20261110_signup_gate.sql — شبتوت بحري
-- ══════════════════════════════════════════════════════════════
--  بوابة التسجيل الجديد: Supabase أولًا، فإذا امتلأ يذهب الجديد إلى Firebase.
--  • لا يمسّ أي مستخدم قائم (الخطاف يعمل عند إنشاء مستخدم جديد فقط).
--  • الحد في الجدول akdar_auth_config (supabase_signup_cap) — يُعدَّل بأمر UPDATE واحد.
--    العدّاد = عدد الحسابات الحقيقية (غير المجهولة). نترك فارقًا عن 50 ألف
--    لأن الجلسات المجهولة (من يكتبون فقط) تُحسب أيضًا في MAU.
--  • حساب سُجّل على مسار Firebase لا يُنشأ له حساب ثانٍ في Supabase أبدًا
--    (جدول akdar_firebase_route) — وإلا صار للشخص هويتان وضاعت أفكاره وأصواته.
--  • الخطاف لا يفعل شيئًا حتى تفعّله من: Authentication ← Hooks ← Before User Created
--    ← Postgres ← hook_akdar_signup_gate.
--  آمن للتشغيل أكثر من مرة. التراجع: 20261110_signup_gate_ROLLBACK.sql
-- ══════════════════════════════════════════════════════════════
begin;

create table if not exists public.akdar_auth_config (
  key   text primary key,
  value text not null
);
insert into public.akdar_auth_config (key, value) values ('supabase_signup_cap', '40000')
on conflict (key) do nothing;

create table if not exists public.akdar_firebase_route (
  email_hash text primary key,
  created_at timestamptz not null default now()
);

alter table public.akdar_auth_config   enable row level security;
alter table public.akdar_firebase_route enable row level security;
revoke all on public.akdar_auth_config    from anon, authenticated;
revoke all on public.akdar_firebase_route from anon, authenticated;
-- (بلا أي سياسة = مغلقة تمامًا على التطبيق؛ تُقرأ فقط من الدوال أدناه)

create or replace function public.akdar_email_hash(p_email text)
returns text
language sql
immutable
set search_path = ''
as $$
  select encode(sha256(convert_to(lower(btrim(coalesce(p_email, ''))), 'UTF8')), 'hex')
$$;

-- هل ما زال Supabase يقبل حسابات حقيقية جديدة؟
create or replace function public.akdar_signup_open()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select (select count(*) from auth.users where coalesce(is_anonymous, false) = false)
         < coalesce((select nullif(value, '')::int from public.akdar_auth_config where key = 'supabase_signup_cap'), 40000)
$$;

-- تسجيل حساب على مسار Firebase (تستدعيه دالة Edge فقط بمفتاح الخدمة)
create or replace function public.akdar_register_firebase(p_email text)
returns void
language sql
security definer
set search_path = ''
as $$
  insert into public.akdar_firebase_route (email_hash)
  values (public.akdar_email_hash(p_email))
  on conflict (email_hash) do nothing
$$;

-- الخطاف نفسه: يُرفض إنشاء حساب حقيقي جديد في Supabase عند الامتلاء أو لو الحساب على Firebase
create or replace function public.hook_akdar_signup_gate(event jsonb)
returns jsonb
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  u     jsonb   := coalesce(event -> 'user', '{}'::jsonb);
  anon  boolean := coalesce((u ->> 'is_anonymous')::boolean, false)
                   or (u -> 'app_metadata' ->> 'provider') = 'anonymous';
  v_email text  := u ->> 'email';
begin
  if anon then return '{}'::jsonb; end if;   -- الجلسات المجهولة لا نحجبها (تُحسب ضمن الفارق)

  if v_email is not null and exists (
       select 1 from public.akdar_firebase_route
        where email_hash = public.akdar_email_hash(v_email)) then
    return jsonb_build_object('error', jsonb_build_object('http_code', 403, 'message', 'akdar_route_firebase'));
  end if;

  if not public.akdar_signup_open() then
    return jsonb_build_object('error', jsonb_build_object('http_code', 403, 'message', 'akdar_route_full'));
  end if;

  return '{}'::jsonb;
end
$$;

-- الصلاحيات: الخطاف لـ supabase_auth_admin فقط، والباقي لمفتاح الخدمة فقط
revoke all on function public.hook_akdar_signup_gate(jsonb) from public, anon, authenticated;
grant execute on function public.hook_akdar_signup_gate(jsonb) to supabase_auth_admin;

revoke all on function public.akdar_signup_open()          from public, anon, authenticated;
revoke all on function public.akdar_register_firebase(text) from public, anon, authenticated;
grant execute on function public.akdar_signup_open()          to service_role;
grant execute on function public.akdar_register_firebase(text) to service_role;

commit;
