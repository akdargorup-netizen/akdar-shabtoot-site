-- 20261110_signup_gate_ROLLBACK.sql
-- ⚠️ أولًا عطّل الخطاف من: Authentication ← Hooks ← Before User Created (Disable)، ثم شغّل هذا.
begin;
drop function if exists public.hook_akdar_signup_gate(jsonb);
drop function if exists public.akdar_register_firebase(text);
drop function if exists public.akdar_signup_open();
drop function if exists public.akdar_email_hash(text);
drop table if exists public.akdar_firebase_route;
drop table if exists public.akdar_auth_config;
commit;
