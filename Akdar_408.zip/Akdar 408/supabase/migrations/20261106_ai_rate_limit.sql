-- 20261106_ai_rate_limit.sql — شبتوت بحري
-- حدود استخدام المساعد الذكي (دالة ask) بعدّادات دائمة مشتركة بين كل نسخ الدالة.
-- المشكلة: العدّادات كانت في ذاكرة كل نسخة، فالسقف اليومي للموقع (DAILY_CAP) وحدود كل IP تتصفّر
-- مع كل تشغيل بارد ولا تُجمع بين النسخ المتوازية، فتتفلّت عند كثرة المستخدمين.
-- الآن: دالة ask تسأل القاعدة (طلب واحد خفيف) وتعود للحدود المحلية لو تعذّرت القاعدة.
-- تُكتب وتُقرأ بـservice_role فقط. المعرّف المخزَّن هو بصمة SHA-256 مقتطعة للـIP تتبدّل كل يوم (لا IP خام).
-- شغّله في SQL Editor. آمن لو أعدت تشغيله.

create table if not exists public.ai_rate_counters (
  scope   text   not null,            -- ask-min | ask-day | route-min | route-day | site | tok-est
  bucket  text   not null,            -- اليوم YYYY-MM-DD أو الدقيقة YYYY-MM-DDTHH:MI (UTC)
  subject text   not null default '', -- بصمة الـIP (فارغ للعدّادات العامة)
  n       bigint not null default 0,
  primary key (scope, bucket, subject)
);

alter table public.ai_rate_counters enable row level security;
revoke all on public.ai_rate_counters from anon, authenticated;

-- يفحص الحدود الثلاثة (الدقيقة للمستخدم، اليوم للمستخدم، اليوم للموقع) ثم يسجّل الطلب لو مسموحًا.
-- الطلب المرفوض لا يستهلك شيئًا. قفل استشاري قصير يجعل الفحص والتسجيل ذرّيًا بين النسخ المتوازية.
-- حد الدقيقة بدقيقة تقويمية (قد يسمح بدفعتين متلاصقتين عند حدّ الدقيقة) — كافٍ لغرض الحماية.
create or replace function public.ai_rate_hit(
  p_kind     text,
  p_subject  text,
  p_per_min  int,
  p_per_day  int,
  p_site_cap int
) returns text
language plpgsql security definer set search_path = public as $$
declare
  now_u timestamp := now() at time zone 'utc';
  d     text := to_char(now_u, 'YYYY-MM-DD');
  m     text := to_char(now_u, 'YYYY-MM-DD"T"HH24:MI');
  k     text := case when p_kind = 'route' then 'route' else 'ask' end;
  subj  text := coalesce(nullif(left(p_subject, 64), ''), 'unknown');
  v_min bigint;
  v_day bigint;
  v_site bigint;
begin
  perform pg_advisory_xact_lock(hashtext('ai_rate_hit'));

  select n into v_min  from public.ai_rate_counters where scope = k || '-min' and bucket = m and subject = subj;
  if coalesce(v_min, 0) >= p_per_min then return 'too-many-requests'; end if;

  select n into v_day  from public.ai_rate_counters where scope = k || '-day' and bucket = d and subject = subj;
  if coalesce(v_day, 0) >= p_per_day then return 'daily-limit-user'; end if;

  select n into v_site from public.ai_rate_counters where scope = 'site' and bucket = d and subject = '';
  if coalesce(v_site, 0) >= p_site_cap then return 'daily-limit-site'; end if;

  insert into public.ai_rate_counters(scope, bucket, subject, n) values (k || '-min', m, subj, 1)
    on conflict (scope, bucket, subject) do update set n = public.ai_rate_counters.n + 1;
  insert into public.ai_rate_counters(scope, bucket, subject, n) values (k || '-day', d, subj, 1)
    on conflict (scope, bucket, subject) do update set n = public.ai_rate_counters.n + 1;
  insert into public.ai_rate_counters(scope, bucket, subject, n) values ('site', d, '', 1)
    on conflict (scope, bucket, subject) do update set n = public.ai_rate_counters.n + 1;

  -- تنظيف دوري خفيف: نحتفظ بيومين فقط
  if random() < 0.02 then
    delete from public.ai_rate_counters where left(bucket, 10) < to_char(now_u - interval '1 day', 'YYYY-MM-DD');
  end if;
  return 'ok';
end $$;

-- يرجّع ما استهلكه طلب فشل بسبب عطل المزوّد (لا ذنب للمستخدم)
create or replace function public.ai_rate_refund(p_kind text, p_subject text)
returns void
language plpgsql security definer set search_path = public as $$
declare
  now_u timestamp := now() at time zone 'utc';
  d    text := to_char(now_u, 'YYYY-MM-DD');
  m    text := to_char(now_u, 'YYYY-MM-DD"T"HH24:MI');
  k    text := case when p_kind = 'route' then 'route' else 'ask' end;
  subj text := coalesce(nullif(left(p_subject, 64), ''), 'unknown');
begin
  perform pg_advisory_xact_lock(hashtext('ai_rate_hit'));
  update public.ai_rate_counters set n = greatest(n - 1, 0) where scope = k || '-min' and bucket = m and subject = subj;
  update public.ai_rate_counters set n = greatest(n - 1, 0) where scope = k || '-day' and bucket = d and subject = subj;
  update public.ai_rate_counters set n = greatest(n - 1, 0) where scope = 'site'      and bucket = d and subject = '';
end $$;

-- تقدير التوكنات المرسلة للنماذج اليوم (للقياس لا للحجب): يبني عليه ضبط DAILY_CAP بعد أسبوع من التشغيل
create or replace function public.ai_rate_tokens(p_tokens int)
returns void
language plpgsql security definer set search_path = public as $$
declare d text := to_char(now() at time zone 'utc', 'YYYY-MM-DD');
begin
  if coalesce(p_tokens, 0) <= 0 then return; end if;
  insert into public.ai_rate_counters(scope, bucket, subject, n) values ('tok-est', d, '', least(p_tokens, 100000))
    on conflict (scope, bucket, subject) do update set n = public.ai_rate_counters.n + least(p_tokens, 100000);
end $$;

-- لوحة الإدارة: كم طلبًا مسموحًا اليوم وكم تقدير التوكنات
create or replace function public.ai_rate_today()
returns json
language sql security definer set search_path = public as $$
  select json_build_object(
    'site',   coalesce((select n from public.ai_rate_counters where scope = 'site'    and bucket = to_char(now() at time zone 'utc', 'YYYY-MM-DD') and subject = ''), 0),
    'tokens', coalesce((select n from public.ai_rate_counters where scope = 'tok-est' and bucket = to_char(now() at time zone 'utc', 'YYYY-MM-DD') and subject = ''), 0)
  );
$$;

revoke all on function public.ai_rate_hit(text, text, int, int, int) from public, anon, authenticated;
revoke all on function public.ai_rate_refund(text, text)             from public, anon, authenticated;
revoke all on function public.ai_rate_tokens(int)                    from public, anon, authenticated;
revoke all on function public.ai_rate_today()                        from public, anon, authenticated;
grant execute on function public.ai_rate_hit(text, text, int, int, int) to service_role;
grant execute on function public.ai_rate_refund(text, text)             to service_role;
grant execute on function public.ai_rate_tokens(int)                    to service_role;
grant execute on function public.ai_rate_today()                        to service_role;
