-- تقوية الأمان (آمن للتشغيل أكثر من مرة). شغّله بعد 20261024_member_ban_enforce.sql

-- ١) المشاركة (أفكار/مناسبات/تعليقات/تصويت): ترفض الجلسات المجهولة والأعضاء المحظورين من السيرفر
create or replace function public.akdar_block_banned()
returns trigger language plpgsql security definer set search_path = public as $$
declare v_uid text; v_status text;
begin
  -- جلسة مجهولة (زائر) ما تشارك — الواجهة أصلاً تطلب تسجيل دخول Google
  if coalesce(auth.jwt() ->> 'is_anonymous', 'false') = 'true' then
    raise exception 'not_allowed' using errcode = 'P0001';
  end if;
  v_uid := coalesce(
    nullif(to_jsonb(NEW)->>'author_uid',''),
    nullif(to_jsonb(NEW)->>'uid',''),
    nullif(to_jsonb(NEW)->>'voter_uid',''));
  if v_uid is null then return NEW; end if;
  select status into v_status from public.member_moderation where uid::text = v_uid;
  if v_status in ('banned-full','banned-partial') then
    raise exception 'member_banned' using errcode = 'P0001';
  end if;
  return NEW;
end $$;

-- ٢) الرسائل الواردة (الطوارئ/المساهمات/الانضمام): حد للطول + حد للتكرار + حالة ثابتة
alter table public.inbox_messages add column if not exists sender uuid;

create or replace function public.akdar_inbox_guard()
returns trigger language plpgsql security definer set search_path = public as $$
declare v_recent int;
begin
  if auth.jwt() is null then return NEW; end if;   -- SQL Editor / service role
  if length(coalesce(NEW.body,'')) > 2000 or length(coalesce(NEW.author_name,'')) > 100 then
    raise exception 'body_too_long' using errcode = 'P0001';
  end if;
  NEW.status := 'new';          -- ما يقدر المرسل يحدد الحالة بنفسه
  NEW.sender := auth.uid();
  select count(*) into v_recent from public.inbox_messages
   where sender = auth.uid() and created_at > now() - interval '1 hour';
  if v_recent >= 6 then
    raise exception 'inbox_rate_limited' using errcode = 'P0001';
  end if;
  return NEW;
end $$;

drop trigger if exists akdar_inbox_guard_trg on public.inbox_messages;
create trigger akdar_inbox_guard_trg before insert on public.inbox_messages
  for each row execute function public.akdar_inbox_guard();
