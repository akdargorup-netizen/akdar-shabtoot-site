-- 20261106_audio_bucket.sql — شبتوت بحري
-- ════════════════════════════════════════════════════════════════════════════
--  bucket مقاطع النطق الصوتي (قاموس آنداندي + تعلم الكلام).
--  • لا عمود جديد في nubian_words/nubian_phrases: حقل audio يُحفظ تلقائيًا في عمود extra (jsonb)
--    ويرجع مع الصف المقروء أصلًا (makeStore.fromRow يفرد extra) ⇒ صفر قراءات إضافية.
--  • القراءة عامة (bucket عام: الرابط يعمل بلا استعلام). الرفع/التعديل/الحذف للمشرف ومشرف الرُطانة فقط
--    (نفس دالتَي akdar_is_admin / akdar_is_nubian المستخدمتين في جداول القاموس).
--  • السقف ١٠٠ كيلوبايت للملف، وأنواع الصوت فقط.
--  التشغيل: Supabase ← SQL Editor.
-- ════════════════════════════════════════════════════════════════════════════

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'akdar-audio', 'akdar-audio', true, 102400,
  array['audio/mp4', 'audio/x-m4a', 'audio/aac', 'audio/mpeg']
)
on conflict (id) do update
  set public = true,
      file_size_limit = 102400,
      allowed_mime_types = array['audio/mp4', 'audio/x-m4a', 'audio/aac', 'audio/mpeg'];

drop policy if exists "akdar audio insert" on storage.objects;
create policy "akdar audio insert" on storage.objects
  for insert to authenticated
  with check (bucket_id = 'akdar-audio' and (public.akdar_is_admin() or public.akdar_is_nubian()));

drop policy if exists "akdar audio update" on storage.objects;
create policy "akdar audio update" on storage.objects
  for update to authenticated
  using      (bucket_id = 'akdar-audio' and (public.akdar_is_admin() or public.akdar_is_nubian()))
  with check (bucket_id = 'akdar-audio' and (public.akdar_is_admin() or public.akdar_is_nubian()));

drop policy if exists "akdar audio delete" on storage.objects;
create policy "akdar audio delete" on storage.objects
  for delete to authenticated
  using (bucket_id = 'akdar-audio' and (public.akdar_is_admin() or public.akdar_is_nubian()));

-- Storage يتحقق من صلاحية select قبل الحذف/الاستبدال، فنمنحها للمشرفين فقط (ليس للمجهول).
-- القراءة بالرابط العام لا تحتاجها، فيبقى سرد محتويات الـbucket ممنوعًا على الزوار.
drop policy if exists "akdar audio select" on storage.objects;
create policy "akdar audio select" on storage.objects
  for select to authenticated
  using (bucket_id = 'akdar-audio' and (public.akdar_is_admin() or public.akdar_is_nubian()));

-- ── تجربة أول عشر كلمات (قبل بناء الرفع من لوحة الإدارة) ───────────────────
-- ١) ارفع الملف يدويًا من Storage ← akdar-audio باسم مثل:  w/<id الكلمة>-v1.m4a
-- ٢) اربطه بالكلمة (يحافظ على أي قيم أخرى في extra):
--   update public.nubian_words
--      set extra = coalesce(extra, '{}'::jsonb) || jsonb_build_object('audio', 'w/<id>-v1.m4a'),
--          updated_at = now()
--    where id = '<id>';
-- (للجمل: نفس الأمر على nubian_phrases ومسار p/<id>-v1.m4a). updated_at ضروري كي يلتقط
-- التطبيق التغيير عبر فحص الإصدار (versionCheck).
