-- مفتاح تفرّد من الجهاز لتعليقات الأفكار: يجعل إعادة الإرسال (بعد انقطاع الردّ أو ضغط الخادم) آمنة،
-- فلا يظهر تعليق مكرر لو كان الإرسال الأول قد نجح فعلًا. آمن للتشغيل أكثر من مرة.
-- (التطبيق يعمل بدونه أيضًا: لو العمود غير موجود يرسل التعليق بلا مفتاح.)
alter table public.idea_comments add column if not exists client_id text;
create unique index if not exists idea_comments_client_id_key
  on public.idea_comments (client_id) where client_id is not null;
