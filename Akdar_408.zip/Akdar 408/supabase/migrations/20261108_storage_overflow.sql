-- 20261108_storage_overflow.sql — شبتوت بحري
-- ══════════════════════════════════════════════════════════════
--  مشروع التخزين الاحتياطي: دالة تقيس ما استُهلك فعلًا من Storage في هذا المشروع (الأول)،
--  فيعرف التطبيق متى يحوّل الرفع الجديد إلى المشروع الثاني قبل أن يمتلئ الأول.
--  للمشرف ومشرف الرُطانة فقط. الدالة تقرأ الحجم من storage.objects (لا تلمس أي ملف).
-- ══════════════════════════════════════════════════════════════
create or replace function public.akdar_storage_used() returns bigint
language plpgsql stable security definer set search_path = public, storage as $$
begin
  if not (public.akdar_is_admin() or public.akdar_is_nubian()) then
    raise exception 'forbidden' using errcode = '42501';
  end if;
  return coalesce((select sum(coalesce((metadata->>'size')::bigint, 0))
                   from storage.objects
                   where bucket_id in ('akdar-images', 'akdar-audio')), 0);
end $$;

revoke all on function public.akdar_storage_used() from public, anon;
grant execute on function public.akdar_storage_used() to authenticated;
