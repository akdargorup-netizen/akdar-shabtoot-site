-- أختام النسخة للكاش: صف واحد في settings يحمل آخر وقت تغيّر لكل قسم عام.
-- التطبيق يقرأه (بضع بايتات) فيجدد الأقسام المتغيرة فقط، بدل مدد زمنية قصيرة.
-- آمن للتشغيل أكثر من مرة. لا يغيّر أي جدول محتوى؛ يضيف محفّزًا فقط.

-- ١) صف الأختام + سماح بقراءته للجميع (هو أرقام أوقات فقط)
insert into public.settings (key, data) values ('cache_stamps', '{}'::jsonb)
on conflict (key) do nothing;

drop policy if exists cache_stamps_read on public.settings;
create policy cache_stamps_read on public.settings
  for select to anon, authenticated
  using (key = 'cache_stamps');

-- ٢) دالة المحفّز. security definer لأن مستخدمًا عاديًا قد يحذف منشوره أو تخفيه البلاغات
--    فيجب أن يتحرك الختم رغم أن settings للإدارة وحدها.
--    TG_ARGV[0] = اسم الختم، TG_ARGV[1] = 'moderated' للأفكار والمناسبات.
create or replace function public.akdar_bump_stamp()
returns trigger language plpgsql security definer set search_path = public as $$
declare
  v_name   text    := TG_ARGV[0];
  v_mod    boolean := coalesce(TG_ARGV[1], '') = 'moderated';
  v_noise  text[]  := array['updated_at','votes_up','votes_down','comments_count','reports_count','likes_count'];
  v_o      jsonb;
  v_n      jsonb;
  v_pub_o  boolean := false;
  v_pub_n  boolean := false;
begin
  if TG_OP in ('UPDATE','DELETE') then v_o := to_jsonb(OLD); end if;
  if TG_OP in ('INSERT','UPDATE') then v_n := to_jsonb(NEW); end if;

  if v_mod then
    -- عام = moderation فارغ أو approved، وليس محذوفًا من صاحبه
    if v_o is not null then
      v_pub_o := (v_o->>'moderation' is null or v_o->>'moderation' = 'approved')
                 and coalesce(v_o->>'deleted_by_author', 'false') = 'false';
    end if;
    if v_n is not null then
      v_pub_n := (v_n->>'moderation' is null or v_n->>'moderation' = 'approved')
                 and coalesce(v_n->>'deleted_by_author', 'false') = 'false';
    end if;
    if TG_OP = 'UPDATE' then
      -- تغيّر الحالة نفسها (قبول/رفض/إخفاء) يهم صاحب المنشور أيضًا ولو لم يكن عامًا
      if not (v_pub_o or v_pub_n or (v_o->>'moderation') is distinct from (v_n->>'moderation')) then
        return null;
      end if;
    elsif not (v_pub_o or v_pub_n) then
      return null; -- منشور جديد معلّق، أو حذف شيء غير منشور: لا يهم أحدًا
    end if;
  end if;

  if TG_OP = 'UPDATE' and (v_o - v_noise) = (v_n - v_noise) then
    return null; -- تغيّرت عدّادات فقط (تصويت/إعجاب/تعليق): لا نحرّك الختم
  end if;

  update public.settings
     set data = jsonb_set(coalesce(data, '{}'::jsonb), array[v_name],
                          to_jsonb((extract(epoch from clock_timestamp()) * 1000)::bigint), true)
   where key = 'cache_stamps';
  return null;
end $$;

-- ٣) ربط المحفّز بكل جدول (يتخطى الجدول غير الموجود بدل إفشال الملف كله)
do $$
declare
  r record;
begin
  for r in
    select * from (values
      ('news',                         'news',                         ''),
      ('events',                       'events',                       ''),
      ('ideas',                        'ideas',                        'moderated'),
      ('occasions',                    'occasions',                    'moderated'),
      ('memory_videos',                'memory_videos',                ''),
      ('study_videos',                 'study_videos',                 ''),
      ('study_tips',                   'study_tips',                   ''),
      ('worship_lectures',             'worship_lectures',             ''),
      ('history_articles',             'history_articles',             ''),
      ('association_journey_articles', 'association_journey_articles', ''),
      ('projects',                     'projects',                     ''),
      ('gallery',                      'gallery',                      ''),
      ('contacts',                     'contacts',                     ''),
      ('nubian_words',                 'nubian_words',                 ''),
      ('nubian_phrase_categories',     'nubian_phrase_categories',     ''),
      ('nubian_phrases',               'nubian_phrases',               '')
    ) as t(tbl, stamp, mode)
  loop
    if to_regclass('public.' || r.tbl) is null then
      raise notice 'تخطّي الجدول غير الموجود: %', r.tbl;
      continue;
    end if;
    execute format('drop trigger if exists akdar_stamp on public.%I', r.tbl);
    execute format(
      'create trigger akdar_stamp after insert or update or delete on public.%I '
      'for each row execute function public.akdar_bump_stamp(%L, %L)',
      r.tbl, r.stamp, r.mode);
  end loop;
end $$;
