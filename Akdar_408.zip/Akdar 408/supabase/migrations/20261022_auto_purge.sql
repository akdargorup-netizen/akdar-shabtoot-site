-- supabase/migrations/20261022_auto_purge.sql — شبتوت بحري
-- تنظيف تلقائي أسبوعي للمحتوى المؤرشف (كان يدويًا من زر "تنظيف الأرشيف") — يحفظ حد الـ500MB.
-- نفس مدد الاحتفاظ في js/data/retention.js (أخبار/رسائل/أفكار/تعليقات ٤٥، مناسبات ٦٠، وارد ٩٠)
-- + مهلة أمان ٣٠ يومًا بعد انتهاء المدة قبل الحذف النهائي. ما حُدِّد "restored" يدويًا لا يُحذف أبدًا.
-- المؤرشف يدويًا ("archived") يُحذف بعد ٧ أيام من تاريخه على الأقل.
-- ⚠️ إن غيّرت retention.js غيّر الأرقام هنا. صور الأخبار المحذوفة هنا لا تُحذف من Storage
--    (الحذف اليدوي من لوحة الإدارة هو الذي ينظّف الصور).
-- شغّله في SQL Editor. آمن لو أعدت تشغيله.

create or replace function public.akdar_purge_archived() returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  grace interval := interval '30 days';
  n_news int; n_notif int; n_ideas int; n_comm int; n_occ int; n_inbox int;
begin
  delete from public.news where archive_state is distinct from 'restored'
    and ((archive_state = 'archived' and published_at < now() - interval '7 days')
      or published_at < now() - (interval '45 days' + grace));
  get diagnostics n_news = row_count;

  delete from public.notifications where archive_state is distinct from 'restored'
    and ((archive_state = 'archived' and created_at < now() - interval '7 days')
      or created_at < now() - (interval '45 days' + grace));
  get diagnostics n_notif = row_count;

  delete from public.ideas where archive_state is distinct from 'restored'
    and ((archive_state = 'archived' and created_at < now() - interval '7 days')
      or created_at < now() - (interval '45 days' + grace));
  get diagnostics n_ideas = row_count;

  delete from public.idea_comments where created_at < now() - (interval '45 days' + grace);
  get diagnostics n_comm = row_count;

  delete from public.occasions where archive_state is distinct from 'restored'
    and ((archive_state = 'archived' and created_at < now() - interval '7 days')
      or created_at < now() - (interval '60 days' + grace));
  get diagnostics n_occ = row_count;

  delete from public.inbox_messages where created_at < now() - (interval '90 days' + grace);
  get diagnostics n_inbox = row_count;

  return jsonb_build_object('news', n_news, 'notifications', n_notif, 'ideas', n_ideas,
    'comments', n_comm, 'occasions', n_occ, 'inbox', n_inbox);
end $$;
revoke all on function public.akdar_purge_archived() from public, anon, authenticated;
grant execute on function public.akdar_purge_archived() to service_role;

-- الجدولة: كل أحد 03:30 UTC. تتطلب امتداد pg_cron (Database ← Extensions ← pg_cron ← Enable)،
-- فإن لم يكن مفعّلًا تُتخطّى الجدولة برسالة بدل أن تفشل الهجرة.
do $$
begin
  create extension if not exists pg_cron;
  perform cron.unschedule(jobid) from cron.job where jobname = 'akdar-purge-archived';
  perform cron.schedule('akdar-purge-archived', '30 3 * * 0', 'select public.akdar_purge_archived()');
exception when others then
  raise notice 'pg_cron غير متاح (%): فعّله من Extensions ثم أعد تشغيل هذا الملف', sqlerrm;
end $$;

-- فحص يدوي لما سيُحذف أو تشغيل فوري (من SQL Editor):  select public.akdar_purge_archived();
