-- آنداندي: تحمّل آلاف الكلمات والجمل (المرحلة ب).
--  • أعمدة محسوبة تلقائيًا (has_audio / has_translation / search_key) بدل حسابها في المتصفح.
--  • دوال تُرجع صفحة واحدة (٣٠ عنصرًا مثلًا) + عدّادات التصنيفات بطلب صغير، بدل تنزيل الجدول كله.
--  • لا تغيير في بيانات موجودة ولا في سياسات الأمان: الدوال security invoker فتبقى القراءة عامة كما هي.
-- آمن للتشغيل أكثر من مرة. التطبيق يعمل حتى قبل تشغيل هذا الملف (يرجع للجلب الكامل القديم تلقائيًا).

-- ١) تطبيع البحث — نفس روح normalizeText في js/shared/arabic-search.js:
--    تشكيل/تطويل/علامات لاتينية تُحذف، الهمزات→ا، ى/ئ→ي، ؤ→و، ة→ه، الأرقام الهندية→لاتينية،
--    تكرار الحرف اللاتيني يُدمج، وأي رمز → مسافة. (الاستعلام نفسه يُطبَّع هنا أيضًا فلا يهم أي اختلاف بسيط عن JS.)
create or replace function public.akdar_search_norm(t text)
returns text language sql immutable parallel safe as $$
  select btrim(
    regexp_replace(
      regexp_replace(
        lower(
          translate(
            regexp_replace(normalize(coalesce(t, ''), NFD), '[\u0300-\u036F\u064B-\u065F\u0670\u06D6-\u06ED\u0640]', '', 'g'),
            'أإآٱىیئؤةک٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹',
            'اااايييوهك01234567890123456789'
          )
        ),
        '([a-z])\1+', '\1', 'g'
      ),
      '[\s\.,;:!?"''()\[\]{}<>=+*&^%$#@~`|/\\_\-\u060C\u061B\u061F\u00AB\u00BB\u2026\u2013\u2014\u200C\u200F\u200E]+', ' ', 'g'
    )
  );
$$;

-- ٢) الأعمدة المحسوبة (تُحدَّث وحدها مع كل إضافة/تعديل؛ لا يكتبها التطبيق أبدًا)
alter table public.nubian_words
  add column if not exists has_audio boolean
    generated always as (coalesce(extra->>'audio', '') <> '') stored,
  add column if not exists has_translation boolean
    generated always as (nub <> '' or translit <> '') stored,
  add column if not exists search_key text
    generated always as (public.akdar_search_norm(ar || ' ' || nub || ' ' || translit || ' ' || note)) stored;

alter table public.nubian_phrases
  add column if not exists has_audio boolean
    generated always as (coalesce(extra->>'audio', '') <> '') stored,
  add column if not exists has_translation boolean
    generated always as (nub <> '' or translit <> '') stored,
  add column if not exists search_key text
    generated always as (public.akdar_search_norm(ar || ' ' || nub || ' ' || translit || ' ' || note)) stored;

-- ٣) فهارس: التصفح بالتصنيف مرتبًا، وطابور «بلا صوت». (فهرس الحروف الثلاثية للبحث اختياري: فشله لا يوقف الملف)
create index if not exists nubian_words_cat_created_idx   on public.nubian_words   (category, created_at, id);
create index if not exists nubian_phrases_cat_created_idx on public.nubian_phrases (category, created_at, id);
create index if not exists nubian_words_queue_idx         on public.nubian_words   (created_at, id) where has_translation and not has_audio;

do $$ begin
  create extension if not exists pg_trgm with schema extensions;
  execute 'create index if not exists nubian_words_search_trgm   on public.nubian_words   using gin (search_key extensions.gin_trgm_ops)';
  execute 'create index if not exists nubian_phrases_search_trgm on public.nubian_phrases using gin (search_key extensions.gin_trgm_ops)';
exception when others then
  raise notice 'تخطّي فهرس البحث الثلاثي (اختياري): %', sqlerrm;
end $$;

-- ٤) عدّادات التصنيفات (للشاشة الرئيسية وشاشة التصنيفات) — طلب واحد صغير
create or replace function public.nubian_word_stats()
returns table (category text, total int, no_audio int, no_translation int)
language sql stable as $$
  select w.category,
         count(*)::int,
         count(*) filter (where w.has_translation and not w.has_audio)::int,
         count(*) filter (where not w.has_translation)::int
    from public.nubian_words w
   group by w.category;
$$;

create or replace function public.nubian_phrase_stats()
returns table (category text, total int, no_audio int, no_translation int)
language sql stable as $$
  select p.category,
         count(*)::int,
         count(*) filter (where p.has_translation and not p.has_audio)::int,
         count(*) filter (where not p.has_translation)::int
    from public.nubian_phrases p
   group by p.category;
$$;

-- ٥) صفحة واحدة: p_filter = all | no-audio | no-translation، p_query بحث متعدد الكلمات بأي ترتيب
--    يرجع { total, rows } — total عدد كل المطابق (للعدّاد و«عرض المزيد») وrows الصفحة المطلوبة.
create or replace function public.nubian_words_page(
  p_category text default null, p_filter text default 'all', p_query text default '',
  p_offset int default 0, p_limit int default 30)
returns jsonb language plpgsql stable as $$
declare
  v_toks text[] := array(select x from unnest(string_to_array(public.akdar_search_norm(p_query), ' ')) x where x <> '');
  v_limit int := least(greatest(coalesce(p_limit, 30), 1), 200);
  v_total int;
  v_rows jsonb;
begin
  with m as (
    select w.* from public.nubian_words w
     where (p_category is null or p_category = '' or w.category = p_category)
       and (case coalesce(p_filter, 'all')
              when 'no-audio'       then w.has_translation and not w.has_audio
              when 'no-translation' then not w.has_translation
              else true end)
       and not exists (select 1 from unnest(v_toks) t where position(t in w.search_key) = 0)
  )
  select (select count(*) from m)::int,
         coalesce(jsonb_agg(to_jsonb(s) order by s.created_at, s.id), '[]'::jsonb)
    into v_total, v_rows
    from (select * from m order by created_at, id offset greatest(coalesce(p_offset, 0), 0) limit v_limit) s;
  return jsonb_build_object('total', v_total, 'rows', v_rows);
end $$;

create or replace function public.nubian_phrases_page(
  p_category text default null, p_filter text default 'all', p_query text default '',
  p_offset int default 0, p_limit int default 30)
returns jsonb language plpgsql stable as $$
declare
  v_toks text[] := array(select x from unnest(string_to_array(public.akdar_search_norm(p_query), ' ')) x where x <> '');
  v_limit int := least(greatest(coalesce(p_limit, 30), 1), 200);
  v_total int;
  v_rows jsonb;
begin
  with m as (
    select p.* from public.nubian_phrases p
     where (p_category is null or p_category = '' or p.category = p_category)
       and (case coalesce(p_filter, 'all')
              when 'no-audio'       then p.has_translation and not p.has_audio
              when 'no-translation' then not p.has_translation
              else true end)
       and not exists (select 1 from unnest(v_toks) t where position(t in p.search_key) = 0)
  )
  select (select count(*) from m)::int,
         coalesce(jsonb_agg(to_jsonb(s) order by s.created_at, s.id), '[]'::jsonb)
    into v_total, v_rows
    from (select * from m order by created_at, id offset greatest(coalesce(p_offset, 0), 0) limit v_limit) s;
  return jsonb_build_object('total', v_total, 'rows', v_rows);
end $$;

grant execute on function public.akdar_search_norm(text)                          to anon, authenticated;
grant execute on function public.nubian_word_stats()                              to anon, authenticated;
grant execute on function public.nubian_phrase_stats()                            to anon, authenticated;
grant execute on function public.nubian_words_page(text, text, text, int, int)    to anon, authenticated;
grant execute on function public.nubian_phrases_page(text, text, text, int, int)  to anon, authenticated;

-- يجعل PostgREST يلتقط الدوال والأعمدة الجديدة فورًا
notify pgrst, 'reload schema';
