-- 20261019_storage_hardening.sql — شبتوت بحري
-- ════════════════════════════════════════════════════════════════════════════
--  حماية حصة Storage المجانية (1GB) من الرفع المسيء.
--  المشكلة: سياسة "akdar anon upload" تسمح لأي شخص يعرف المفتاح العام (الظاهر في المتصفح)
--  برفع ملفات إلى bucket الصور، فيمكن ملء المساحة أو استهلاك النقل.
--  التشغيل: Supabase ← SQL Editor، كل مرحلة وحدها.
-- ════════════════════════════════════════════════════════════════════════════

-- ── المرحلة (أ) — شغّلها الآن (آمنة، لا تكسر شيئًا) ─────────────────────────
-- حدّ حجم ونوع الملف على مستوى الـbucket. التطبيق يصغّر الصور قبل الرفع إلى WebP/JPEG
-- (أقصى بعد ١٢٠٠ بكسل، عادةً ١٠٠–٣٠٠KB)، فـ١MB هامش واسع.
update storage.buckets
set file_size_limit    = 1048576,
    allowed_mime_types = array['image/webp', 'image/jpeg']
where id = 'akdar-images';

-- تحقّق من النتيجة:
-- select id, public, file_size_limit, allowed_mime_types from storage.buckets where id = 'akdar-images';


-- ── المرحلة (ب) — شغّلها بعد أن يصل التطبيق v415 (أو أحدث) لمعظم المستخدمين (~أسبوع) ──
-- نسخة v415 ترسل توكن المستخدم المسجّل مع كل رفع، فنقصر الرفع على الأعضاء الحقيقيين
-- (لا مجهولين ولا من يحمل المفتاح العام فقط). النسخ القديمة التي لم تتحدّث لن تستطيع رفع
-- الصور إلى أن تتحدّث — لذلك لا تشغّلها قبل انتشار التحديث.
-- (أزل علامة -- من الأسطر التالية لتفعيلها)
--
-- drop policy if exists "akdar anon upload" on storage.objects;
-- create policy "akdar member upload" on storage.objects
--   for insert to authenticated
--   with check (
--     bucket_id = 'akdar-images'
--     and coalesce((auth.jwt() ->> 'is_anonymous')::boolean, false) = false
--   );
--
-- للتراجع لو ظهر خلل في الرفع:
-- drop policy if exists "akdar member upload" on storage.objects;
-- create policy "akdar anon upload" on storage.objects
--   for insert to anon with check (bucket_id = 'akdar-images');
--
-- ملاحظة: سياسة القراءة/السرد للمجهول ("akdar anon list") تبقى كما هي لأن لوحة الإدارة
-- وسكربت النسخ الاحتياطي (scripts/admin/backup-images.mjs) يعتمدان عليها.
