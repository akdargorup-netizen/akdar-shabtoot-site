-- 20261109_akdar_uid_ROLLBACK.sql — يعيد السياسات والدوال لتعريفها الأصلي (auth.uid()) ثم يحذف akdar_uid().
begin;


-- ── الدوال (الأصل) ──────────────────────────────────────

CREATE OR REPLACE FUNCTION public.akdar_is_owner()
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  select exists (select 1 from public.user_roles r where r.user_id = auth.uid() and r.is_owner is true);
$function$;

CREATE OR REPLACE FUNCTION public.akdar_is_admin()
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  select exists (select 1 from public.user_roles r
                 where r.user_id = auth.uid() and (r.is_admin is true or r.is_owner is true));
$function$;

CREATE OR REPLACE FUNCTION public.akdar_is_nubian()
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  select exists (select 1 from public.user_roles r where r.user_id = auth.uid() and r.is_nubian is true);
$function$;

CREATE OR REPLACE FUNCTION public.unregister_push_subscription(p_device_id text)
 RETURNS void
 LANGUAGE sql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
  delete from public.push_subscriptions
   where device_id = p_device_id and owner_uid = (select auth.uid());
$function$;

CREATE OR REPLACE FUNCTION public.register_push_subscription(p_device_id text, p_subscription jsonb)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare
  me uuid := (select auth.uid());
  ep  text := p_subscription ->> 'endpoint';
begin
  if me is null then raise exception 'not_signed_in'; end if;
  if p_device_id is null or char_length(p_device_id) not between 1 and 200 then
    raise exception 'invalid_device';
  end if;
  if ep is null or char_length(ep) > 1000
     or ep !~ '^https://(fcm\.googleapis\.com|updates\.push\.services\.mozilla\.com|[a-zA-Z0-9.-]+\.notify\.windows\.com|[a-zA-Z0-9.-]*push\.apple\.com)/.*'
  then
    raise exception 'invalid_endpoint';
  end if;
  if coalesce(char_length(p_subscription #>> '{keys,p256dh}'), 0) not between 1 and 200
     or coalesce(char_length(p_subscription #>> '{keys,auth}'), 0) not between 1 and 100
  then
    raise exception 'invalid_keys';
  end if;

  insert into public.push_subscriptions (device_id, owner_uid, subscription, updated_at)
  values (p_device_id, me, p_subscription, now())
  on conflict (device_id) do update
    set owner_uid = excluded.owner_uid, subscription = excluded.subscription, updated_at = now();
end $function$;

CREATE OR REPLACE FUNCTION public.is_not_banned()
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO ''
AS $function$
  select not exists (select 1 from public.member_moderation m where m.uid = (select auth.uid()));
$function$;

CREATE OR REPLACE FUNCTION public.a_force_created_at()
 RETURNS trigger
 LANGUAGE plpgsql
 SET search_path TO ''
AS $function$
begin
  if (select auth.uid()) is not null then new.created_at := now(); end if;
  return new;
end $function$;

CREATE OR REPLACE FUNCTION public.ideas_guard_insert()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare
  me  uuid := (select auth.uid());
  used int;
begin
  if me is null then return new; end if;                 -- service_role / SQL Editor
  if new.author_uid is distinct from me then raise exception 'author_mismatch'; end if;
  if not public.staff_role_ok(new.staff_role) then raise exception 'invalid_staff_role'; end if;

  new.moderation := case when new.staff_role is null then 'pending' else null end;
  new.archive_state := null; new.archived := false; new.hidden := false; new.deleted_by_author := false;
  new.votes_up := 0; new.votes_down := 0; new.comments_count := 0; new.reports_count := 0;
  new.edited_at := null; new.created_at := now();

  if new.staff_role is null then
    select count(*) into used from public.ideas x
     where x.author_uid = me
       and x.created_at >= (date_trunc('day', now() at time zone 'utc') at time zone 'utc');
    if used >= public.post_daily_limit() then raise exception 'daily_limit_reached'; end if;
  end if;
  return new;
end $function$;

CREATE OR REPLACE FUNCTION public.is_owner()
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO ''
AS $function$
  select coalesce((select r.is_owner from public.user_roles r where r.user_id = (select auth.uid())), false);
$function$;

CREATE OR REPLACE FUNCTION public.is_admin()
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO ''
AS $function$
  select coalesce((select r.is_admin or r.is_owner from public.user_roles r where r.user_id = (select auth.uid())), false);
$function$;

CREATE OR REPLACE FUNCTION public.is_nubian_editor()
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO ''
AS $function$
  select coalesce((select r.is_nubian from public.user_roles r where r.user_id = (select auth.uid())), false);
$function$;

CREATE OR REPLACE FUNCTION public.is_real_user()
 RETURNS boolean
 LANGUAGE sql
 STABLE
 SET search_path TO ''
AS $function$
  select (select auth.uid()) is not null
     and coalesce(((select auth.jwt()) ->> 'is_anonymous')::boolean, false) = false;
$function$;

CREATE OR REPLACE FUNCTION public.occasions_guard_insert()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare
  me  uuid := (select auth.uid());
  used int;
begin
  if me is null then return new; end if;
  if new.author_uid is distinct from me then raise exception 'author_mismatch'; end if;
  if not public.staff_role_ok(new.staff_role) then raise exception 'invalid_staff_role'; end if;

  new.moderation := case when new.staff_role is null then 'pending' else null end;
  new.archive_state := null; new.archived := false; new.hidden := false; new.deleted_by_author := false;
  new.likes_count := 0; new.comments_count := 0; new.reports_count := 0;
  new.edited_at := null; new.created_at := now();

  if new.staff_role is null then
    select count(*) into used from public.occasions x
     where x.author_uid = me
       and x.created_at >= (date_trunc('day', now() at time zone 'utc') at time zone 'utc');
    if used >= public.post_daily_limit() then raise exception 'daily_limit_reached'; end if;
  end if;
  return new;
end $function$;

CREATE OR REPLACE FUNCTION public.post_guard_update()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare
  me     uuid   := (select auth.uid());
  content text[] := string_to_array(tg_argv[0], ',');
  ch      text[] := public._changed_cols(to_jsonb(old), to_jsonb(new));
begin
  if me is null or pg_trigger_depth() > 1 or public.is_owner() then return new; end if;

  if public.is_admin()
     and ch <@ (content || array['archive_state', 'moderation', 'updated_at', 'archived', 'hidden'])
     and (not ('archive_state' = any(ch)) or new.archive_state in ('archived', 'restored'))
     and (not ('moderation' = any(ch))    or new.moderation = 'approved')
  then
    return new;
  end if;

  if old.author_uid = me and public.is_real_user() then
    if ch <@ array['deleted_by_author', 'updated_at'] and new.deleted_by_author = true then
      return new;
    end if;
    if public.is_not_banned()
       and coalesce(old.moderation, '') <> 'reported'
       and now() < old.created_at + interval '15 minutes'
       and ch <@ (content || array['edited_at', 'updated_at'])
    then
      new.edited_at := now();
      return new;
    end if;
  end if;

  raise exception 'not_allowed';
end $function$;

CREATE OR REPLACE FUNCTION public.idea_comment_guard_insert()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare
  me  uuid := (select auth.uid());
  used int;
begin
  if me is null then return new; end if;
  if new.uid is distinct from me then raise exception 'author_mismatch'; end if;
  if not public.staff_role_ok(new.staff_role) then raise exception 'invalid_staff_role'; end if;
  new.moderation := null; new.reports_count := 0; new.deleted_by_author := false;
  new.edited_at := null; new.created_at := now();
  if new.staff_role is null then
    select count(*) into used from public.idea_comments c where c.idea_id = new.idea_id and c.uid = me;
    if used >= 3 then raise exception 'comment_limit_reached'; end if;
  end if;
  return new;
end $function$;

CREATE OR REPLACE FUNCTION public.occasion_comment_guard_insert()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare me uuid := (select auth.uid());
begin
  if me is null then return new; end if;
  if new.uid is distinct from me then raise exception 'author_mismatch'; end if;
  if not public.staff_role_ok(new.staff_role) then raise exception 'invalid_staff_role'; end if;
  new.moderation := null; new.reports_count := 0; new.deleted_by_author := false;
  new.edited_at := null; new.created_at := now();
  return new;
end $function$;

CREATE OR REPLACE FUNCTION public.comment_guard_update()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare
  me uuid   := (select auth.uid());
  ch  text[] := public._changed_cols(to_jsonb(old), to_jsonb(new));
begin
  if me is null or pg_trigger_depth() > 1 or public.is_owner() then return new; end if;

  if public.is_admin() and ch <@ array['moderation'] and new.moderation = 'approved' then
    return new;
  end if;

  if old.uid = me and public.is_real_user() then
    if ch <@ array['deleted_by_author'] and new.deleted_by_author = true then
      return new;
    end if;
    if public.is_not_banned()
       and coalesce(old.moderation, '') <> 'reported'
       and now() < old.created_at + interval '15 minutes'
       and ch <@ array['text', 'edited_at']
    then
      new.edited_at := now();
      return new;
    end if;
  end if;

  raise exception 'not_allowed';
end $function$;

CREATE OR REPLACE FUNCTION public.akdar_inbox_guard()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_recent int;
begin
  if auth.jwt() is null then return NEW; end if;   -- SQL Editor / service role
  if length(coalesce(NEW.body,'')) > 2000 or length(coalesce(NEW.author_name,'')) > 100 then
    raise exception 'body_too_long' using errcode = 'P0001';
  end if;
  NEW.status := 'new';          -- ما يقدر المرسل يحدد الحالة بنفسه
  NEW.sender := auth.uid();
  select count(*) into v_recent from public.inbox_messages
   where sender = auth.uid() and created_at > now() - interval '1 hour';
  if v_recent >= 6 then
    raise exception 'inbox_rate_limited' using errcode = 'P0001';
  end if;
  return NEW;
end $function$;

-- ── السياسات (الأصل) ────────────────────────────────────

alter policy "roles read own" on public.user_roles
  using ((user_id = ( SELECT auth.uid() AS uid)));

alter policy "mod read" on public.member_moderation
  using ((is_admin() OR (uid = ( SELECT auth.uid() AS uid))));

alter policy "ideas read" on public.ideas
  using ((((moderation IS DISTINCT FROM 'pending'::text) AND (moderation IS DISTINCT FROM 'reported'::text)) OR (author_uid = ( SELECT auth.uid() AS uid)) OR is_admin()));

alter policy "ideas insert" on public.ideas
  with check ((is_real_user() AND is_not_banned() AND (author_uid = ( SELECT auth.uid() AS uid))));

alter policy "ideas update" on public.ideas
  using ((is_admin() OR (author_uid = ( SELECT auth.uid() AS uid))))
  with check ((is_admin() OR (author_uid = ( SELECT auth.uid() AS uid))));

alter policy "occasions read" on public.occasions
  using ((((moderation IS DISTINCT FROM 'pending'::text) AND (moderation IS DISTINCT FROM 'reported'::text)) OR (author_uid = ( SELECT auth.uid() AS uid)) OR is_admin()));

alter policy "occasions insert" on public.occasions
  with check ((is_real_user() AND is_not_banned() AND (author_uid = ( SELECT auth.uid() AS uid))));

alter policy "occasions update" on public.occasions
  using ((is_admin() OR (author_uid = ( SELECT auth.uid() AS uid))))
  with check ((is_admin() OR (author_uid = ( SELECT auth.uid() AS uid))));

alter policy "votes read" on public.idea_votes
  using (((voter_uid = ( SELECT auth.uid() AS uid)) OR is_admin()));

alter policy "notif read" on public.notifications
  using ((is_admin() OR (personal = false) OR (personal AND is_real_user() AND (recipient_uid = ( SELECT auth.uid() AS uid)))));

alter policy "votes insert" on public.idea_votes
  with check ((is_real_user() AND is_not_banned() AND (voter_uid = ( SELECT auth.uid() AS uid))));

alter policy "votes update" on public.idea_votes
  using ((voter_uid = ( SELECT auth.uid() AS uid)))
  with check ((is_real_user() AND is_not_banned() AND (voter_uid = ( SELECT auth.uid() AS uid))));

alter policy "likes read" on public.occasion_likes
  using (((uid = ( SELECT auth.uid() AS uid)) OR is_admin()));

alter policy "likes insert" on public.occasion_likes
  with check ((is_real_user() AND is_not_banned() AND (uid = ( SELECT auth.uid() AS uid))));

alter policy "notif insert" on public.notifications
  with check ((is_owner() OR (is_real_user() AND is_not_banned() AND (personal = true) AND (actor_uid = ( SELECT auth.uid() AS uid)) AND (recipient_uid IS NOT NULL) AND (recipient_uid <> actor_uid) AND (type = ANY (ARRAY['like'::text, 'comment'::text, 'reply'::text, 'endorse'::text])) AND (target_kind = ANY (ARRAY['occasion'::text, 'idea'::text])) AND (target_id IS NOT NULL) AND (char_length(target_id) <= 40) AND (char_length(title) <= 100) AND (char_length(body) <= 300) AND (read = false) AND (((target_kind = 'idea'::text) AND (EXISTS ( SELECT 1
   FROM ideas i
  WHERE (((i.id)::text = notifications.target_id) AND (i.author_uid = notifications.recipient_uid))))) OR ((target_kind = 'occasion'::text) AND (EXISTS ( SELECT 1
   FROM occasions o
  WHERE (((o.id)::text = notifications.target_id) AND (o.author_uid = notifications.recipient_uid)))))))));

alter policy "likes delete" on public.occasion_likes
  using ((is_owner() OR (is_real_user() AND (uid = ( SELECT auth.uid() AS uid)))));

alter policy "icomments read" on public.idea_comments
  using (((moderation IS DISTINCT FROM 'reported'::text) OR (uid = ( SELECT auth.uid() AS uid)) OR is_admin()));

alter policy "icomments insert" on public.idea_comments
  with check ((is_real_user() AND is_not_banned() AND (uid = ( SELECT auth.uid() AS uid))));

alter policy "icomments update" on public.idea_comments
  using ((is_admin() OR (uid = ( SELECT auth.uid() AS uid))))
  with check ((is_admin() OR (uid = ( SELECT auth.uid() AS uid))));

alter policy "ocomments read" on public.occasion_comments
  using (((moderation IS DISTINCT FROM 'reported'::text) OR (uid = ( SELECT auth.uid() AS uid)) OR is_admin()));

alter policy "ocomments insert" on public.occasion_comments
  with check ((is_real_user() AND is_not_banned() AND (uid = ( SELECT auth.uid() AS uid))));

alter policy "ocomments update" on public.occasion_comments
  using ((is_admin() OR (uid = ( SELECT auth.uid() AS uid))))
  with check ((is_admin() OR (uid = ( SELECT auth.uid() AS uid))));

alter policy "ocomments delete" on public.occasion_comments
  using ((is_owner() OR (is_real_user() AND (uid = ( SELECT auth.uid() AS uid)))));

alter policy "reports insert" on public.idea_reports
  with check ((is_real_user() AND is_not_banned() AND (reporter_uid = ( SELECT auth.uid() AS uid)) AND (( SELECT p.author_uid
   FROM ideas p
  WHERE (p.id = idea_reports.idea_id)) IS DISTINCT FROM ( SELECT auth.uid() AS uid))));

alter policy "reports insert" on public.idea_comment_reports
  with check ((is_real_user() AND is_not_banned() AND (reporter_uid = ( SELECT auth.uid() AS uid)) AND (( SELECT p.uid
   FROM idea_comments p
  WHERE (p.id = idea_comment_reports.comment_id)) IS DISTINCT FROM ( SELECT auth.uid() AS uid))));

alter policy "reports insert" on public.occasion_reports
  with check ((is_real_user() AND is_not_banned() AND (reporter_uid = ( SELECT auth.uid() AS uid)) AND (( SELECT p.author_uid
   FROM occasions p
  WHERE (p.id = occasion_reports.occasion_id)) IS DISTINCT FROM ( SELECT auth.uid() AS uid))));

alter policy "reports insert" on public.occasion_comment_reports
  with check ((is_real_user() AND is_not_banned() AND (reporter_uid = ( SELECT auth.uid() AS uid)) AND (( SELECT p.uid
   FROM occasion_comments p
  WHERE (p.id = occasion_comment_reports.comment_id)) IS DISTINCT FROM ( SELECT auth.uid() AS uid))));

alter policy "user_roles_read_own" on public.user_roles
  using ((user_id = auth.uid()));

alter policy "member_moderation_select_own" on public.member_moderation
  using (((uid)::text = (auth.uid())::text));

drop function if exists public.akdar_uid();
commit;
