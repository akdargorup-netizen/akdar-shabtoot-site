-- supabase/migrations/20261105_ai_insights.sql — شبتوت بحري
-- رؤى المساعد: (١) الأسئلة التي لم يجد لها جوابًا («لا توجد معلومة عن هذا حاليًا») مجمّعة ومعدودة
-- لتعرف ما يسأل عنه الناس وتكتب المحتوى الناقص، (٢) تقييم 👍/👎 لكل إجابة.
-- خصوصية: لا نحفظ هوية ولا IP ولا أي معرّف للمستخدم — نص السؤال/الإجابة فقط (مقصوصان).
-- تكتبها دالة ask بـservice_role فقط وتقرؤها دالة ask نفسها لصفحة «الذكاء الاصطناعي» في الإدارة.
-- شغّله في SQL Editor. آمن لو أعدت تشغيله.

-- ── الأسئلة غير المُجابة (مجمّعة بعد التطبيع) ──
create table if not exists public.ai_unanswered (
  norm      text primary key,                 -- السؤال بعد التطبيع (لتجميع الصيغ المتشابهة)
  question  text not null,                    -- آخر صيغة وصلت
  cnt       int  not null default 1,
  first_at  timestamptz not null default now(),
  last_at   timestamptz not null default now()
);
alter table public.ai_unanswered enable row level security;
revoke all on public.ai_unanswered from anon, authenticated;

create or replace function public.ai_unanswered_bump(p_norm text, p_question text)
returns void language plpgsql security definer set search_path = public as $$
declare n text := left(coalesce(p_norm, ''), 200);
begin
  if length(n) < 3 then return; end if;
  insert into public.ai_unanswered(norm, question)
  values (n, left(coalesce(p_question, n), 300))
  on conflict (norm) do update set
    cnt = public.ai_unanswered.cnt + 1,
    question = left(coalesce(p_question, public.ai_unanswered.question), 300),
    last_at = now();
  -- تنظيف دوري خفيف: نحتفظ بـ٦٠ يومًا، وبحد أقصى ٢٠٠٠ سؤال مميّز
  if random() < 0.01 then
    delete from public.ai_unanswered where last_at < now() - interval '60 days';
    delete from public.ai_unanswered where norm in (
      select norm from public.ai_unanswered order by last_at desc offset 2000);
  end if;
end $$;
revoke all on function public.ai_unanswered_bump(text, text) from public, anon, authenticated;
grant execute on function public.ai_unanswered_bump(text, text) to service_role;

-- ── تقييم الإجابات ──
create table if not exists public.ai_feedback (
  id          bigserial primary key,
  created_at  timestamptz not null default now(),
  vote        smallint not null check (vote in (-1, 1)),
  question    text not null,
  answer      text not null
);
create index if not exists ai_feedback_created_idx on public.ai_feedback (created_at desc);
alter table public.ai_feedback enable row level security;
revoke all on public.ai_feedback from anon, authenticated;

create or replace function public.ai_feedback_add(p_vote int, p_question text, p_answer text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if p_vote not in (-1, 1) then return; end if;
  insert into public.ai_feedback(vote, question, answer)
  values (p_vote::smallint, left(coalesce(p_question, ''), 300), left(coalesce(p_answer, ''), 600));
  if random() < 0.01 then
    delete from public.ai_feedback where created_at < now() - interval '90 days';
    delete from public.ai_feedback where id in (
      select id from public.ai_feedback order by id desc offset 3000);
  end if;
end $$;
revoke all on function public.ai_feedback_add(int, text, text) from public, anon, authenticated;
grant execute on function public.ai_feedback_add(int, text, text) to service_role;
