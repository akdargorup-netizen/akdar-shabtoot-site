-- supabase/migrations/20261021_storage_cleanup.sql — شبتوت بحري
-- حذف صور Storage عند حذف المحتوى (المشرف/المالك فقط). شغّله في SQL Editor. آمن لو أعدت تشغيله.
--
-- ١) سياسة حذف على bucket الصور للمشرف المسجّل فقط (anon لا يحذف).
-- ٢) دالة akdar_image_in_use(url): هل ما زال أي سجل يشير لهذه الصورة؟ — لأن زر "اختر من صور البلد"
--    يربط أخبارًا/مشاريع/مقالات بصورة موجودة في المعرض، فلا نحذف ملفًا ما زال مستخدمًا.

drop policy if exists "akdar admin delete" on storage.objects;
create policy "akdar admin delete" on storage.objects
  for delete to authenticated
  using (bucket_id = 'akdar-images' and public.akdar_is_admin());

create or replace function public.akdar_image_in_use(p_url text) returns boolean
language sql stable security definer set search_path = public as $$
  select p_url <> '' and (
       exists (select 1 from public.news                          where image = p_url)
    or exists (select 1 from public.gallery                       where image = p_url)
    or exists (select 1 from public.projects                      where image = p_url)
    or exists (select 1 from public.history_articles              where image = p_url)
    or exists (select 1 from public.association_journey_articles  where image = p_url)
  );
$$;
revoke all on function public.akdar_image_in_use(text) from public, anon;
grant execute on function public.akdar_image_in_use(text) to authenticated;
