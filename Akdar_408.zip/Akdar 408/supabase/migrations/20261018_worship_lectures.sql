-- supabase/migrations/20261018_worship_lectures.sql — شبتوت بحري
-- المحاضرات الدينية (قسم العبادة): روابط يوتيوب تنشرها الإدارة.
-- شغّله بعد ملفات الدفعة ٢ب. آمن لو أعدت تشغيله. القراءة للجميع، الإضافة/التعديل للمشرف/المالك، الحذف للمالك.

create table if not exists public.worship_lectures (
  id text primary key default gen_random_uuid()::text,
  youtube_id text not null default '', title text not null default '',
  speaker text not null default '', excerpt text not null default '',
  extra jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);

drop trigger if exists worship_lectures_touch on public.worship_lectures;
create trigger worship_lectures_touch before update on public.worship_lectures
  for each row execute function public.akdar_touch_updated_at();
alter table public.worship_lectures enable row level security;

drop policy if exists worship_lectures_read   on public.worship_lectures;
drop policy if exists worship_lectures_insert on public.worship_lectures;
drop policy if exists worship_lectures_update on public.worship_lectures;
drop policy if exists worship_lectures_delete on public.worship_lectures;
create policy worship_lectures_read   on public.worship_lectures for select using (true);
create policy worship_lectures_insert on public.worship_lectures for insert with check (public.akdar_is_admin());
create policy worship_lectures_update on public.worship_lectures for update using (public.akdar_is_admin()) with check (public.akdar_is_admin());
create policy worship_lectures_delete on public.worship_lectures for delete using (public.akdar_is_owner());

grant select on public.worship_lectures to anon, authenticated;
grant insert, update, delete on public.worship_lectures to authenticated;
