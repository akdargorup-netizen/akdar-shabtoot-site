// supabase/functions/storage-overflow/index.ts — شبتوت بحري
// ══════════════════════════════════════════════════════════════
//  Edge Function — بوابة الرفع/الحذف إلى مشروع التخزين الاحتياطي (المشروع الثاني).
//  المشروع الثاني لا يعرف جلسات هذا المشروع، فهذه الدالة تتحقق من صاحب الطلب هنا ثم
//  تطلب من المشروع الثاني رابط رفع موقّعًا قصير العمر (أو تحذف ملفًا) بمفتاحه السرّي.
//
//  الأسرار (Supabase → Edge Functions → Secrets) — في هذا المشروع الأول:
//    STORAGE2_URL           مثال: https://abcdxyz.supabase.co  (عنوان المشروع الثاني)
//    STORAGE2_SERVICE_KEY   مفتاح service_role / secret للمشروع الثاني (لا يوضع في التطبيق أبدًا)
//    ALLOWED_ORIGINS        (اختياري) نطاقات إضافية مفصولة بفواصل
//
//  ⚠️ اترك "Verify JWT" معطّلًا (التحقق يتم هنا في الكود، كبقية الدوال).
//
//  الطلب (POST JSON):
//    { action: 'sign-upload', bucket: 'akdar-images' | 'akdar-audio', path: '...' }
//        → { uploadUrl, publicUrl }   ثم يرفع التطبيق الملف بـPUT إلى uploadUrl
//    { action: 'delete', bucket, paths: ['...'] } → { removed: n }
//  الصلاحية: الصور = أي حساب حقيقي (غير مجهول) كما في المشروع الأول؛ الصوت = مشرف أو مشرف رُطانة.
// ══════════════════════════════════════════════════════════════

const SUPABASE_URL = Deno.env.get('SUPABASE_URL') || 'https://rtgrkugcokqxseedzunr.supabase.co';
const SUPABASE_PUBLISHABLE_KEY = 'sb_publishable_GweumDJkfZ42oVSQar-uHg_ZUZ7az2K';
const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const MAX_REQUEST_BYTES = 8192;
const MAX_DELETE = 4;

const PATH_RE = {
  'akdar-images': /^[a-zA-Z0-9_\/-]{1,150}\.(webp|jpg|png)$/,
  'akdar-audio': /^[a-zA-Z0-9_-]+(?:\/[a-zA-Z0-9_.-]+)*\.(m4a|mp4|aac|mp3)$/,
} as Record<string, RegExp>;

const env = (k: string) => Deno.env.get(k) ?? '';

const DEFAULT_ORIGINS = ['https://akdar-shabtoot.web.app', 'https://akdar-shabtoot.firebaseapp.com'];
const LOCAL_ORIGIN = /^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/;

function corsHeadersFor(req: Request): Record<string, string> | null {
  const origin = req.headers.get('origin');
  const extra = env('ALLOWED_ORIGINS').split(',').map((s) => s.trim()).filter(Boolean);
  if (!origin || !([...DEFAULT_ORIGINS, ...extra].includes(origin) || LOCAL_ORIGIN.test(origin))) return null;
  return {
    'Access-Control-Allow-Origin': origin,
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, apikey, x-client-info',
    'Access-Control-Max-Age': '86400',
    'Vary': 'Origin',
  };
}

function reply(status: number, obj: unknown): Response {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' },
  });
}

function claimsOf(token: string): any | null {
  try {
    const parts = token.split('.');
    if (parts.length !== 3) return null;
    let b = parts[1].replace(/-/g, '+').replace(/_/g, '/');
    while (b.length % 4) b += '=';
    const claims = JSON.parse(new TextDecoder().decode(Uint8Array.from(atob(b), (c) => c.charCodeAt(0))));
    if (typeof claims.sub !== 'string' || !UUID_PATTERN.test(claims.sub)) return null;
    if (claims.is_anonymous === true) return null;
    if (!(claims.exp > Math.floor(Date.now() / 1000))) return null;
    return claims;
  } catch { return null; }
}

// نسأل المشروع الأول "بصفة المستخدم نفسه": PostgREST هو من يتحقق من توقيع التوكن
async function rpcBool(token: string, fn: string): Promise<boolean> {
  try {
    const res = await fetch(`${SUPABASE_URL}/rest/v1/rpc/${fn}`, {
      method: 'POST',
      headers: { apikey: SUPABASE_PUBLISHABLE_KEY, Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: '{}',
    });
    return res.ok && (await res.json()) === true;
  } catch { return false; }
}

async function mainHandler(req: Request): Promise<Response> {
  if (req.method !== 'POST') return reply(405, { error: 'method-not-allowed' });

  const base = env('STORAGE2_URL').replace(/\/+$/, '');
  const key = env('STORAGE2_SERVICE_KEY');
  if (!base || !key) return reply(500, { error: 'not-configured' });

  const bearer = /^Bearer\s+(.+)$/i.exec(req.headers.get('authorization') || '')?.[1];
  if (!bearer || !claimsOf(bearer)) return reply(401, { error: 'unauthorized' });

  const raw = await req.text();
  if (raw.length > MAX_REQUEST_BYTES) return reply(413, { error: 'payload-too-large' });
  let p: any;
  try { p = JSON.parse(raw || '{}'); } catch { return reply(400, { error: 'invalid-json' }); }

  const { action, bucket } = p ?? {};
  if (!['sign-upload', 'delete'].includes(action) || !PATH_RE[bucket]) return reply(400, { error: 'invalid-request' });

  // الصلاحية: الصوت لمشرف/مشرف رُطانة، والحذف لهما أيضًا (الصور والصوت)، ورفع الصور لأي حساب حقيقي
  const needsStaff = bucket === 'akdar-audio' || action === 'delete';
  if (needsStaff && !(await rpcBool(bearer, 'akdar_is_admin') || await rpcBool(bearer, 'akdar_is_nubian'))) {
    return reply(403, { error: 'forbidden' });
  }

  // المفاتيح الجديدة (sb_secret_...) تكفيها apikey؛ المفاتيح القديمة (JWT) تُرسل أيضًا كـBearer
  const headers: Record<string, string> = { apikey: key, 'Content-Type': 'application/json' };
  if (key.startsWith('eyJ')) headers.Authorization = `Bearer ${key}`;

  if (action === 'sign-upload') {
    const path = p.path;
    if (typeof path !== 'string' || !PATH_RE[bucket].test(path) || path.includes('..')) return reply(400, { error: 'invalid-path' });
    const res = await fetch(`${base}/storage/v1/object/upload/sign/${bucket}/${path}`, { method: 'POST', headers });
    if (!res.ok) return reply(502, { error: 'sign-failed', status: res.status });
    const { url } = await res.json();
    if (typeof url !== 'string') return reply(502, { error: 'sign-failed' });
    return reply(200, {
      uploadUrl: `${base}/storage/v1${url.startsWith('/') ? '' : '/'}${url}`,
      publicUrl: `${base}/storage/v1/object/public/${bucket}/${path}`,
    });
  }

  // delete
  const paths = Array.isArray(p.paths) ? p.paths : [];
  if (!paths.length || paths.length > MAX_DELETE || !paths.every((x: unknown) => typeof x === 'string' && PATH_RE[bucket].test(x) && !x.includes('..'))) {
    return reply(400, { error: 'invalid-paths' });
  }
  const res = await fetch(`${base}/storage/v1/object/${bucket}`, { method: 'DELETE', headers, body: JSON.stringify({ prefixes: paths }) });
  if (!res.ok) return reply(502, { error: 'delete-failed', status: res.status });
  return reply(200, { removed: paths.length });
}

Deno.serve(async (req: Request) => {
  const cors = corsHeadersFor(req);
  if (req.method === 'OPTIONS') return new Response(null, { status: cors ? 204 : 403, headers: cors ?? {} });
  const res = await mainHandler(req);
  if (cors) for (const [k, v] of Object.entries(cors)) res.headers.set(k, v);
  return res;
});
