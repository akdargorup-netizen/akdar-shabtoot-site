// supabase/functions/send-notification/index.ts — شبتوت بحري
// ══════════════════════════════════════════════════════════════
//  Supabase Edge Function — نقطة الوصل الآمنة بين لوحة الإدارة وبين GitHub Actions.
//  (بديل نسخة Netlify: نفس المنطق، بدون تغيير في السلوك أو أكواد الأخطاء.)
//
//  الأسرار (Supabase → Edge Functions → Secrets):
//    GITHUB_DISPATCH_TOKEN  (مطلوب)  Fine-grained PAT، صلاحية Contents: Read and write، لريبو akdar-shabtoot فقط
//    ADMIN_PUSH_KEY         (اختياري) مفتاح مرحلي ≥ 16 حرفًا (الطريق القديم X-Push-Key)
//    DISABLE_PUSH_KEY       (اختياري) اكتب 1 لإغلاق الطريق القديم بعد نجاح الإرسال بالتوكن
//    ALLOWED_ORIGINS        (اختياري) نطاقات إضافية مفصولة بفواصل
//
//  ⚠️ إعداد لازم: اترك "Verify JWT" معطّلًا لهذه الدالة (Edge Functions ← الدالة ← Details/Settings).
//     التحقق من الهوية يتم هنا داخل الكود (لا نعتمد على بوابة Supabase).
//
//  الصلاحية: توكن Supabase (access token) صالح لحساب غير مجهول دوره owner في جدول
//  user_roles، أو مفتاح X-Push-Key.
//  التحقق بدون أي سر: نسأل قاعدة البيانات "بصفة المستخدم نفسه" عن صفّه في user_roles
//  (سياسة RLS تسمح له بقراءة صفه فقط) — لو التوكن مزوّر/منتهي تُرفض القراءة.
// ══════════════════════════════════════════════════════════════

const GITHUB_OWNER = 'akdargorup-netizen';
const GITHUB_REPO = 'akdar-shabtoot';
// القيمتان عامتان بطبيعتهما (نفس الموجودتين في js/data/supabase-client.js)
const SUPABASE_URL = Deno.env.get('SUPABASE_URL') || 'https://rtgrkugcokqxseedzunr.supabase.co';
const SUPABASE_PUBLISHABLE_KEY = 'sb_publishable_GweumDJkfZ42oVSQar-uHg_ZUZ7az2K';
const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

const MAX_REQUEST_BYTES = 4096;
const MAX_TITLE = 100;
const MAX_BODY = 400;
const PAGE_PATTERN = /^[a-z0-9-]{1,40}$/;
const MIN_KEY_LENGTH = 16;

// نفس مفاتيح NOTIFICATION_TYPES في js/data/local-data.js (القابلة للاختيار من لوحة الإدارة)
const VALID_TYPES = new Set([
  'news', 'event', 'solidarity', 'congrats', 'condolence', 'community', 'project', 'idea', 'worship', 'nubian', 'system',
]);

const env = (k: string) => Deno.env.get(k) ?? '';

// ── CORS (قائمة بيضاء، ليست *) ──────────────────────────────────
const DEFAULT_ORIGINS = [
  'https://akdar-shabtoot.web.app',
  'https://akdar-shabtoot.firebaseapp.com',
];
const LOCAL_ORIGIN = /^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/;

function allowedOrigins(): string[] {
  const extra = env('ALLOWED_ORIGINS').split(',').map((s) => s.trim()).filter(Boolean);
  return [...new Set([...DEFAULT_ORIGINS, ...extra])];
}
function corsHeadersFor(req: Request): Record<string, string> | null {
  const origin = req.headers.get('origin');
  if (!origin || !(allowedOrigins().includes(origin) || LOCAL_ORIGIN.test(origin))) return null;
  return {
    'Access-Control-Allow-Origin': origin,
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Push-Key, apikey, x-client-info',
    'Access-Control-Max-Age': '86400',
    'Vary': 'Origin',
  };
}

function reply(status: number, obj: unknown): Response {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' },
  });
}

// ── أدوات التشفير (WebCrypto) ───────────────────────────────────
const enc = new TextEncoder();

function b64urlToBytes(s: string): Uint8Array {
  let b = s.replace(/-/g, '+').replace(/_/g, '/');
  while (b.length % 4) b += '=';
  const bin = atob(b);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
function b64urlJson(part: string): any {
  return JSON.parse(new TextDecoder().decode(b64urlToBytes(part)));
}

// مقارنة ثابتة الزمن (بعد هاش الاثنين لنفس الطول)
async function keysMatch(provided: string, expected: string): Promise<boolean> {
  const a = new Uint8Array(await crypto.subtle.digest('SHA-256', enc.encode(String(provided))));
  const b = new Uint8Array(await crypto.subtle.digest('SHA-256', enc.encode(String(expected))));
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a[i] ^ b[i];
  return diff === 0;
}

// ── التحقق من توكن Supabase (بدون مكتبات وبدون أسرار) ───────────
// يرجّع claims التوكن لو صالح وصاحبه owner وحسابه غير مجهول، وإلا null
async function verifyAdminToken(accessToken: string): Promise<any | null> {
  try {
    const parts = String(accessToken).split('.');
    if (parts.length !== 3) return null;
    const claims = b64urlJson(parts[1]);
    if (typeof claims.sub !== 'string' || !UUID_PATTERN.test(claims.sub)) return null;
    if (claims.is_anonymous === true) return null;
    if (!(claims.exp > Math.floor(Date.now() / 1000))) return null;

    // PostgREST هو من يتحقق من توقيع التوكن؛ وسياسة "roles read own" ترجّع صفّ المستخدم نفسه فقط
    const res = await fetch(
      `${SUPABASE_URL}/rest/v1/user_roles?select=is_owner&user_id=eq.${claims.sub}`,
      { headers: { apikey: SUPABASE_PUBLISHABLE_KEY, Authorization: `Bearer ${accessToken}` } },
    );
    if (!res.ok) return null;
    const rows = await res.json();
    return Array.isArray(rows) && rows[0]?.is_owner === true ? claims : null;
  } catch {
    return null;
  }
}

async function mainHandler(req: Request): Promise<Response> {
  if (req.method !== 'POST') return reply(405, { error: 'method-not-allowed' });

  // ── التحقق من هوية المرسل — قبل أي شيء آخر ──────────────────
  const bearer = /^Bearer\s+(.+)$/i.exec(req.headers.get('authorization') || '')?.[1];
  let authorized = false;
  if (bearer) authorized = !!(await verifyAdminToken(bearer));

  const expectedKey = env('ADMIN_PUSH_KEY');
  const keyDisabled = env('DISABLE_PUSH_KEY') === '1';
  const keyConfigured = !keyDisabled && !!expectedKey && expectedKey.length >= MIN_KEY_LENGTH;
  const pushKey = req.headers.get('x-push-key');
  if (!authorized && keyConfigured && pushKey) {
    authorized = await keysMatch(pushKey, expectedKey);
  }

  if (!authorized) {
    if (keyDisabled && !bearer) return reply(401, { sent: false, reason: 'token-required' });
    if (!bearer && !keyConfigured) return reply(500, { sent: false, reason: 'key-not-configured' });
    return reply(401, { sent: false, reason: 'unauthorized' });
  }

  const token = env('GITHUB_DISPATCH_TOKEN');
  if (!token) return reply(500, { sent: false, reason: 'token-not-configured' });

  // ── التحقق من المحتوى ───────────────────────────────────────
  const raw = await req.text();
  if (raw.length > MAX_REQUEST_BYTES) return reply(413, { error: 'payload-too-large' });

  let payload: any;
  try { payload = JSON.parse(raw || '{}'); } catch { return reply(400, { error: 'invalid-json' }); }

  const { title, body, page, type } = payload ?? {};
  if (typeof title !== 'string' || typeof body !== 'string' || !title.trim() || !body.trim()) {
    return reply(400, { error: 'missing-title-or-body' });
  }
  if (title.length > MAX_TITLE || body.length > MAX_BODY) return reply(400, { error: 'text-too-long' });
  if (page != null && page !== '' && !(typeof page === 'string' && PAGE_PATTERN.test(page))) {
    return reply(400, { error: 'invalid-page' });
  }
  if (type != null && type !== '' && !VALID_TYPES.has(type)) return reply(400, { error: 'invalid-type' });

  try {
    const res = await fetch(`https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/dispatches`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Accept': 'application/vnd.github+json',
        'Content-Type': 'application/json',
        'User-Agent': 'akdar-shabtoot-edge',
      },
      body: JSON.stringify({
        event_type: 'send-notification',
        client_payload: { title: title.trim(), body: body.trim(), page: page || null, type: type || null },
      }),
    });

    if (!res.ok) {
      const text = await res.text().catch(() => '');
      return reply(502, { sent: false, reason: 'github-error', status: res.status, detail: text });
    }
    return reply(200, { sent: true });
  } catch (err) {
    return reply(502, { sent: false, reason: 'network-error', detail: String(err) });
  }
}

Deno.serve(async (req: Request) => {
  const cors = corsHeadersFor(req);
  if (req.method === 'OPTIONS') {
    return new Response(null, { status: cors ? 204 : 403, headers: cors ?? {} });
  }
  const res = await mainHandler(req);
  if (cors) for (const [k, v] of Object.entries(cors)) res.headers.set(k, v);
  return res;
});
