#!/usr/bin/env bash
# deploy.sh — شبتوت بحري: نشر واحد على الاستضافات الثلاث (Vercel + Firebase + GitHub Pages)
#   cd ~/storage/shared/"Akdar 400" && bash deploy.sh
# خيارات:
#   --only vercel,github      انشر على مضيف أو أكثر فقط (لإعادة محاولة مضيف فشل)
#   --skip-build              أعد نشر dist/ الحالي بلا بناء
#   --no-verify               بلا فحص ما بعد النشر
#   --setup-github USER/REPO  اضبط مضيف GitHub Pages (مرة واحدة)
# كل مضيف يُنشر باستقلال: نفاد حصة أحدها أو فشله لا يوقف الباقي، وينتهي السكربت بملخص.
set -u
cd "$(dirname "$0")" || exit 1

ONLY="vercel,firebase,github"; SKIP_BUILD=0; VERIFY=1
while [ $# -gt 0 ]; do
  case "$1" in
    --only) ONLY="${2:-}"; shift 2;;
    --skip-build) SKIP_BUILD=1; shift;;
    --no-verify) VERIFY=0; shift;;
    --setup-github) node build/gen-hosts.js --set-github "${2:-}" || exit 1; shift 2;;
    -h|--help) sed -n '2,11p' "$0"; exit 0;;
    *) echo "خيار غير معروف: $1"; exit 1;;
  esac
done
has() { case ",$ONLY," in *",$1,"*) return 0;; esac; return 1; }
die() { echo "❌ $*"; exit 1; }
step() { echo; echo "▶ $*"; }
command -v node >/dev/null || die "Node.js غير مثبّت (pkg install nodejs)"

ST_vercel=skip; ST_firebase=skip; ST_github=skip
MSG_github=""

# ── مضيف GitHub Pages: لازم USER/REPO ──────────────────────────────────
if has github && [ "$(node build/gen-hosts.js --get github.enabled)" != "1" ]; then
  guess=$(git remote get-url origin 2>/dev/null | sed -nE 's#.*github\.com[:/]([^/]+/[^/.]+)(\.git)?$#\1#p')
  if [ -t 0 ]; then
    read -r -p "مستودع GitHub لصفحات Pages (USER/REPO) [${guess}]: " repo
    repo="${repo:-$guess}"
  else repo="$guess"; fi
  if [ -n "${repo:-}" ]; then node build/gen-hosts.js --set-github "$repo" || exit 1
  else MSG_github="لم يُضبط المستودع — شغّل: bash deploy.sh --setup-github USER/REPO"; ST_github=unset; fi
fi

# ── البناء مرة واحدة تُنشر نتيجتها على الكل ─────────────────────────────
if [ "$SKIP_BUILD" = 0 ]; then
  step "توليد قائمة المضيفات"; node build/gen-hosts.js || die "gen-hosts"
  step "تجميع CSS";            node build/bundle-css.js || die "bundle-css"
  step "modulepreload";        node build/gen-modulepreload.js || die "gen-modulepreload"
  step "فحص الـservice worker"; node build/check-sw-core.js || die "check-sw-core"
  grep -n "const CACHE_VERSION" service-worker.js
  step "بناء dist/ (مرة واحدة)"; node build/build-dist.js || die "build-dist"
  node build/gen-vercel-json.js || die "gen-vercel-json"
fi
[ -d dist ] || die "لا يوجد dist/ — شغّل بدون --skip-build"
WANT=$(grep -o "const CACHE_VERSION = '[^']*'" service-worker.js | head -1)

# ── Vercel ──────────────────────────────────────────────────────────────
deploy_vercel() {
  command -v vercel >/dev/null || { echo "vercel CLI غير مثبّت (npm i -g vercel)"; return 1; }
  [ -d .vercel ] || vercel link --yes --project "$(node build/gen-hosts.js --get vercel.project)" || return 1
  rm -rf dist/.vercel && cp -r .vercel dist/.vercel
  ( cd dist && vercel deploy --prod --yes ); local rc=$?
  [ -d dist/.vercel ] && { rm -rf .vercel && cp -r dist/.vercel .vercel; }
  rm -rf dist/.vercel   # لا يجوز أن يصل إلى Firebase/GitHub
  return $rc
}

# ── Firebase (نفس dist بلا predeploy كي لا يُعاد البناء ولا يُستهلك Supabase) ──
deploy_firebase() {
  command -v firebase >/dev/null || { echo "firebase CLI غير مثبّت (npm i -g firebase-tools)"; return 1; }
  rm -rf dist/.vercel
  node -e "const f=require('./firebase.json');delete f.hosting.predeploy;require('fs').writeFileSync('firebase.nopredeploy.json',JSON.stringify(f))" || return 1
  firebase deploy --only hosting --project "$(node build/gen-hosts.js --get firebase.project)" --config firebase.nopredeploy.json --non-interactive; local rc=$?
  rm -f firebase.nopredeploy.json
  return $rc
}

# ── GitHub Pages: فرع gh-pages (كامل التطبيق) ───────────────────────────
ensure_pages() {   # اختياري: يفعّل Pages على الفرع لو gh مثبّت ومسجّل دخول
  command -v gh >/dev/null || return 0
  local repo="$1" br="$2"
  [ "$(gh api "repos/$repo/pages" --jq .source.branch 2>/dev/null)" = "$br" ] && return 0
  gh api -X POST "repos/$repo/pages" -f "source[branch]=$br" -f "source[path]=/" >/dev/null 2>&1 \
   || gh api -X PUT "repos/$repo/pages" -f build_type=legacy -f "source[branch]=$br" -f "source[path]=/" >/dev/null 2>&1 \
   || echo "⚠️ فعّل Pages يدويًا: Settings ← Pages ← Source: Deploy from a branch ← $br / (root)"
}
deploy_github() {
  command -v git >/dev/null || { echo "git غير مثبّت"; return 1; }
  local repo br remote tmp rc
  repo=$(node build/gen-hosts.js --get github.repo); br=$(node build/gen-hosts.js --get github.branch)
  remote=$(git remote get-url origin 2>/dev/null || true)
  case "$remote" in *"$repo"*) ;; *) remote="https://github.com/${repo}.git";; esac
  tmp=$(mktemp -d) || return 1
  node build/prepare-pages.js dist "$tmp" || { rm -rf "$tmp"; return 1; }
  ( cd "$tmp" && git init -q && git symbolic-ref HEAD "refs/heads/$br" && git add -A \
    && git -c user.name=deploy.sh -c user.email=deploy@localhost commit -q -m "deploy $(date -u +%FT%TZ)" \
    && git push -f "$remote" "$br" ); rc=$?
  rm -rf "$tmp"
  [ $rc = 0 ] && ensure_pages "$repo" "$br"
  return $rc
}

# ── فحص ما بعد النشر: health.json سليم + نفس CACHE_VERSION ──────────────
verify_host() {   # base tries delay
  command -v curl >/dev/null || return 0
  local base="$1" tries="$2" delay="$3" i sw
  for i in $(seq 1 "$tries"); do
    if curl -fsS --max-time 15 "${base}health.json?t=$(date +%s)" 2>/dev/null | grep -q '"app":"akdar"'; then
      sw=$(curl -fsS --max-time 20 "${base}service-worker.js?t=$(date +%s)" 2>/dev/null | grep -o "const CACHE_VERSION = '[^']*'" | head -1)
      [ "$sw" = "$WANT" ] && return 0
    fi
    sleep "$delay"
  done
  return 1
}
base_of() { node -e "const c=require('./hosts.config.json');const h=c.hosts.find(x=>x.id==='$1');process.stdout.write(h?h.base:'')"; }

for h in vercel firebase github; do
  has "$h" || continue
  [ "$h" = github ] && [ "$ST_github" = unset ] && continue
  step "نشر على $h"
  if "deploy_$h"; then eval "ST_$h=ok"; else eval "ST_$h=fail"; fi
done

if [ "$VERIFY" = 1 ]; then
  step "فحص النسخة المنشورة"
  for h in vercel firebase github; do
    eval "s=\$ST_$h"; [ "$s" = ok ] || continue
    t=4; d=3; [ "$h" = github ] && { t=18; d=10; }   # Pages يحتاج دقيقة أو اثنتين للظهور
    if verify_host "$(base_of $h)" "$t" "$d"; then echo "  ✅ $h يخدم $WANT"; else echo "  ⚠️ $h لم يُثبت النسخة بعد (قد يتأخر قليلًا) — افتح: $(base_of $h)"; fi
  done
fi

echo; echo "══════ الملخص ══════"
bad=0
for h in vercel firebase github; do
  eval "s=\$ST_$h"
  case "$s" in
    ok)    echo "  ✅ $h";;
    fail)  echo "  ❌ $h — أعد المحاولة: bash deploy.sh --skip-build --only $h"; bad=1;;
    unset) echo "  ⏭ $h — $MSG_github"; bad=1;;
    *)     echo "  ·  $h (متخطّى)";;
  esac
done
[ "$bad" = 0 ] && echo "✅ تم النشر" || echo "⚠️ اكتمل جزئيًا — المضيفات الناجحة تعمل، والتطبيق يتحوّل تلقائيًا إليها."
exit $bad
