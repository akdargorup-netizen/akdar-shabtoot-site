# بناء APK — أخضر شبتوت بحري (Capacitor، ملفات مضمَّنة)

## ما هذا
غلاف أندرويد يحمل `dist/` داخل الـAPK نفسه (الصفحات تعمل بلا نت ولا تستهلك حصة الاستضافة).
المحتوى المتغيّر (المرآة، Supabase) يُجلب من الإنترنت كالمعتاد، والنسخة المضمَّنة وقت البناء احتياط بلا نت.
البناء كله في **GitHub Actions** (لا حاجة لـnpm أو Android SDK على هاتفك).

## التجربة الأولى (بلا مفتاح)
1. ارفع المشروع إلى مستودع GitHub كالعادة (الملفات `apk/` و`.github/workflows/build-apk.yml` جزء منه).
2. GitHub ← Actions ← **build-apk** ← Run workflow.
3. بعد النجاح: افتح التشغيل ← Artifacts ← حمّل `Akdar-1.0.NNN-DEBUG` (ملف مضغوط فيه APK) وثبّته على هاتفك.
   هذا APK **تجريبي**: لا يُحدَّث فوقه إصدار موقّع لاحق (يلزم حذفه أولًا).

## الإصدار الحقيقي (موقّع) — مرة واحدة
في Termux:
```
pkg install openjdk-17
keytool -genkeypair -v -keystore akdar-release.jks -alias akdar -keyalg RSA -keysize 2048 -validity 10000
base64 -w0 akdar-release.jks > ks.b64
```
ثم GitHub ← Settings ← Secrets and variables ← Actions ← New secret:
- `ANDROID_KEYSTORE_BASE64` = محتوى `ks.b64`
- `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS` (= akdar), `ANDROID_KEY_PASSWORD`

⚠️ احتفظ بملف `akdar-release.jks` وكلمتي السر في مكانين آمنين خارج المشروع. لو ضاع لن تستطيع تحديث التطبيق لمن ثبّته.
لا ترفعه إلى GitHub ولا تضعه داخل مجلد المشروع.

## معرّف الحزمة
`app.akdar.shabtoot` في `apk/capacitor.config.json`. **لا يتغيّر بعد أول تثبيت لمستخدمين حقيقيين.** غيّره الآن إن أردت غيره.

## ما ينقص (مراحل لاحقة)
- الدخول بجوجل: نافذة Firebase المنبثقة (`signInWithPopup`) لا تعمل داخل WebView؛ يلزم إضافة أصلية ثم `signInWithIdToken` كما هو.
- الإشعارات: إشعارات الويب لا تعمل في الغلاف؛ يلزم FCM.
- التحديث: كل تغيير في الصفحات يحتاج APK جديدًا (أو تحديث OTA لاحقًا).
