// apk/scripts/patch-android.mjs — يعدّل مشروع أندرويد المولَّد (cap add android) بعد توليده:
//  • versionCode / versionName من رقم الكاش (VERSION_CODE / VERSION_NAME)
//  • أيقونات التطبيق وخلفية الأيقونة التكيّفية
// يفشل بصوت عالٍ لو لم يجد ما يعدّله (حتى لا يُبنى APK بإصدار 1 دون أن ننتبه).
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const res = path.join(root, 'android', 'app', 'src', 'main', 'res');
const code = process.env.VERSION_CODE || '1';
const name = process.env.VERSION_NAME || '1.0';

const gp = path.join(root, 'android', 'app', 'build.gradle');
let g = fs.readFileSync(gp, 'utf8');
const g2 = g
  .replace(/versionCode\s*=?\s*\d+/, `versionCode ${code}`)
  .replace(/versionName\s*=?\s*"[^"]*"/, `versionName "${name}"`);
if (g2 === g && !g.includes(`versionCode ${code}`)) {
  console.error('❌ لم أجد versionCode/versionName في app/build.gradle — راجع قالب Capacitor');
  process.exit(1);
}
fs.writeFileSync(gp, g2);
console.log(`✓ versionCode=${code} versionName=${name}`);

// الأيقونات
const srcRes = path.join(root, 'resources', 'android-res');
function copyDir(from, to) {
  for (const ent of fs.readdirSync(from, { withFileTypes: true })) {
    const a = path.join(from, ent.name), b = path.join(to, ent.name);
    if (ent.isDirectory()) { fs.mkdirSync(b, { recursive: true }); copyDir(a, b); } else fs.copyFileSync(a, b);
  }
}
copyDir(srcRes, res);
fs.mkdirSync(path.join(res, 'mipmap-anydpi-v26'), { recursive: true });
const adaptive = `<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/ic_launcher_background"/>
    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>
</adaptive-icon>
`;
fs.writeFileSync(path.join(res, 'mipmap-anydpi-v26', 'ic_launcher.xml'), adaptive);
fs.writeFileSync(path.join(res, 'mipmap-anydpi-v26', 'ic_launcher_round.xml'), adaptive);
fs.mkdirSync(path.join(res, 'values'), { recursive: true });
fs.writeFileSync(path.join(res, 'values', 'ic_launcher_background.xml'),
  `<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#113714</color>\n</resources>\n`);
console.log('✓ الأيقونات');
